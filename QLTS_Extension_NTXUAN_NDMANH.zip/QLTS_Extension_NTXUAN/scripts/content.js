function sendDataToClient_inject(data){
    switch(data.action){
        case "close_popup":
          close_popup_inject();
          break;
        case "create_misaqlts":
          create_misaqlts_inject();
          break;
        case "login_misaqlts":
          login_misaqlts_inject();
          break;
        case "change_misaqlts":
          change_misaqlts_inject();
        case "change_license":
          change_license_inject();
          break;
        case "enable_DGL":
          enable_DGL_inject();
          break;
        case "show_data_bind":
          show_data_bind_inject();
          break;
        case "get_voucher_id":
          get_voucher_id_inject();
          break;
        case "get_voucher_id_org":
          get_voucher_id_org_inject();
          break;
        case "get_HM_NG_Am":
          get_HM_NG_Am();
          break;
        case "get_fixed_asset_id":
          get_fixed_asset_id_inject();
          break;
        case "jira_refresh":
          jira_refresh_inject();
          break;
        case "create_PAM_AM":
          create_PAM_AM_inject();
          break;
        case "create_PAM_PM":
          create_PAM_PM_inject();
          break;
      }
}

function create_PAM_AM_inject(){
  $("#clone-issue").click();

  setTimeout(function(){
    var m = new Date();
    var dateString = m.getUTCDate() + "/" + (m.getUTCMonth()+1) + "/" + m.getUTCFullYear();
    let summary = `Dự án QLTSv2 yêu cầu truy cập máy chủ QLTS từ 08h đến 12h ngày ${dateString}`;

    $("#summary").val(summary);
    $("#clone-issue-submit").click();
  },1000);
}

function create_PAM_PM_inject(){
  $("#clone-issue").click();

  setTimeout(function(){
    var m = new Date();
    var dateString = m.getUTCDate() + "/" + (m.getUTCMonth()+1) + "/" + m.getUTCFullYear();
    let summary = `Dự án QLTSv2 yêu cầu truy cập máy chủ QLTS từ 14h đến 18h ngày ${dateString}`;

    $("#summary").val(summary);
    $("#clone-issue-submit").click();
  },1000);
}

function jira_refresh_inject(){
    setInterval(function(){$(".search-button").click();},30000);

    $(".search-button").click();
}

function show_data_bind_inject(){
    $("[data-bind]").each(function(){
		let control = $(this),
			labelChild = control.find("label"),
			label = control.parent().parent().find("label"),
			data_bind = control.attr("data-bind"),
			text = label.text();
			
		if(labelChild.length > 0){
			label = labelChild;
			text = label.text();
		}
		
		text = text.substr(0,text.indexOf("[") > 0 ? text.indexOf("[") : 200);

        control.attr("title",data_bind);
		
		label.html(`${text} <span style="color: red">[${data_bind}]</span>`);
	});
	
	$(".header-standard [data-field]").each(function(){
		let control = $(this),
			span = control.find("span"),
			data_field = control.attr("data-field"),
			newItem = control.find(".newItem"),
			text = span.text();
		
		text = text.substr(0,text.indexOf("[") > 0 ? text.indexOf("[") : 200);
		
		span.attr("title",data_field);
		
		$(".table-standard .header-row").height(40);
		
		if(newItem.length > 0){
			newItem.text(data_field);
		}else{
			control.append(`<span class="newItem" style="color: red;position: absolute; top: 17px; left: 0">${data_field}</span>`);
		}
	});
}

function get_fixed_asset_id_inject(){
    let value = $("#grdFixedAssetList .selected-row-record").attr("id");

    let query = `CALL Proc_Jira_ReCallUpdateFAData('${value}');`;

    $(".page-title").text(query);
}

function get_voucher_id_inject(){
    let voucherid = $("#tableHistoryChange .selected-row-record").attr("id");
    let fa_id = $("#grdFixedAssetList .selected-row-record").attr("id");

    let query = `CALL Proc_Jira_Backup_ChangeDate_Voucher('${voucherid}','${fa_id}', 1);`;

    $(".page-title").text(query);
}

function get_voucher_id_org_inject(){
  let voucherid = $("#tableHistoryChange .selected-row-record").attr("id");
  let fa_id = $("#grdFixedAssetList .selected-row-record").attr("id");

  let query = `CALL Proc_Jira_Update_Revaluation_AccumOldByFA('${voucherid}','${fa_id}');`;

  $(".page-title").text(query);
}

function get_HM_NG_Am(){
  let fa_id = $("#grdFixedAssetList .selected-row-record").attr("id");
  let HM_value = parseFloat($("#history-change .selected-row-record .cell-item").eq(6).text().replaceAll(".",""));

  let query = `CALL Proc_Jira_Update_HM_Value_FA('${fa_id}',${HM_value});`;

  $(".page-title").text(query);
}

function enable_DGL_inject(data){
    $("#btn-save").removeClass("d-none"); 
    $("#ms-modal [data-type='money']").attr("disabled",false);
}

function change_license_inject(data){
    var data = localStorage.getItem("DataSuman");

    if (data) {
        data = JSON.parse(data);

        data.Status = true;
        data.ExpiredDays = 1000;
        data.ShowBannerWarning = false;
        data.ShowPopupWarning = false;

        localStorage.setItem("DataSuman", JSON.stringify(data));
    }

    setTimeout(function(){
        window.location.href = "https://qltsapp.misa.vn/settlement";
    },500);
}

function change_misaqlts_inject(data){
    $("#passwordOld").val("123456789@Abc");
    $("#password").val("1234567890@Abc");
    $("#rePassword").val("1234567890@Abc");

    setTimeout(function(){
        $(".btn-save").click();
    },1000);
}

function login_misaqlts_inject(data){
    $("#iptUserName").val("misaqlts");
    $("#iptPassword").val("123456789@Abc");
}

function close_popup_inject(data){
    $("#ms-modal").empty();
    $(".ms-model-choose-asset-tranfer").remove();
    $(".modal-backdrop").remove();
}

function create_misaqlts_inject(data){
    $("#btnAddAccount").click();

    setTimeout(function(){
        $("#txtJira").val('QLTSV2-35434');
        $("#txtFisrtName").val('misaqlts');
        $("#txtLastName").val('misaqlts');
        $("#txtEmail").val('misaqlts@gmail.com');
        $("#txtUserName").val('misaqlts');
        $("#txtPhoneNumber").val('0986789584');
        $("#txtPassword").val('123456789@Abc');
        $("#txtRePassword").val('123456789@Abc');
    }, 500);

    setTimeout(function(){$("#btnEstimateSave").click();},1000);
}

// Gửi lên để lấy tài sản tiếp theo
function pushNofity(message){
    try {
        chrome.runtime.sendMessage(message, (response) => {});
    } catch (error) {
        alert("Đã có lỗi push xảy ra. Vui lòng nhấn F5");
    }
}

// function goToLink(isTangMoi, _loaiHinh, _isCreateTSDA, _isTSQL) {
//     let json = {
//         message: "bindingSuccess",
//         name: data.Ten_tai_san
//     }
//     pushNofity(JSON.stringify(json));

// }