class Tool {
    constructor() {
      this.initEvents();
    }
  
    // Khởi tạo sự kiện
    initEvents() {
      let me = this;

      $(".item-options").on("click", function(){
            $(".item-options").removeClass("active");
            $(this).addClass("active");
      });

      $(".icon-choose").on("click", function(){
         $(this).toggleClass("active");
      });

      $("input").on("click", function(){
         $(this).select();
      });
  
      // Sự kiện khi click vào các button
      $(".header-item").on("click", function () {
        let command = $(this).attr("command");
  
        switch (command) {
          case "mode":
            me.collapseToggle(this);
            break;
          case "compare":
            me.compare();
            break;
          case "hideSTT":
            me.hideSTT();
            break;
        }
      });
    }

    getData(){
      let cookie = '_ga_16H7SQYWHC=deleted; _gcl_au=1.1.1985789892.1694489015; _ga_4N8J1W6EBF=GS1.1.1697767498.1.1.1697768814.0.0.0; CURRENTSERVER=JiraSoftware; SL_G_WPT_TO=vi; SL_GWPT_Show_Hide_tmp=1; SL_wptGlobTipTmp=1; JIRA_RETURNTOCOOKIE=https://baotri.misa.vn/browse/TSDR-167204; DEVICEDETAILS=Mozilla/5.0 (Windows NT 10.0: Win64: x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36||Chrome||Windows OS||PDF Viewer, Chrome PDF Viewer, Chromium PDF Viewer, Microsoft Edge PDF Viewer, WebKit built-in PDF||false||Mozilla||vi, en||true||Gi ng Dng||vi||true; seraph.rememberme.cookie=204388%3Aed32f201e4247e0b640455b3b0df2400892dea3a; _ga_H8EB1RJ15T=GS1.1.1698828013.102.1.1698828014.0.0.0; _ga_F203WK05RP=GS1.1.1698828013.103.1.1698828014.0.0.0; JSESSIONID=1112B360392150CFAD4F7C6037B27C8A; atlassian.xsrf.token=AVDJ-CUHT-JT92-0W8F_0848eae9e5154833783e22c84183e8774f799cb4_lin; cf_clearance=32qPtl10Ycg.iDQZDnqeg8T.K.oqmnLLQ.IghZGYAKo-1699232579-0-1-e934bb98.15b2a11.be35e478-0.2.1699232579; _ga_2HDB2Z79W3=GS1.1.1699232587.4.0.1699232587.60.0.0; _gid=GA1.2.1977324826.1699232588; _clck=1yk6d5|2|fgh|0|1405; _ga_ML5WDM0KD9=GS1.1.1699232587.4.1.1699232587.0.0.0; Jira_rememberMyLogin=i3uG6BtG2bDUTCNfVdJobARNxqHaVxSrf+kcp8RYLDjUCFCnJoZTAoOWjieMf2GYydIkwD+t699FcFdfte3raKry2B4B+OUb3Z+/mDKsDfWVJa22b+/Jrvnky/po2lDS/JASwGP3OiPreeoAbhdHTw==; _ga_X214Q59EZP=GS1.1.1699255750.1.0.1699255750.0.0.0; _ga_L1M17DH244=GS1.2.1699255750.1.0.1699255750.0.0.0; _ga=GA1.1.2017838567.1694393689; _ga_YC2BKEL28B=GS1.1.1699255933.2.1.1699256209.0.0.0; _ga_16H7SQYWHC=GS1.1.1699253769.183.1.1699256222.0.0.0';

      $.ajax( {
        type : "GET",
        url : "https://baotri.misa.vn/rest/api/2/issue/TSDR-171857?expand=changelog&fields=*all",
        async: false,
        crossDomain: true,
        dataType: 'json',
        xhrFields: {
          withCredentials: true
        },
        beforeSend : function(xhr) {        
          xhr.setRequestHeader('Cookie', cookie);
        },
        success : function(data, textStatus, xmLHttpRequest){
          debugger
        },
        error : function(xhr, ajaxOptions, thrownError) {
          debugger
          credentials = null;
        }
      });
    }
  
    // show/hide cột STT
    hideSTT() {
      $(".stt").toggle();
    }
  
    // Thực hiện phóng to và thu nhỏ
    collapseToggle(item) {
      let me = this;
  
      if ($(item).text() == "Phóng to") {
        $(item).text("Thu nhỏ");
      } else {
        $(item).text("Phóng to");
      }
  
      $(".content-left").toggle();
    }
  
    // Thực hiện so sánh
    compare() {
      let me = this,
          voucher_name = $(".item-options.active").text().trim();

        let data = config.filter(function(item){ return item.voucher == voucher_name})[0];

        let dataChange = JSON.parse(JSON.stringify(data));

        $(".icon-choose").each(function(item){
            let valid = $(this).hasClass("active") || $(this).hasClass("active2"),
                field = $(this).next().attr("id");

            if(valid){
                let value = $(this).next().val().trim(),
                    strValue = '';

                switch(field){
                    case "OrganID":
                        strValue = ` AND A.organization_id = '${value}'`;
                        break;
                    case "VoucherID":
                        strValue = ` AND A.voucher_id = '${value}'`;
                        break;
                    case "FixedAssetID":
                        strValue = ` AND A.fixed_asset_id = '${value}'`;
                        break;
                    case "CategoryID":
                        strValue = ` AND A.fixed_asset_category_id = '${value}'`;
                    break;
                }

                dataChange.query = dataChange.query.replaceAll(field, strValue);
            }else{
                dataChange.query = dataChange.query.replaceAll(field, '');
            }
        });

        $(".output1").html(dataChange.query);
    }
  }
  
  var tool = new Tool();