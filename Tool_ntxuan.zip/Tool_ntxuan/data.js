var config = [
    {
        query: `
        SELECT A.fixed_asset_id, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM fixed_asset_increment A WHERE 1 = 1 OrganID VoucherID;
        <br>
        <br>
        SELECT * FROM fixed_asset_increment_detail A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        <br>
        <br>
        SELECT A.fixed_asset_id, A.voucher_type, A.change_date, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset_ledger A WHERE 1 = 1 OrganID VoucherID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fa_ledger_increment_and_decrement A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        `,
        voucher: "Ghi tăng"
    },
    {
        query: `
        SELECT A.fixed_asset_id, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fixed_asset_decrement A WHERE 1 = 1 OrganID VoucherID;
        <br>
        <br>
        SELECT * FROM fixed_asset_decrement_detail A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        <br>
        <br>
        SELECT A.fixed_asset_id, A.voucher_type, A.change_date, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset_ledger A WHERE 1 = 1 OrganID VoucherID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fa_ledger_increment_and_decrement A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        `,
        voucher: "Ghi giảm"
    },
    {
        query: `
        SELECT A.fixed_asset_id, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fixed_asset_depreciation A WHERE 1 = 1 OrganID VoucherID;
        <br>
        <br>
        SELECT * FROM fixed_asset_depreciation_detail A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        <br>
        <br>
        SELECT A.fixed_asset_id, A.voucher_type, A.change_date, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset_ledger A WHERE 1 = 1 OrganID VoucherID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fa_ledger_depreciation A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        `,
        voucher: "Hao mòn"
    },
    {
        query: `
        SELECT A.fixed_asset_id, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fixed_asset_depreciation_business A WHERE 1 = 1 OrganID VoucherID;
        <br>
        <br>
        SELECT * FROM fixed_asset_depreciation_business_detail A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        <br>
        <br>
        SELECT A.fixed_asset_id, A.voucher_type, A.change_date, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset_ledger A WHERE 1 = 1 OrganID VoucherID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fa_ledger_depreciation A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        `,
        voucher: "Khấu hao"
    },
    {
        query: `
        SELECT A.fixed_asset_id, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fixed_asset_revaluation A WHERE 1 = 1 OrganID VoucherID;
        <br>
        <br>
        SELECT * FROM fa_ledger_revaluation_detail A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        <br>
        <br>
        SELECT A.fixed_asset_id, A.voucher_type, A.change_date, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset_ledger A WHERE 1 = 1 OrganID VoucherID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fa_ledger_change_info A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        `,
        voucher: "Đánh giá lại"
    },
    {
        query: `
        SELECT A.fixed_asset_id, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fixed_asset_transfer A WHERE 1 = 1 OrganID VoucherID;
        <br>
        <br>
        SELECT * FROM fixed_asset_transfer_detail A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        <br>
        <br>
        SELECT A.fixed_asset_id, A.voucher_type, A.change_date, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset_ledger A WHERE 1 = 1 OrganID VoucherID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM fa_ledger_change_info A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        `,
        voucher: "Điều chuyển"
    },
    {
        query: `
        SELECT A.fixed_asset_id, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT A.fixed_asset_id, A.voucher_type, A.change_date, A.orgprice, A.accum_depreciation_amount, A.depreciation_amount, A.depreciation_for_business_amount, A.remaining_amount FROM fixed_asset_inventory A WHERE 1 = 1 OrganID VoucherID;
        <br>
        <br>
        SELECT * FROM fa_ledger_inventory A WHERE 1 = 1 OrganID VoucherID FixedAssetID;
        `,
        voucher: "Kiểm kê"
    },
    {
        query: `
        SELECT A.convert_circular_id, A.* FROM fixed_asset A WHERE 1 = 1 OrganID FixedAssetID CategoryID;
        <br>
        <br>
        SELECT * FROM ledger_budget A WHERE 1 = 1 OrganID FixedAssetID order by change_date desc;
        <br>
        <br>
        SELECT * FROM convert_circular A WHERE 1 = 1 OrganID;
        <br>
        <br>
        SELECT A.convert_circular_id, A.* FROM convert_circular_history A WHERE 1 = 1 OrganID FixedAssetID;
        <br>
        <br>
        SELECT A.convert_circular_id, A.* FROM dic_fixed_asset_category A WHERE CategoryID;
        `,
        voucher: "Thông tư"
    },
];
