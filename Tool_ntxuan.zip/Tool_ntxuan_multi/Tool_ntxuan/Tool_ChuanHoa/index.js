class Tool {
  constructor() {
    this.initEvents();
  }

  // Khởi tạo sự kiện
  initEvents() {
    let me = this;
    $(".btn-convert").on("click", function () {
      let inputStr = $("#inputScript").val();

      if (inputStr) {
        let outputStr = me.getOutPutScript(inputStr);

        $("#outputScript").val(outputStr.trim());

        // Copy to clipboard
        navigator.clipboard.writeText(outputStr);
      }
    });
  }

  // Chuẩn hóa input
  getOutPutScript(inputStr) {
    let me = this,
      typeScript = $('input[name="typeScript"]:checked').val(),
      arrayStr = [],
      changeColumn = [],
      changeColumnText = [],
      changeIndex = [],
      modifyColumn = [],
      result = [];

    if (typeScript == "Table") {
      inputStr = inputStr.replaceAll(`dấu ";"`, `dấu chấm phảy`);
      arrayStr = inputStr.split(";");
    } else {
      inputStr = inputStr.replaceAll(`DELIMITER $$`, `DELIMITER2 $$$`);
      arrayStr = inputStr.split("$$");
    }

    arrayStr.filter(function (item, index) {
      if (item.trim() != "" && typeScript == "Table") {
        let listType = [
            "ADD COLUMN",
            "DROP COLUMN",
            "CHANGE COLUMN",
            "MODIFY",
            "ADD INDEX",
            "DROP INDEX",
            "ADD UNIQUE INDEX",
          ],
          itemCheck = item.trim() + ";",
          obj = {};

        listType.filter(function (type) {
          if (itemCheck.toUpperCase().includes(type)) {
            let arr = itemCheck.split("\n");

            arr.filter(function (item2) {
              if (item2.toUpperCase().includes("ALTER TABLE")) {
                obj.tableName = item2.trim().split(" ")[2].replace(";", "");
              } else if (item2.toUpperCase().includes(type)) {
                obj.columnName = item2.trim().split(" ")[2].replace(";", "");

                if (type == "CHANGE COLUMN") {
                  obj.dataType = item2.trim().split(" ")[4].replace(";", "");

                  if (item2.trim().split(" ")[5].includes(")")) {
                    obj.dataType += item2.trim().split(" ")[5];
                  }
                } else if (type == "ADD INDEX" || type == "DROP INDEX") {
                  obj.indexName = item2
                    .trim()
                    .split(" ")[2]
                    .replace(";", "")
                    .split("(")[0];
                } else if (type == "ADD UNIQUE INDEX") {
                  obj.indexName = item2.trim().split(" ")[3].split("(")[0];
                }
              }
            });

            if (obj.tableName) {
              itemCheck = me.getValue(obj, item, type);
            }
          }
        });

        if (
          itemCheck.includes("CALL Proc_ChangeDataTypeColumn(") ||
          itemCheck.includes("ADD INDEX") ||
          itemCheck.includes("ADD UNIQUE INDEX") ||
          itemCheck.includes("MODIFY") ||
          itemCheck.includes("DROP INDEX")
        ) {
          if (itemCheck.includes("CALL Proc_ChangeDataTypeColumn(")) {
            if (
              obj.dataType &&
              (obj.dataType.includes("VARCHAR") ||
                obj.dataType.includes("TEXT"))
            ) {
              changeColumnText.push(itemCheck);
            } else {
              changeColumn.push(itemCheck);
            }
          } else if (itemCheck.includes("MODIFY")) {
            modifyColumn.push(itemCheck);
          } else {
            changeIndex.push(itemCheck);
          }
        } else {
          if (!itemCheck.includes("DROP COLUMN")) {
            result.push(itemCheck);
          }
        }
      } else if (
        item.trim() != "" &&
        typeScript == "Store" &&
        !item.trim().includes("DROP PROCEDURE IF EXISTS") &&
        !item.trim().includes("SET FOREIGN_KEY_CHECKS") &&
        !item.trim().includes("@OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS")
      ) {
        let itemCheck = item.trim() + " $$";

        // Phần tử cuối không cần add $$
        if (index == arrayStr.length - 1) {
          itemCheck = itemCheck.replaceAll("$$", "");
        }

        if (itemCheck.toUpperCase().includes("CREATE PROCEDURE")) {
          let storeName = itemCheck.trim().split("(")[0];

          storeName = storeName.split(" ")[2].trim();

          if (storeName) {
            itemCheck = `DELIMITER ;
DROP PROCEDURE IF EXISTS ${storeName};
DELIMITER $$
                        
${itemCheck}`;
          }
        }

        result.push(itemCheck);
      }
    });

    return result
      .concat(modifyColumn, changeColumn, changeColumnText, changeIndex)
      .join("\n\n")
      .replaceAll("DELIMITER2", "DELIMITER");
  }

  // Lấy ra giá trị dựa vào type
  getValue(obj, script, type) {
    let me = this;

    switch (type) {
      case "ADD COLUMN":
        script = `SET @var = IF((SELECT TRUE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = "${obj.tableName}" AND COLUMN_NAME = "${
          obj.columnName
        }" LIMIT 1) = TRUE, 
            "SET @tem = 1;", 
            "${script.trim().split("\n").join("")};");

PREPARE script FROM @var;
EXECUTE script;
DEALLOCATE PREPARE script;`;
        break;
      case "DROP COLUMN":
        script = `SET @var = IF((SELECT TRUE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = "${obj.tableName}"
            AND COLUMN_NAME = "${obj.columnName}" LIMIT 1) = TRUE, 
            "${script.trim().split("\n").join("")};", 
            "SET @tem = 1;");

PREPARE script FROM @var;
EXECUTE script;
DEALLOCATE PREPARE script;`;
        break;
      case "CHANGE COLUMN":
        script = `DELIMITER ;
CALL Proc_ChangeDataTypeColumn('${obj.tableName}','${obj.columnName}','${obj.dataType}','NULL');`;
        break;
      case "MODIFY":
        script = `DELIMITER ;
${script.trim()};`;
        break;
      case "ADD INDEX":
      case "ADD UNIQUE INDEX":
        script = `SET @var = IF((SELECT TRUE FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = "${obj.tableName}" AND INDEX_NAME = "${
          obj.indexName
        }" LIMIT 1) = TRUE, 
            "SET @tem = 1;", 
            "${script.trim().split("\n").join("")};");

PREPARE script FROM @var;
EXECUTE script;
DEALLOCATE PREPARE script;`;
        break;
      case "DROP INDEX":
        script = `SET @var = IF((SELECT TRUE FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME = "${obj.tableName}"
            AND INDEX_NAME = "${obj.indexName}" LIMIT 1) = TRUE, 
            "${script.trim().split("\n").join("")};", 
            "SET @tem = 1;");

PREPARE script FROM @var;
EXECUTE script;
DEALLOCATE PREPARE script;`;
        break;
    }

    return script;
  }
}

var tool = new Tool();
