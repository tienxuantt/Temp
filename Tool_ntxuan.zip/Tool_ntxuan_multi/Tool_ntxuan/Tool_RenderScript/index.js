class Tool {
  constructor() {
    this.initEvents();
  }

  // Khởi tạo sự kiện
  initEvents() {
    let me = this;

    // Sự kiện khi click vào các button
    $(".header-item").on("click", function () {
      let command = $(this).attr("command");

      switch (command) {
        case "mode":
          me.collapseToggle(this);
          break;
        case "render":
          me.render();
          break;
        case "hideSTT":
          me.hideSTT();
          break;
        case "nullifnotfound":
          me.render(true);
          break;
      }
    });
  }

  // show/hide cột STT
  hideSTT() {
    $(".stt").toggle();
  }

  // Thực hiện phóng to và thu nhỏ
  collapseToggle(item) {
    let me = this;

    if ($(item).text() == "Phóng to") {
      $(item).text("Thu nhỏ");
    } else {
      $(item).text("Phóng to");
    }

    $(".content-left").toggle();
  }

  // Thực hiện so sánh
  render(defaultValue = false) {
    let me = this,
      alias1 = $("#alias1").val().trim(),
      alias2 = $("#alias2").val().trim(),
      alias3 = $("#alias3").val().trim(),
      input1 = $("#inputScript1").val().replaceAll(",", ""),
      input2 = $("#inputScript2").val().replaceAll(",", ""),
      input3 = $("#inputScript3").val().replaceAll(",", ""),
      input4 = $("#inputScript4").val();

    $(".output1").empty();

    let array1 = input1.split("\n"),
      array2 = input2.split("\n"),
      array3 = input3.split("\n"),
      array4 = input4.split("\n");

    array4.filter(function (item, index) {
      let itemCompare = item.replaceAll(",", ""),
        itemArr1 = array1.find((s) => s.trim() == itemCompare.trim()),
        itemArr2 = array2.find((s) => s.trim() == itemCompare.trim()),
        itemArr3 = array3.find((s) => s.trim() == itemCompare.trim()),
        row = $("<div></div>");

      if (itemArr1) {
        item = `${alias1}${item.trim()}`;
        row.addClass("blue");
      } else if (itemArr2) {
        item = `${alias2}${item.trim()}`;
        row.addClass("blue");
      } else if (itemArr3) {
        item = `${alias3}${item.trim()}`;
        row.addClass("blue");
      } else {
        if (defaultValue && !item.includes("NULL") && !item.includes(".")) {
          item = `NULL as ${item.trim()}`;
        }

        row.addClass("red");
      }

      item = `<span class="stt">${index + 1}</span> ${item}`;

      row.html(item);

      $(".output1").append(row);
    });
  }
}

var tool = new Tool();
