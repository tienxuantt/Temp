class Tool {
  constructor() {
    this.initEvents();
  }

  // Khởi tạo sự kiện
  initEvents() {
    let me = this;

    // Sự kiện khi click vào các button
    $(".header-item").on("click", function () {
      let command = $(this).attr("command");

      switch (command) {
        case "mode":
          me.collapseToggle(this);
          break;
        case "submit":
          me.submit();
          break;
        case "clear":
          me.submit({ clear: true });
          break;
        case "replace":
          me.submit({ replace: true });
          break;
        case "hideSTT":
          me.hideSTT();
          break;
      }
    });
  }

  // show/hide cột STT
  hideSTT() {
    $(".stt").toggle();
  }

  // Thực hiện phóng to và thu nhỏ
  collapseToggle(item) {
    let me = this;

    if ($(item).text() == "Phóng to") {
      $(item).text("Thu nhỏ");
    } else {
      $(item).text("Phóng to");
    }

    $(".content-left").toggle();
  }

  // Thực hiện so sánh
  submit(params = {}) {
    let me = this,
      split = $("#alias1").val().trim(),
      input1 = $("#inputScript1").val().trim(),
      result = "";

    $(".output1").empty();

    if (input1.trim()) {
      if (params.clear) {
        let value = input1.replaceAll("\n", "");

        $(".output1").text(value);
      } else if (params.replace) {
        let value = input1.replaceAll("\n", "/ xuan");
        value = value.replaceAll(" xuan", "n");
        $(".output1").text(value);
      } else {
        let array = input1.split(split);

        if (array && array.length > 0) {
          array.filter(function (item, index) {
            result = `<div>${item}${split}</div>`;

            if (index == array.length - 1) {
              result = `<div>${item}</div>`;
            }

            $(".output1").append(result);
          });
        }
      }
    } else {
      alert("Vui lòng điền đầy đủ thông tin!");
    }
  }
}

var tool = new Tool();
