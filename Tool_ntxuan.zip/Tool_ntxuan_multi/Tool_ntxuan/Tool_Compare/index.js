class Tool {
  constructor() {
    this.initEvents();
  }

  // Khởi tạo sự kiện
  initEvents() {
    let me = this;

    // Sự kiện khi click vào các button
    $(".header-item").on("click", function () {
      let command = $(this).attr("command");

      switch (command) {
        case "mode":
          me.collapseToggle(this);
          break;
        case "compare":
          me.compare();
          break;
        case "hideSTT":
          me.hideSTT();
          break;
      }
    });
  }

  // show/hide cột STT
  hideSTT() {
    $(".stt").toggle();
  }

  // Thực hiện phóng to và thu nhỏ
  collapseToggle(item) {
    let me = this;

    if ($(item).text() == "Phóng to") {
      $(item).text("Thu nhỏ");
    } else {
      $(item).text("Phóng to");
    }

    $(".content-left").toggle();
  }

  // Thực hiện so sánh
  compare() {
    let me = this,
      input1 = $("#inputScript1").val(),
      input2 = $("#inputScript2").val();

    if (input1.trim() && input2.trim()) {
      let array1 = input1.split("\n"),
        array2 = input2.split("\n"),
        output1 = [],
        output2 = [];

      // So sanh 1 voi 2
      array1.filter(function (item, index) {
        let obj = {
          input: item.trim(),
          inputIndex: index + 1,
        };

        for (var i = 0; i < array2.length; i++) {
          if (array2[i].trim() == item.trim()) {
            obj.output = array2[i].trim();
            obj.outputIndex = i + 1;
          }
        }

        output1.push(obj);
      });

      // So sánh 2 với 1
      array2.filter(function (item, index) {
        let obj = {
          input: item.trim(),
          inputIndex: index + 1,
        };

        for (var i = 0; i < array1.length; i++) {
          if (array1[i].trim() == item.trim()) {
            obj.output = array1[i].trim();
            obj.outputIndex = i + 1;
          }
        }

        output2.push(obj);
      });

      me.renderOutputCompare(output1, output2);
    } else {
      alert("Vui lòng điền đầy đủ thông tin!");
    }
  }

  // Thực hiện render kết quả
  renderOutputCompare(data1, data2) {
    if (data1.length > 0) {
      $(".output1").empty();

      data1.filter(function (item, index) {
        let text = $(
          `<div><span class="stt">${item.inputIndex}-${
            item.outputIndex || 0
          }</span>${item.input}</div>`
        );

        if (item.output) {
          text.addClass("blue");
        } else {
          text.addClass("red");
        }

        $(".output1").append(text);
      });
    }

    if (data2.length > 0) {
      $(".output2").empty();

      data2.filter(function (item, index) {
        let text = $(
          `<div><span class="stt">${item.inputIndex}-${
            item.outputIndex || 0
          }</span>${item.input}</div>`
        );

        if (item.output) {
          text.addClass("blue");
        } else {
          text.addClass("red");
        }

        $(".output2").append(text);
      });
    }
  }
}

var tool = new Tool();
