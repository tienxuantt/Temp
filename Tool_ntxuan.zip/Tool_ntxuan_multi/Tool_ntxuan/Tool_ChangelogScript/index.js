class Tool {
  constructor() {
    this.initEvents();
  }

  // Khởi tạo sự kiện
  initEvents() {
    let me = this;

    $(".btnAutoGetName").on("click", function () {
      let inputStr = $("#inputScript").val();

      if (inputStr) {
        let array = inputStr.split("\n"),
          storeName = [];

        array.filter(function (item) {
          if (item.includes("DROP PROCEDURE IF EXISTS")) {
            item = item.replaceAll("DROP PROCEDURE IF EXISTS ", "");
            item = item.replaceAll(";", "");

            storeName.push(item);
          }
        });

        $("#objectName").val(storeName.join(","));
      } else {
        alert("Vui lòng nhập đủ các thông tin");
      }
    });

    $(".btn-convert").on("click", function () {
      let inputStr = $("#inputScript").val();

      if (me.validateForm(inputStr)) {
        let outputStr = me.getOutPutScript(inputStr);

        $("#outputScript").val(outputStr.trim());

        // Copy to clipboard
        navigator.clipboard.writeText(outputStr);
      } else {
        alert("Vui lòng nhập đủ các thông tin");
      }
    });
  }

  // Validate form
  validateForm(inputStr) {
    let me = this,
      valid = false,
      devName = $("#devName").val(),
      objectName = $("#objectName").val();

    if (devName && objectName && inputStr) {
      valid = true;
    }

    return valid;
  }

  // Chuẩn hóa input
  getOutPutScript(inputStr) {
    let devName = $("#devName").val(),
      objectName = $("#objectName").val(),
      script = `${inputStr.trim()}

DELIMITER ;
INSERT INTO changelog ( dev_name, object_name, script_changelog, created_date, created_by, modified_date, modified_by)
VALUES ('${devName.trim().toUpperCase()}', '${objectName.trim()}', "${inputStr
        .trim()
        .replaceAll('"', "'")}", NOW(), '', NOW(), '');
`;

    return script;
  }
}

var tool = new Tool();
