class Tool {
  constructor() {
    this.initEvents();
  }

  // Khởi tạo sự kiện
  initEvents() {
    let me = this;

    // Sự kiện khi click vào title tool
    $(".content-item").on("click", function () {
      let link = $(this).attr("src");

      window.open(link, "_blank");
    });
  }
}

var tool = new Tool();
