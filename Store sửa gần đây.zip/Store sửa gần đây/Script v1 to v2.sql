﻿SELECT CONCAT('INSERT data_v1_depreciation VALUES ','(uuid(), "', OrganizationID,'","',DepartmentID,'","', FADocumentID,'","', FADocumentCode,'","', FixedAssetID,'",', DepreciationValue,',', DepreciationRate, ',', DepreciationYear,' ,"', FORMAT(DepreciationDate , 'yyyy-MM-dd HH:mm:ss'), '"',' ,"', FORMAT(ChangeDate , 'yyyy-MM-dd HH:mm:ss'), '");') AS Data
FROM dbo.FAHistory WHERE FixedAssetChangeCategoryID = 5 AND YEAR(ChangeDate) = 2019;



-- Đã done: 2020 2021

DELETE FROM data_v1_depreciation WHERE YEAR(change_date) = 2019;
SELECT *  FROM data_v1_depreciation WHERE YEAR(change_date) = 2019;

DROP TABLE IF EXISTS data_v1_depreciation;
CREATE TABLE data_v1_depreciation(
    id varchar(36) PRIMARY KEY,
    organization_id varchar(36),
    department_id varchar(36),
    voucher_id varchar(36),
    voucher_code varchar(100),
    fixed_asset_id varchar(36),
    depreciation_value decimal(19,4),
    depreciation_rate int,
    depreciation_year decimal(19,4),
    voucher_date timestamp,
    change_date timestamp
);

SELECT * FROM data_v1_depreciation;

SELECT a.* 
FROM data_v1_depreciation a 
INNER JOIN fixed_asset_depreciation fad ON a.organization_id = fad.organization_id AND a.voucher_id = fad.voucher_id
LEFT JOIN fixed_asset_depreciation_detail fadd ON fad.voucher_id = fadd.voucher_id and a.fixed_asset_id = fadd.fixed_asset_id
WHERE fadd.fixed_asset_id IS NULL;

SELECT * FROM user u WHERE u.organization_code = '1085450';

update user set status = 1 WHERE id = '404394';

SELECT * FROM jira_fixed_asset_survey jfas;


SELECT * FROM data_v1_depreciation WHERE YEAR(change_date) = 2018;

SELECT CONCAT('EXECUTE [dbo].[Proc_GetDetailRevalution_ByDocumentID_INSERT] N''', FADocumentID,''';') AS Data
FROM dbo.FAHistory WHERE FixedAssetChangeCategoryID = 2 ORDER BY ChangeDate ASC;

DELETE FROM data_v1_revaluation_v2;




