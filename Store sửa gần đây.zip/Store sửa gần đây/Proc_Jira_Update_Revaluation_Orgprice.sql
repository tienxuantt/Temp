﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_Revaluation_Orgprice;

CREATE PROCEDURE Proc_Jira_Update_Revaluation_Orgprice (IN $OrganizationID varchar(36))
BEGIN

  SET group_concat_max_len = 18446744073709551615;

  DROP TEMPORARY TABLE IF EXISTS tbLedger;
  CREATE TEMPORARY TABLE tbLedger AS
  SELECT
    SUM(lb.amount) orgledger,
    lb.voucher_id,
    lb.fixed_asset_id
  FROM ledger_budget lb
  WHERE lb.voucher_id IS NOT NULL AND lb.voucher_type = 2
  AND organization_id = $OrganizationID
  GROUP BY lb.voucher_id,
           lb.fixed_asset_id;

  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation AS
  SELECT
    far.voucher_id,
    far.fixed_asset_id,
    far.fixed_asset_revaluation_list,
    far.description,
    COALESCE(fa.fixed_asset_type, 0) fixed_asset_type
  FROM fixed_asset_revaluation far
    INNER JOIN tbLedger b
      ON far.voucher_id = b.voucher_id
      AND far.fixed_asset_id = b.fixed_asset_id
    INNER JOIN fixed_asset fa
      ON far.fixed_asset_id = fa.fixed_asset_id
  WHERE far.organization_id = $OrganizationID
  AND far.description LIKE '%Đánh giá lại do thay đổi thời gian sử dụng tài sản khi cập nhật%';

  DROP TEMPORARY TABLE IF EXISTS tbOldData;
  CREATE TEMPORARY TABLE tbOldData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    description text,
    fixed_asset_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbNewData;
  CREATE TEMPORARY TABLE tbNewData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    description text,
    fixed_asset_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbChangeData;
  CREATE TEMPORARY TABLE tbChangeData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;


  INSERT INTO tbOldData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      fa.description,
      fa.fixed_asset_type,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.old_data[*].orgprice',
         orgprice_info longtext PATH '$.old_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.old_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_amount',
         remaining_amount decimal(19, 4) PATH '$.old_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.old_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.old_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.old_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.old_data[*].quantity',
         house_category_id int PATH '$.old_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.old_data[*].house_category_name',
         number_of_floor float PATH '$.old_data[*].number_of_floor',
         build_year int PATH '$.old_data[*].build_year',
         build_area float PATH '$.old_data[*].build_area',
         total_floor_area float PATH '$.old_data[*].total_floor_area',
         area float PATH '$.old_data[*].area',
         working_office float PATH '$.old_data[*].working_office',
         leasing float PATH '$.old_data[*].leasing',
         house float PATH '$.old_data[*].house',
         basis_of_business_activity float PATH '$.old_data[*].basis_of_business_activity',
         vacant float PATH '$.old_data[*].vacant',
         business float PATH '$.old_data[*].business',
         joint_venture float PATH '$.old_data[*].joint_venture',
         mix_using float PATH '$.old_data[*].mix_using',
         occupied float PATH '$.old_data[*].occupied',
         other float PATH '$.old_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.old_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.old_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbNewData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      fa.description,
      fa.fixed_asset_type,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
         orgprice_info longtext PATH '$.new_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.new_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_amount',
         remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.new_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.new_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.new_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.new_data[*].quantity',
         house_category_id int PATH '$.new_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.new_data[*].house_category_name',
         number_of_floor float PATH '$.new_data[*].number_of_floor',
         build_year int PATH '$.new_data[*].build_year',
         build_area float PATH '$.new_data[*].build_area',
         total_floor_area float PATH '$.new_data[*].total_floor_area',
         area float PATH '$.new_data[*].area',
         working_office float PATH '$.new_data[*].working_office',
         leasing float PATH '$.new_data[*].leasing',
         house float PATH '$.new_data[*].house',
         basis_of_business_activity float PATH '$.new_data[*].basis_of_business_activity',
         vacant float PATH '$.new_data[*].vacant',
         business float PATH '$.new_data[*].business',
         joint_venture float PATH '$.new_data[*].joint_venture',
         mix_using float PATH '$.new_data[*].mix_using',
         occupied float PATH '$.new_data[*].occupied',
         other float PATH '$.new_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.new_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.new_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbChangeData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      r.*
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.change_data[*].orgprice',
         orgprice_info longtext PATH '$.change_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.change_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_amount',
         remaining_amount decimal(19, 4) PATH '$.change_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.change_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.change_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.change_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.change_data[*].quantity',
         house_category_id int PATH '$.change_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.change_data[*].house_category_name',
         number_of_floor float PATH '$.change_data[*].number_of_floor',
         build_year int PATH '$.change_data[*].build_year',
         build_area float PATH '$.change_data[*].build_area',
         total_floor_area float PATH '$.change_data[*].total_floor_area',
         area float PATH '$.change_data[*].area',
         working_office float PATH '$.change_data[*].working_office',
         leasing float PATH '$.change_data[*].leasing',
         house float PATH '$.change_data[*].house',
         basis_of_business_activity float PATH '$.change_data[*].basis_of_business_activity',
         vacant float PATH '$.change_data[*].vacant',
         business float PATH '$.change_data[*].business',
         joint_venture float PATH '$.change_data[*].joint_venture',
         mix_using float PATH '$.change_data[*].mix_using',
         occupied float PATH '$.change_data[*].occupied',
         other float PATH '$.change_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.change_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.change_data[*].orgprice_from_other'
         )) AS r;


  UPDATE tbNewData a
  INNER JOIN tbLedger b
    ON a.voucher_id = b.voucher_id
    AND a.fixed_asset_id = b.fixed_asset_id
  SET a.orgprice = orgledger,
      a.row_update = 1,
      a.remaining_amount = CASE WHEN a.fixed_asset_type = 1 THEN b.orgledger - COALESCE(a.depreciation_amount, 0) WHEN a.fixed_asset_type = 2 THEN b.orgledger - COALESCE(a.depreciation_for_business_amount, 0) WHEN a.fixed_asset_type = 3 THEN b.orgledger - COALESCE(a.depreciation_amount, 0) - COALESCE(a.depreciation_for_business_amount, 0) ELSE b.orgledger END
  WHERE a.orgprice = b.orgledger * 2
  AND orgledger <> 0
  AND a.description LIKE '%Đánh giá lại do thay đổi thời gian sử dụng tài sản khi cập nhật%';

  UPDATE tbOldData a
  INNER JOIN tbLedger b
    ON a.voucher_id = b.voucher_id
    AND a.fixed_asset_id = b.fixed_asset_id
  SET a.orgprice = b.orgledger,
      a.row_update = 1,
      a.remaining_amount = CASE WHEN a.fixed_asset_type = 1 THEN b.orgledger - COALESCE(a.depreciation_amount, 0) WHEN a.fixed_asset_type = 2 THEN b.orgledger - COALESCE(a.depreciation_for_business_amount, 0) WHEN a.fixed_asset_type = 3 THEN b.orgledger - COALESCE(a.depreciation_amount, 0) - COALESCE(a.depreciation_for_business_amount, 0) ELSE b.orgledger END
  WHERE a.orgprice = b.orgledger * 2
  AND orgledger <> 0
  AND a.description LIKE '%Đánh giá lại do thay đổi thời gian sử dụng tài sản khi cập nhật%';

  UPDATE fixed_asset_revaluation far
  INNER JOIN (SELECT
      A.voucher_id,
      A.row_update,
      B.row_update AS row_update_new,
      CONCAT('[{"old_data":', A.old_data, ',"new_data":', B.new_data, ',"change_data":', C.change_data, '}]') AS fixed_asset_revaluation_list
    FROM (SELECT
        voucher_id,
        MAX(row_update) row_update,
        CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
        'orgprice_info', orgprice_info,
        'depreciation_amount', depreciation_amount,
        'depreciation_for_business_amount', depreciation_for_business_amount,
        'remaining_amount', remaining_amount,
        'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
        'depreciation_rate', depreciation_rate,
        'depreciation_year', depreciation_year,
        'remaining_number_of_year', remaining_number_of_year,
        'depreciation_for_business_price', depreciation_for_business_price,
        'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
        'depreciation_for_business_value', depreciation_for_business_value,
        'quantity', quantity,
        'house_category_id', house_category_id,
        'house_category_name', house_category_name,
        'number_of_floor', number_of_floor,
        'build_year', build_year,
        'build_area', build_area,
        'total_floor_area', total_floor_area,
        'area', area,
        'working_office', working_office,
        'leasing', leasing,
        'house', house,
        'basis_of_business_activity', basis_of_business_activity,
        'vacant', vacant,
        'business', business,
        'joint_venture', joint_venture,
        'mix_using', mix_using,
        'occupied', occupied,
        'other', other,
        'orgprice_from_budget', orgprice_from_budget,
        'orgprice_from_other', orgprice_from_other
        )), ']') AS old_data
      FROM tbOldData
      GROUP BY voucher_id) AS A
      INNER JOIN (SELECT
          voucher_id,
          MAX(row_update) row_update,
          CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
          'orgprice_info', orgprice_info,
          'depreciation_amount', depreciation_amount,
          'depreciation_for_business_amount', depreciation_for_business_amount,
          'remaining_amount', remaining_amount,
          'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
          'depreciation_rate', depreciation_rate,
          'depreciation_year', depreciation_year,
          'remaining_number_of_year', remaining_number_of_year,
          'depreciation_for_business_price', depreciation_for_business_price,
          'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
          'depreciation_for_business_value', depreciation_for_business_value,
          'quantity', quantity,
          'house_category_id', house_category_id,
          'house_category_name', house_category_name,
          'number_of_floor', number_of_floor,
          'build_year', build_year,
          'build_area', build_area,
          'total_floor_area', total_floor_area,
          'area', area,
          'working_office', working_office,
          'leasing', leasing,
          'house', house,
          'basis_of_business_activity', basis_of_business_activity,
          'vacant', vacant,
          'business', business,
          'joint_venture', joint_venture,
          'mix_using', mix_using,
          'occupied', occupied,
          'other', other,
          'orgprice_from_budget', orgprice_from_budget,
          'orgprice_from_other', orgprice_from_other
          )), ']') AS new_data
        FROM tbNewData
        GROUP BY voucher_id) AS B
        ON A.voucher_id = B.voucher_id
      INNER JOIN (SELECT
          voucher_id,
          CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
          'orgprice_info', orgprice_info,
          'depreciation_amount', depreciation_amount,
          'depreciation_for_business_amount', depreciation_for_business_amount,
          'remaining_amount', remaining_amount,
          'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
          'depreciation_rate', depreciation_rate,
          'depreciation_year', depreciation_year,
          'remaining_number_of_year', remaining_number_of_year,
          'depreciation_for_business_price', depreciation_for_business_price,
          'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
          'depreciation_for_business_value', depreciation_for_business_value,
          'quantity', quantity,
          'house_category_id', house_category_id,
          'house_category_name', house_category_name,
          'number_of_floor', number_of_floor,
          'build_year', build_year,
          'build_area', build_area,
          'total_floor_area', total_floor_area,
          'area', area,
          'working_office', working_office,
          'leasing', leasing,
          'house', house,
          'basis_of_business_activity', basis_of_business_activity,
          'vacant', vacant,
          'business', business,
          'joint_venture', joint_venture,
          'mix_using', mix_using,
          'occupied', occupied,
          'other', other,
          'orgprice_from_budget', orgprice_from_budget,
          'orgprice_from_other', orgprice_from_other
          )), ']') AS change_data
        FROM tbChangeData
        GROUP BY voucher_id) AS C
        ON A.voucher_id = C.voucher_id) AS A
    ON far.voucher_id = A.voucher_id
  SET far.fixed_asset_revaluation_list = A.fixed_asset_revaluation_list,
      far.modified_by = 'admin'
  WHERE (row_update = 1
  OR row_update_new = 1)
  ;


  DROP TEMPORARY TABLE IF EXISTS tbFixedAsset;
  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetLedger;
  DROP TEMPORARY TABLE IF EXISTS tbBudget;
END;



