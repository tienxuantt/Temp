﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_Ledger_Revaluation_Standard_FA;

CREATE PROCEDURE Proc_Jira_Update_Ledger_Revaluation_Standard_FA(IN $FixedAssetID varchar(36))
BEGIN

  DECLARE $revaluation_type int DEFAULT 0;
  DECLARE $fixed_asset_type int DEFAULT 0;
  DECLARE $OrgPrice decimal(19, 4) DEFAULT 0;
  DECLARE $Accum decimal(19, 4) DEFAULT 0;
  DECLARE $Remaining decimal(19, 4) DEFAULT 0;

  SET group_concat_max_len = 18446744073709551615;

  -- Lấy ra loại tài sản tính hao mòn 
  SELECT fa.fixed_asset_type INTO $fixed_asset_type FROM fixed_asset fa WHERE fa.fixed_asset_id = $FixedAssetID LIMIT 1;

  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation AS
  SELECT
    r.orgprice,
    r.orgprice_info,
    r.orgprice_old,
    r.orgprice_info_old,
    fa.voucher_id,
    fa.fixed_asset_id,
    fa.fixed_asset_code,
    fa.organization_id,
    fa.fixed_asset_revaluation_list,
    fa.revaluation_type,
    fa.description,
    COALESCE(fa1.fixed_asset_type, 0) fixed_asset_type,
    if(fa.created_by LIKE '%thông tư%', 1, 0) AS create_by_TT
  FROM fixed_asset_revaluation fa
         INNER JOIN fixed_asset fa1
           ON fa.organization_id = fa1.organization_id
           AND fa.fixed_asset_id = fa1.fixed_asset_id,
       JSON_TABLE (fa.fixed_asset_revaluation_list,
       '$[*]'
       COLUMNS (
       orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
       orgprice_info text PATH '$.new_data[*].orgprice_info',
       orgprice_old decimal(19, 4) PATH '$.old_data[*].orgprice',
       orgprice_info_old text PATH '$.old_data[*].orgprice_info'
       )) AS r
  WHERE fa.modified_by NOT LIKE '%Proc_Standard_FA%' AND fa1.fixed_asset_type IN (2,3) AND fa.fixed_asset_id = $FixedAssetID;

  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation_JSON AS
  SELECT
    SUM(r.amount) amount,
    fa.voucher_id,
    fa.fixed_asset_id
  FROM tbFixedAssetRevaluation fa,
       JSON_TABLE (fa.orgprice_info,
       '$[*]'
       COLUMNS (
       budget_category_id varchar(36) PATH '$.budget_category_id',
       budget_category_code varchar(50) PATH '$.budget_category_code',
       budget_category_name varchar(500) PATH '$.budget_category_name',
       budget_type int PATH '$.budget_type',
       is_budget bit(1) PATH '$.is_budget',
       amount decimal(19, 4) PATH '$.amount',
       depreciation_for_business_price decimal(19, 4) PATH '$.depreciation_for_business_price'
       )) AS r
  GROUP BY fa.voucher_id,
           fa.fixed_asset_id;

  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON_old;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation_JSON_old AS
  SELECT
    SUM(r.amount) amount,
    fa.voucher_id,
    fa.fixed_asset_id
  FROM tbFixedAssetRevaluation fa,
       JSON_TABLE (fa.orgprice_info_old,
       '$[*]'
       COLUMNS (
       budget_category_id varchar(36) PATH '$.budget_category_id',
       budget_category_code varchar(50) PATH '$.budget_category_code',
       budget_category_name varchar(500) PATH '$.budget_category_name',
       budget_type int PATH '$.budget_type',
       is_budget bit(1) PATH '$.is_budget',
       amount decimal(19, 4) PATH '$.amount',
       depreciation_for_business_price decimal(19, 4) PATH '$.depreciation_for_business_price'
       )) AS r
  GROUP BY fa.voucher_id,
           fa.fixed_asset_id;

  DROP TEMPORARY TABLE IF EXISTS tbOldData;
  CREATE TEMPORARY TABLE tbOldData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    description text,
    fixed_asset_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbNewData;
  CREATE TEMPORARY TABLE tbNewData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    description text,
    fixed_asset_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbChangeData;
  CREATE TEMPORARY TABLE tbChangeData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  INSERT INTO tbOldData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      fa.description,
      fa.fixed_asset_type,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.old_data[*].orgprice',
         orgprice_info longtext PATH '$.old_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.old_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_amount',
         accum_depreciation_amount decimal(19, 4) PATH '$.old_data[*].accum_depreciation_amount',
         remaining_amount decimal(19, 4) PATH '$.old_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.old_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.old_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.old_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.old_data[*].quantity',
         house_category_id int PATH '$.old_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.old_data[*].house_category_name',
         number_of_floor float PATH '$.old_data[*].number_of_floor',
         build_year int PATH '$.old_data[*].build_year',
         build_area float PATH '$.old_data[*].build_area',
         total_floor_area float PATH '$.old_data[*].total_floor_area',
         area float PATH '$.old_data[*].area',
         working_office float PATH '$.old_data[*].working_office',
         leasing float PATH '$.old_data[*].leasing',
         house float PATH '$.old_data[*].house',
         basis_of_business_activity float PATH '$.old_data[*].basis_of_business_activity',
         vacant float PATH '$.old_data[*].vacant',
         business float PATH '$.old_data[*].business',
         joint_venture float PATH '$.old_data[*].joint_venture',
         mix_using float PATH '$.old_data[*].mix_using',
         occupied float PATH '$.old_data[*].occupied',
         other float PATH '$.old_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.old_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.old_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbNewData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      fa.description,
      fa.fixed_asset_type,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
         orgprice_info longtext PATH '$.new_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.new_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_amount',
         accum_depreciation_amount decimal(19, 4) PATH '$.new_data[*].accum_depreciation_amount',
         remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.new_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.new_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.new_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.new_data[*].quantity',
         house_category_id int PATH '$.new_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.new_data[*].house_category_name',
         number_of_floor float PATH '$.new_data[*].number_of_floor',
         build_year int PATH '$.new_data[*].build_year',
         build_area float PATH '$.new_data[*].build_area',
         total_floor_area float PATH '$.new_data[*].total_floor_area',
         area float PATH '$.new_data[*].area',
         working_office float PATH '$.new_data[*].working_office',
         leasing float PATH '$.new_data[*].leasing',
         house float PATH '$.new_data[*].house',
         basis_of_business_activity float PATH '$.new_data[*].basis_of_business_activity',
         vacant float PATH '$.new_data[*].vacant',
         business float PATH '$.new_data[*].business',
         joint_venture float PATH '$.new_data[*].joint_venture',
         mix_using float PATH '$.new_data[*].mix_using',
         occupied float PATH '$.new_data[*].occupied',
         other float PATH '$.new_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.new_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.new_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbChangeData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.change_data[*].orgprice',
         orgprice_info longtext PATH '$.change_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.change_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_amount',
         accum_depreciation_amount decimal(19, 4) PATH '$.change_data[*].accum_depreciation_amount',
         remaining_amount decimal(19, 4) PATH '$.change_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.change_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.change_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.change_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.change_data[*].quantity',
         house_category_id int PATH '$.change_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.change_data[*].house_category_name',
         number_of_floor float PATH '$.change_data[*].number_of_floor',
         build_year int PATH '$.change_data[*].build_year',
         build_area float PATH '$.change_data[*].build_area',
         total_floor_area float PATH '$.change_data[*].total_floor_area',
         area float PATH '$.change_data[*].area',
         working_office float PATH '$.change_data[*].working_office',
         leasing float PATH '$.change_data[*].leasing',
         house float PATH '$.change_data[*].house',
         basis_of_business_activity float PATH '$.change_data[*].basis_of_business_activity',
         vacant float PATH '$.change_data[*].vacant',
         business float PATH '$.change_data[*].business',
         joint_venture float PATH '$.change_data[*].joint_venture',
         mix_using float PATH '$.change_data[*].mix_using',
         occupied float PATH '$.change_data[*].occupied',
         other float PATH '$.change_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.change_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.change_data[*].orgprice_from_other'
         )) AS r;

  UPDATE tbNewData A
  INNER JOIN tbFixedAssetRevaluation far
  ON A.voucher_id = far.voucher_id AND A.fixed_asset_id = far.fixed_asset_id
  INNER JOIN tbFixedAssetRevaluation_JSON B
    ON A.voucher_id = B.voucher_id
    AND A.fixed_asset_id = B.fixed_asset_id
  SET A.orgprice = IFNULL(B.amount, 0),
        A.depreciation_amount = 
         ( CASE WHEN far.fixed_asset_type = 1 THEN  IFNULL(A.depreciation_amount,0)
                     WHEN far.fixed_asset_type = 2 THEN  0
                     WHEN far.fixed_asset_type = 3 THEN  IFNULL(A.depreciation_amount,0) - IFNULL(A.depreciation_for_business_amount,0)
                     ELSE A.depreciation_amount
          END),
        A.depreciation_for_business_amount = 
          CASE WHEN far.fixed_asset_type = 1 THEN 0 
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 1 THEN IFNULL(A.depreciation_for_business_amount,0) 
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 0 THEN  IFNULL(A.depreciation_amount,0)
                     WHEN far.fixed_asset_type = 3 THEN  IF(IFNULL(A.depreciation_amount,0) - IFNULL(A.depreciation_for_business_amount,0) < 0, 0, A.depreciation_amount) - IFNULL(A.depreciation_for_business_amount,0)   
                     ELSE A.depreciation_for_business_amount
          END,
        A.accum_depreciation_amount = 
          CASE WHEN far.fixed_asset_type IN (1,3) THEN  IFNULL(A.depreciation_amount, 0) 
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 1 THEN  IFNULL(A.depreciation_for_business_amount,0)
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 0 THEN  IFNULL(A.depreciation_amount,0)
                     ELSE A.accum_depreciation_amount
          END,
        A.remaining_amount = IFNULL(B.amount, 0) - IFNULL(A.depreciation_amount, 0),
        A.row_update = 1;

    -- Tính lại giá trị còn lại
    UPDATE tbNewData A
    SET A.remaining_amount = A.orgprice - A.accum_depreciation_amount,
            A.depreciation_amount = if(A.accum_depreciation_amount = 0, 0, A.depreciation_amount),
            A.depreciation_for_business_amount = if(A.accum_depreciation_amount = 0, 0, A.depreciation_for_business_amount);

  UPDATE tbOldData A
  INNER JOIN tbFixedAssetRevaluation far
  ON A.voucher_id = far.voucher_id AND A.fixed_asset_id = far.fixed_asset_id
  INNER JOIN tbFixedAssetRevaluation_JSON_old B
    ON A.voucher_id = B.voucher_id
    AND A.fixed_asset_id = B.fixed_asset_id
  SET A.orgprice = IFNULL(B.amount, 0),
      A.depreciation_amount = 
          CASE WHEN far.fixed_asset_type = 1 THEN  IFNULL(A.depreciation_amount,0)
                     WHEN far.fixed_asset_type = 2 THEN  0
                     WHEN far.fixed_asset_type = 3 THEN  IFNULL(A.depreciation_amount,0) - IFNULL(A.depreciation_for_business_amount,0)
                     ELSE A.depreciation_amount
          END,
     A.depreciation_for_business_amount = 
          CASE WHEN far.fixed_asset_type = 1 THEN 0 
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 1 THEN   IFNULL(A.depreciation_for_business_amount,0)
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 0 THEN  IFNULL(A.depreciation_amount,0)
                     WHEN far.fixed_asset_type = 3 THEN  if(IFNULL(A.depreciation_amount,0) - IFNULL(A.depreciation_for_business_amount,0) < 0, 0, A.depreciation_amount) - IFNULL(A.depreciation_for_business_amount,0)
                     ELSE A.depreciation_for_business_amount
          END,
    A.accum_depreciation_amount = 
          CASE WHEN far.fixed_asset_type IN (1,3) THEN  IFNULL(A.depreciation_amount, 0) 
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 1 THEN  IFNULL(A.depreciation_for_business_amount,0)
                     WHEN far.fixed_asset_type = 2 AND far.create_by_TT = 0 THEN  IFNULL(A.depreciation_amount,0)
                     ELSE A.accum_depreciation_amount
          END,
      A.remaining_amount = IFNULL(B.amount, 0) - IFNULL(A.depreciation_amount, 0),
      A.row_update = 1;

    -- Tính lại giá trị còn lại
    UPDATE tbOldData A
    SET A.remaining_amount = A.orgprice - A.accum_depreciation_amount,
            A.depreciation_amount = if(A.accum_depreciation_amount = 0, 0, A.depreciation_amount),
            A.depreciation_for_business_amount = if(A.accum_depreciation_amount = 0, 0, A.depreciation_for_business_amount);

  UPDATE tbChangeData a
  INNER JOIN tbNewData b
    ON a.voucher_id = b.voucher_id
    AND a.fixed_asset_id = b.fixed_asset_id
  INNER JOIN tbOldData c
    ON a.voucher_id = c.voucher_id
    AND a.fixed_asset_id = c.fixed_asset_id
  SET a.orgprice = COALESCE(b.orgprice, 0) - COALESCE(c.orgprice, 0),
      a.remaining_amount = COALESCE(b.remaining_amount, 0) - COALESCE(c.remaining_amount, 0),
      a.depreciation_amount = COALESCE(b.depreciation_amount, 0) - COALESCE(c.depreciation_amount, 0),
      a.depreciation_for_business_amount = COALESCE(b.depreciation_for_business_amount, 0) - COALESCE(c.depreciation_for_business_amount, 0),
      a.accum_depreciation_amount = COALESCE(b.accum_depreciation_amount, 0) - COALESCE(c.accum_depreciation_amount, 0),
      a.depreciation_for_business_price = COALESCE(b.depreciation_for_business_price, 0) - COALESCE(c.depreciation_for_business_price, 0),
      a.row_update = 1
  WHERE (b.row_update = 1
  OR c.row_update = 1);

  UPDATE fixed_asset_revaluation far
  INNER JOIN (SELECT
      A.fixed_asset_id,
      A.voucher_id,
      B.row_update,
      CONCAT('[{"old_data":', A.old_data, ',"new_data":', B.new_data, ',"change_data":', C.change_data, '}]') AS fixed_asset_revaluation_list
    FROM (SELECT
        voucher_id,
        fixed_asset_id,
        CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
        'orgprice_info', orgprice_info,
        'depreciation_amount', depreciation_amount,
        'depreciation_for_business_amount', depreciation_for_business_amount,
        'accum_depreciation_amount', accum_depreciation_amount,
        'remaining_amount', remaining_amount,
        'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
        'depreciation_rate', depreciation_rate,
        'depreciation_year', depreciation_year,
        'remaining_number_of_year', remaining_number_of_year,
        'depreciation_for_business_price', depreciation_for_business_price,
        'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
        'depreciation_for_business_value', depreciation_for_business_value,
        'quantity', quantity,
        'house_category_id', house_category_id,
        'house_category_name', house_category_name,
        'number_of_floor', number_of_floor,
        'build_year', build_year,
        'build_area', build_area,
        'total_floor_area', total_floor_area,
        'area', area,
        'working_office', working_office,
        'leasing', leasing,
        'house', house,
        'basis_of_business_activity', basis_of_business_activity,
        'vacant', vacant,
        'business', business,
        'joint_venture', joint_venture,
        'mix_using', mix_using,
        'occupied', occupied,
        'other', other,
        'orgprice_from_budget', orgprice_from_budget,
        'orgprice_from_other', orgprice_from_other)), ']') AS old_data
      FROM tbOldData
      GROUP BY voucher_id,
               fixed_asset_id) AS A
      INNER JOIN (SELECT
          voucher_id,
          fixed_asset_id,
          MAX(row_update) AS row_update,
          CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
          'orgprice_info', orgprice_info,
          'depreciation_amount', depreciation_amount,
          'depreciation_for_business_amount', depreciation_for_business_amount,
          'accum_depreciation_amount', accum_depreciation_amount,
          'remaining_amount', remaining_amount,
          'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
          'depreciation_rate', depreciation_rate,
          'depreciation_year', depreciation_year,
          'remaining_number_of_year', remaining_number_of_year,
          'depreciation_for_business_price', depreciation_for_business_price,
          'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
          'depreciation_for_business_value', depreciation_for_business_value,
          'quantity', quantity,
          'house_category_id', house_category_id,
          'house_category_name', house_category_name,
          'number_of_floor', number_of_floor,
          'build_year', build_year,
          'build_area', build_area,
          'total_floor_area', total_floor_area,
          'area', area,
          'working_office', working_office,
          'leasing', leasing,
          'house', house,
          'basis_of_business_activity', basis_of_business_activity,
          'vacant', vacant,
          'business', business,
          'joint_venture', joint_venture,
          'mix_using', mix_using,
          'occupied', occupied,
          'other', other,
          'orgprice_from_budget', orgprice_from_budget,
          'orgprice_from_other', orgprice_from_other)), ']') AS new_data
        FROM tbNewData
        GROUP BY voucher_id,
                 fixed_asset_id) AS B
        ON A.voucher_id = B.voucher_id
        AND A.fixed_asset_id = B.fixed_asset_id
      INNER JOIN (SELECT
          voucher_id,
          fixed_asset_id,
          CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
          'orgprice_info', orgprice_info,
          'depreciation_amount', depreciation_amount,
          'depreciation_for_business_amount', depreciation_for_business_amount,
          'accum_depreciation_amount', accum_depreciation_amount,
          'remaining_amount', remaining_amount,
          'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
          'depreciation_rate', depreciation_rate,
          'depreciation_year', depreciation_year,
          'remaining_number_of_year', remaining_number_of_year,
          'depreciation_for_business_price', depreciation_for_business_price,
          'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
          'depreciation_for_business_value', depreciation_for_business_value,
          'quantity', quantity,
          'house_category_id', house_category_id,
          'house_category_name', house_category_name,
          'number_of_floor', number_of_floor,
          'build_year', build_year,
          'build_area', build_area,
          'total_floor_area', total_floor_area,
          'area', area,
          'working_office', working_office,
          'leasing', leasing,
          'house', house,
          'basis_of_business_activity', basis_of_business_activity,
          'vacant', vacant,
          'business', business,
          'joint_venture', joint_venture,
          'mix_using', mix_using,
          'occupied', occupied,
          'other', other,
          'orgprice_from_budget', orgprice_from_budget,
          'orgprice_from_other', orgprice_from_other)), ']') AS change_data
        FROM tbChangeData
        GROUP BY voucher_id,
                 fixed_asset_id) AS C
        ON A.voucher_id = C.voucher_id
        AND A.fixed_asset_id = C.fixed_asset_id) AS A
    ON far.voucher_id = A.voucher_id
    AND A.fixed_asset_id = far.fixed_asset_id
  SET far.fixed_asset_revaluation_list = A.fixed_asset_revaluation_list,
      far.modified_by = 'Proc_Standard_FA';

  UPDATE fixed_asset_ledger fal
  INNER JOIN tbNewData nd
    ON nd.voucher_id = fal.voucher_id
    AND nd.fixed_asset_id = fal.fixed_asset_id
    AND nd.row_update = 1
  SET fal.orgprice = nd.orgprice,
      fal.depreciation_amount =  IFNULL(nd.depreciation_amount, 0) ,
      fal.depreciation_for_business_amount =  IFNULL(nd.depreciation_for_business_amount, 0),
      fal.accum_depreciation_amount = IFNULL(nd.accum_depreciation_amount, 0),
      fal.remaining_amount = IFNULL(nd.remaining_amount, 0),
      fal.depreciation_for_business_price = nd.depreciation_for_business_price,
      fal.depreciation_value = 0,
      fal.depreciation_for_business_value = 0
   WHERE fal.voucher_type = 2;

  UPDATE fixed_asset_ledger fal
  INNER JOIN tbChangeData nd
    ON nd.voucher_id = fal.voucher_id
    AND nd.fixed_asset_id = fal.fixed_asset_id
  SET fal.difference_orgprice = nd.orgprice,
      fal.difference_quantity = nd.quantity,
      fal.difference_remaining_amount = nd.remaining_amount,
      fal.difference_depreciation_amount = IFNULL(nd.depreciation_amount, 0),
      fal.difference_depreciation_for_business_amount = IFNULL(nd.depreciation_for_business_amount, 0)
   WHERE fal.voucher_type = 2;

   CALL Proc_Jira_ReCallUpdateFAData($FixedAssetID);

  DROP TEMPORARY TABLE IF EXISTS tbFixedAsset;
  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetLedger;
  DROP TEMPORARY TABLE IF EXISTS tbBudget;
  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON;
  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON_old;
END;

SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_ReCallUpdateFAData;

CREATE PROCEDURE Proc_Jira_ReCallUpdateFAData (IN $fixed_asset_id varchar(36))
SQL SECURITY INVOKER
BEGIN
  DECLARE $i int DEFAULT 0;
  DECLARE $count int DEFAULT 0;
  DECLARE $organCode varchar(100) DEFAULT '';
  DECLARE $fixedAssetCode varchar(100) DEFAULT '';
  DECLARE $orgprice decimal(19, 4) DEFAULT 0;
  DECLARE $accum decimal(19, 4) DEFAULT 0;
  DECLARE $fixed_asset_type int DEFAULT 0;
  DECLARE $depreciation_amount decimal(19, 4) DEFAULT 0;
  DECLARE $depreciation_for_business_amount decimal(19, 4) DEFAULT 0;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;
  CREATE TEMPORARY TABLE tbOrganizationFA (
    fixed_asset_id varchar(36)
  );

  IF ($fixed_asset_id IS NULL) THEN
  BEGIN
    INSERT tbOrganizationFA
      SELECT
        fixed_asset_id
      FROM tempReCallUpdateFAData;
  END;
  END IF;

  IF ($fixed_asset_id IS NOT NULL) THEN
  BEGIN
    INSERT tbOrganizationFA
      VALUES ($fixed_asset_id);
  END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemFA;
  CREATE TEMPORARY TABLE tbOrganizationTemFA
  SELECT
    do.organization_code,
    fa.fixed_asset_code,
    fal.orgprice,
    fal.accum_depreciation_amount,
    fal.depreciation_amount,
    fal.depreciation_for_business_amount,
    fa.fixed_asset_type
  FROM tbOrganizationFA A
    INNER JOIN fixed_asset fa
      ON A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN dic_organization do
      ON fa.organization_id = do.organization_id
    INNER JOIN fixed_asset_ledger fal
      ON fal.voucher_type IN (1, 8)
      AND fal.organization_id = do.organization_id
      AND A.fixed_asset_id = fal.fixed_asset_id;

  SELECT
    COUNT(1) INTO $count
  FROM tbOrganizationTemFA;

  WHILE $i < $count DO
    SELECT
      organization_code,
      fixed_asset_code,
      orgprice,
      accum_depreciation_amount,
      fixed_asset_type,
      depreciation_amount,
      depreciation_for_business_amount INTO $organCode, $fixedAssetCode, $orgprice, $accum, $fixed_asset_type, $depreciation_amount, $depreciation_for_business_amount
    FROM tbOrganizationTemFA
    LIMIT $i, 1;

                IF ($fixed_asset_type = 3) THEN
                        CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL($organCode, $fixedAssetCode, IFNULL($orgprice, 0), IFNULL($depreciation_amount, 0), IFNULL($depreciation_for_business_amount, 0));
                ELSE
                        CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT($organCode, $fixedAssetCode, IFNULL($orgprice, 0), IFNULL($accum, 0));
                end if;

    SET $i = $i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemFA;
  DROP TEMPORARY TABLE IF EXISTS tempReCallUpdateFAData;

END;

DROP PROCEDURE IF EXISTS Proc_Jira_Update_Depreciation_FixedAsset_From_GT;

CREATE PROCEDURE Proc_Jira_Update_Depreciation_FixedAsset_From_GT(IN $Organ_Code varchar(100), IN $FA_Code varchar(100), IN $OrgPrice decimal(19, 4), IN $AccumDepreciationAmount decimal(19, 4))
SQL SECURITY INVOKER
BEGIN
  DECLARE $Count int DEFAULT 0;
  DECLARE $i int DEFAULT 1;
  DECLARE $STT_GT int DEFAULT 100;
  DECLARE $VoucherType int DEFAULT 0;
  DECLARE $OrgpriceFA decimal(19, 4) DEFAULT 0;
  DECLARE $SumBudget decimal(19, 4) DEFAULT 0;
  DECLARE $LedgerBudgetID varchar(36);
  DECLARE $OrganizationID varchar(36);
  DECLARE $FixedAssetID varchar(36);
  DECLARE $MESSAGE_TEXT varchar(500);

  -- Xu ly exception
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
      GET DIAGNOSTICS CONDITION 1 $MESSAGE_TEXT = MESSAGE_TEXT;
      SELECT CONCAT('MySQL ERROR: ', $MESSAGE_TEXT) AS Data;

      ROLLBACK;   
  END;

  START TRANSACTION;
 
  SET $OrganizationID = (SELECT do.organization_id FROM dic_organization do WHERE do.organization_code = $Organ_Code LIMIT 1);
  SET $FixedAssetID = (SELECT fa.fixed_asset_id FROM fixed_asset fa WHERE fa.organization_id = $OrganizationID AND fa.fixed_asset_code = $FA_Code LIMIT 1);

  -- Các dánh giá l?i do chuy?n d?i thông tu
  DROP TEMPORARY TABLE IF EXISTS tbLedgerRevaluationCircular;
  CREATE TEMPORARY TABLE tbLedgerRevaluationCircular
  SELECT cch.organization_id, cch.fixed_asset_id, cch.fixed_asset_revaluation_id AS voucher_id
  FROM convert_circular_history cch
  WHERE cch.organization_id = $OrganizationID AND cch.fixed_asset_id = $FixedAssetID;

  -- Các ban ghi chuyen loai
  DROP TEMPORARY TABLE IF EXISTS tbChangeInfor;
  CREATE TEMPORARY TABLE tbChangeInfor
  SELECT cch.organization_id, cch.fixed_asset_id, cch.change_category_id AS voucher_id
  FROM fixed_asset_change_category cch
  WHERE cch.organization_id = $OrganizationID AND cch.fixed_asset_id = $FixedAssetID;

  DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
  CREATE TEMPORARY TABLE tbUpdateData (
    STT int,
    fixed_asset_ledger_id bigint,
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    voucher_code varchar(100),
    voucher_type int,
    change_date datetime,
    orgprice decimal(19, 4),
    voucher_price decimal(19, 4),
    depreciation_value decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData2;
  CREATE TEMPORARY TABLE tbOrginData2
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT
  FROM (SELECT
      lg.fixed_asset_ledger_id,
      lg.fixed_asset_id,
      lg.voucher_id,
      lg.voucher_code,
      lg.voucher_type,
      lg.change_date,
      lg.created_date,
      lg.orgprice,
      CASE WHEN lg.voucher_type = 9 THEN IFNULL(lg.depreciation_for_business_value, 0) ELSE IF(lg.voucher_type = 5, IFNULL(lg.depreciation_value, 0), 0) END AS voucher_price,
      CASE WHEN lg.voucher_type = 9 THEN IFNULL(lg.depreciation_for_business_value, 0) ELSE IF(lg.voucher_type = 5, IFNULL(lg.depreciation_value, 0), 0) END AS depreciation_value,
      if(lg.voucher_type <> 2, lg.accum_depreciation_amount, IFNULL(lg.depreciation_amount,0) + IFNULL(lg.depreciation_for_business_amount,0)) AS accum_depreciation_amount,
      lg.remaining_amount
    FROM fixed_asset_ledger lg
    LEFT JOIN tbLedgerRevaluationCircular re ON lg.organization_id = re.organization_id AND lg.voucher_id = re.voucher_id AND lg.fixed_asset_id = re.fixed_asset_id
    LEFT JOIN tbChangeInfor CI ON lg.organization_id = CI.organization_id AND lg.voucher_id = CI.voucher_id AND lg.fixed_asset_id = CI.fixed_asset_id
    WHERE re.fixed_asset_id IS NULL 
    AND lg.organization_id = $OrganizationID
    AND lg.fixed_asset_id = $FixedAssetID
    AND (lg.voucher_type <> 17 OR CI.organization_id IS NOT NULL)
    UNION ALL
    SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      depreciation_value AS voucher_price,
      depreciation_value,
      accum_depreciation_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID) A;

    SET $STT_GT = (SELECT STT FROM tbOrginData2 WHERE voucher_type in (1,8) ORDER BY STT LIMIT 1);

   -- Xóa b? ch?ng t? tru?c ghi tang
   DELETE FROM  tbOrginData2 WHERE STT <  $STT_GT;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData;
  CREATE TEMPORARY TABLE tbOrginData
  SELECT
    A.fixed_asset_ledger_id,
    A.fixed_asset_id,
    A.voucher_id,
    A.voucher_code,
    A.voucher_type,
    A.change_date,
    A.created_date,
    A.orgprice,
    A.voucher_price,
    A.depreciation_value,
    A.accum_depreciation_amount,
    A.remaining_amount,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT 
    FROM tbOrginData2 A;

IF EXISTS (SELECT 1 FROM tbOrginData od WHERE od.voucher_type in (1,8) AND od.STT = 1) THEN
BEGIN

    SELECT
    COUNT(1) INTO $Count
    FROM tbOrginData;

  WHILE $i <= $Count DO

    IF $i = 1 THEN
      INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
        SELECT
          STT,
          fixed_asset_ledger_id,
          fixed_asset_id,
          voucher_id,
          voucher_code,
          voucher_type,
          change_date,
          $OrgPrice as orgprice,
          voucher_price,
          depreciation_value,
          $AccumDepreciationAmount AS accum_depreciation_amount,
          IFNULL($OrgPrice, 0) - $AccumDepreciationAmount AS remaining_amount
        FROM tbOrginData
        WHERE STT = $i;

      IF $i = $Count THEN

        -- C?p nh?t tài s?n
        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.accum_depreciation_amount,
            A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
            A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID;

        -- C?p nh?t detail ghi tang
        UPDATE fixed_asset_increment_detail A
        INNER JOIN fixed_asset fa on A.organization_id = fa.organization_id and A.fixed_asset_id = fa.fixed_asset_id
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice
        WHERE A.organization_id = $OrganizationID;
      END IF;

    ELSE
      DROP TEMPORARY TABLE IF EXISTS tbCacheData;
      CREATE TEMPORARY TABLE tbCacheData
      SELECT
        *
      FROM tbUpdateData
      WHERE STT = $i - 1;

      SELECT
        voucher_type INTO $VoucherType
      FROM tbOrginData
      WHERE STT = $i;

      IF ($VoucherType IN (2, 10, 17)) THEN
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            IF($VoucherType IN (17, 10), B.orgprice, A.orgprice) AS orgprice,
            A.voucher_price,
            0 AS depreciation_value,
            IF($VoucherType IN (17, 10), B.accum_depreciation_amount, A.accum_depreciation_amount),
            IF($VoucherType IN (17, 10), B.remaining_amount, IFNULL(A.orgprice, 0) - IFNULL(A.accum_depreciation_amount, 0)) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      ELSE
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            B.orgprice,
            A.voucher_price,
            A.depreciation_value,
            IFNULL(B.accum_depreciation_amount, 0) + IFNULL(A.depreciation_value, 0) AS accum_depreciation_amount,
            IFNULL(B.remaining_amount, 0) - IFNULL(A.depreciation_value, 0) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      END IF;

      IF $i = $Count THEN

        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B
          ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.accum_depreciation_amount,
            A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
            A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID
        AND B.STT = $Count;

      END IF;
    END IF;

    SET $i = $i + 1;
    SET $VoucherType = 0;
  END WHILE;

  -- C?p nh?t ledger to
  UPDATE fixed_asset_ledger A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type <> 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN IF(A.voucher_type = 2, A.depreciation_amount, B.accum_depreciation_amount )  WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN IF(A.voucher_type = 2, A.depreciation_for_business_amount, B.accum_depreciation_amount ) WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount
  WHERE A.organization_id = $OrganizationID;


  -- C?p nh?t ledger hao mòn, kh?u hao
  UPDATE fa_ledger_depreciation A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (5, 9)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount
  WHERE A.organization_id = $OrganizationID;

  -- C?p nh?t ledger ghi tang, gi?m
  UPDATE fa_ledger_increment_and_decrement A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (1, 8, 6)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount
  WHERE A.organization_id = $OrganizationID;

  -- C?p nh?t ledger ki?m kê
  UPDATE fa_ledger_inventory A
  INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.inventory_orgprice = IFNULL(B.orgprice,0) - IFNULL(A.difference_orgprice,0),
      A.inventory_remaining_amount = IFNULL(B.remaining_amount,0) - IFNULL(A.difference_remaining_amount,0),
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
  WHERE A.organization_id = $OrganizationID;

    -- Detail ghi tang
    UPDATE fixed_asset_increment_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 1) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Hao mon
    UPDATE fixed_asset_depreciation_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 5) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail KH
    UPDATE fixed_asset_depreciation_business_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 9) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_remaining_amount =  IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Ghi giam
    UPDATE fixed_asset_decrement_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 6) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN fa.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 2 THEN 0 WHEN fa.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN fa.fixed_asset_type = 1 THEN 0 WHEN fa.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;      

  -- L?y nguyên giá c?a tài s?n
  set $OrgpriceFA = (SELECT orgprice FROM fixed_asset fa WHERE fa.fixed_asset_id = $FixedAssetID);

  -- Ledger budget c?a tài s?n
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
  CREATE TEMPORARY TABLE tbLedgerBudgetFA
  SELECT lb.*
  FROM ledger_budget lb 
  INNER JOIN
  (
    SELECT * FROM
    (
      SELECT l.fixed_asset_id, IFNULL(l.voucher_id, '') AS voucher_id,
      ROW_NUMBER() OVER(PARTITION BY fixed_asset_id ORDER BY change_date DESC, created_date DESC) AS STT
      FROM ledger_budget l
      WHERE l.fixed_asset_id = $FixedAssetID AND IFNULL(voucher_type, 1) IN (1,2,8)
    ) A WHERE A.STT = 1
  ) A2 ON lb.fixed_asset_id = A2.fixed_asset_id AND IFNULL(lb.voucher_id, '') = A2.voucher_id;

  -- N?u nguyên giá khác v?i t?ng trong ledger budget thì c?p nh?t l?i
  IF (select SUM(amount) FROM tbLedgerBudgetFA) <> $OrgpriceFA THEN
      BEGIN

                 -- C?p nh?t d?i v?i tru?ng h?p ch? có m?t ngu?n
                 IF (SELECT count(*) FROM tbLedgerBudgetFA) = 1 THEN
                 BEGIN
                    UPDATE  tbLedgerBudgetFA set amount = $OrgpriceFA;

                    UPDATE ledger_budget lb 
                    INNER JOIN tbLedgerBudgetFA lbf ON lb.organization_id = lbf.organization_id AND lb.ledger_budget_id = lbf.ledger_budget_id
                    set lb.amount = lbf.amount;
                 END;
                 END IF;

                -- Tru?ng h?p có nhi?u ngu?n
                IF (SELECT count(*) FROM tbLedgerBudgetFA) > 1 THEN
                 BEGIN
                    SET $LedgerBudgetID = (SELECT ledger_budget_id FROM tbLedgerBudgetFA ORDER BY amount DESC LIMIT 1);

                    SET $SumBudget =  (SELECT sum(amount) FROM tbLedgerBudgetFA WHERE ledger_budget_id <> $LedgerBudgetID);

                    UPDATE ledger_budget lb 
                    set lb.amount = ifnull($OrgpriceFA,0) - ifnull($SumBudget,0)
                    WHERE lb.ledger_budget_id =  $LedgerBudgetID;

                 END;
                 END IF;
                 
      END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbCacheData;
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
  
END; 
END IF;
  
DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData2;
DROP TEMPORARY TABLE IF EXISTS tbLedgerRevaluationCircular;
DROP TEMPORARY TABLE IF EXISTS tbChangeInfor;

COMMIT;

END;

SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL;

CREATE PROCEDURE Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL
(
IN $Organ_Code varchar(36), 
IN $FA_Code varchar(36), 
IN $OrgPrice decimal(19, 4), 
IN $DepreciationAmount decimal(19, 4), 
IN $DepreciationBusinessAmount decimal(19, 4)
)
  SQL SECURITY INVOKER
BEGIN
  DECLARE $Count int DEFAULT 0;
  DECLARE $i int DEFAULT 1;
  DECLARE $STT_GT int DEFAULT 100;
  DECLARE $VoucherType int DEFAULT 0;
  DECLARE $OrgpriceFA decimal(19, 4) DEFAULT 0;
  DECLARE $SumBudget decimal(19, 4) DEFAULT 0;
  DECLARE $LedgerBudgetID varchar(36);
  DECLARE $OrganizationID varchar(36);
  DECLARE $FixedAssetID varchar(36);
  DECLARE $FixedAssetType int;

  SET $OrganizationID = (SELECT do.organization_id FROM dic_organization do WHERE do.organization_code = $Organ_Code LIMIT 1);

  SELECT fa.fixed_asset_id, IFNULL(fa.fixed_asset_type, 1) 
  FROM fixed_asset fa 
  WHERE fa.organization_id = $OrganizationID AND fa.fixed_asset_code = $FA_Code LIMIT 1 
  INTO $FixedAssetID, $FixedAssetType;

  SET $DepreciationAmount = CASE WHEN $FixedAssetType = 2 THEN 0 ELSE $DepreciationAmount END;
  SET $DepreciationBusinessAmount = CASE WHEN $FixedAssetType = 1 THEN 0 ELSE $DepreciationBusinessAmount END;

  DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
  CREATE TEMPORARY TABLE tbUpdateData (
    STT int,
    fixed_asset_ledger_id bigint,
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    voucher_code varchar(100),
    voucher_type int,
    change_date datetime,
    orgprice decimal(19, 4),
    depreciation_value decimal(19, 4),
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData2;
  CREATE TEMPORARY TABLE tbOrginData2
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT
  FROM (SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      if(voucher_type <> 2, accum_depreciation_amount, IFNULL(depreciation_amount,0) + IFNULL(depreciation_for_business_amount,0)) AS accum_depreciation_amount,
      CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS depreciation_value,
      CASE WHEN $FixedAssetType = 1 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_amount ELSE 0 END AS depreciation_amount,
      CASE WHEN $FixedAssetType = 2 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_for_business_amount ELSE 0 END AS depreciation_for_business_amount,
      remaining_amount
    FROM fixed_asset_ledger
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID
    AND  (voucher_type <> 17 OR (voucher_type = 17 AND voucher_description LIKE '%chuy?n lo?i%'))
    UNION ALL
    SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      0 AS depreciation_value,
      CASE WHEN $FixedAssetType = 1 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_amount ELSE 0 END AS depreciation_amount,
      CASE WHEN $FixedAssetType = 2 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_for_business_amount ELSE 0 END AS depreciation_for_business_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID) A;

    SET $STT_GT = (SELECT STT FROM tbOrginData2 WHERE voucher_type in (1,8) ORDER BY STT LIMIT 1);

   -- Xóa b? ch?ng t? tru?c ghi tang
   DELETE FROM  tbOrginData2 WHERE STT <  $STT_GT;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData;
  CREATE TEMPORARY TABLE tbOrginData
  SELECT
    A.fixed_asset_ledger_id,
    A.fixed_asset_id,
    A.voucher_id,
    A.voucher_code,
    A.voucher_type,
    A.change_date,
    A.created_date,
    A.orgprice,
    A.depreciation_value,
    A.accum_depreciation_amount,
    A.depreciation_amount,
    A.depreciation_for_business_amount,
    A.remaining_amount,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT 
    FROM tbOrginData2 A;

IF EXISTS (SELECT 1 FROM tbOrginData od WHERE od.voucher_type in (1,8) AND od.STT = 1) AND $FixedAssetType = 3 THEN
BEGIN

    SELECT
    COUNT(1) INTO $Count
    FROM tbOrginData;

  WHILE $i <= $Count DO

    IF $i = 1 THEN
      INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, depreciation_value, depreciation_amount, depreciation_for_business_amount, remaining_amount)
        SELECT
          STT,
          fixed_asset_ledger_id,
          fixed_asset_id,
          voucher_id,
          voucher_code,
          voucher_type,
          change_date,
          $OrgPrice as orgprice,
          depreciation_value,
          IFNULL($DepreciationAmount, 0) AS depreciation_amount,
          IFNULL($DepreciationBusinessAmount, 0) AS depreciation_for_business_amount,
          IFNULL($OrgPrice, 0) - IFNULL($DepreciationAmount, 0) - IFNULL($DepreciationBusinessAmount, 0) AS remaining_amount
        FROM tbOrginData
        WHERE STT = $i;

      IF $i = $Count THEN

        -- C?p nh?t tài s?n
        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
            A.depreciation_amount = B.depreciation_amount,
            A.depreciation_for_business_amount = B.depreciation_for_business_amount,
            A.remaining_amount = B.remaining_amount,
            A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(A.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
        WHERE A.organization_id = $OrganizationID;

        -- C?p nh?t detail ghi tang
        UPDATE fixed_asset_increment_detail A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
            A.depreciation_amount = B.depreciation_amount,
            A.depreciation_for_business_amount = B.depreciation_for_business_amount,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID;
      END IF;

    ELSE
      DROP TEMPORARY TABLE IF EXISTS tbCacheData;
      CREATE TEMPORARY TABLE tbCacheData
      SELECT
        *
      FROM tbUpdateData
      WHERE STT = $i - 1;

      SELECT
        voucher_type INTO $VoucherType
      FROM tbOrginData
      WHERE STT = $i;

      IF ($VoucherType IN (2, 10, 17)) THEN
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, depreciation_value, depreciation_amount, depreciation_for_business_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            IF($VoucherType  IN (17, 10), B.orgprice, A.orgprice) AS orgprice,
            0 AS depreciation_value,
            IF($VoucherType IN (17, 10), B.depreciation_amount, ifnull(A.accum_depreciation_amount,0) - ifnull(A.depreciation_for_business_amount,0)) AS depreciation_amount,
            IF($VoucherType IN (17, 10), B.depreciation_for_business_amount, A.depreciation_for_business_amount) AS depreciation_for_business_amount,
            IF($VoucherType  IN (17, 10), B.remaining_amount, IFNULL(A.remaining_amount, 0)) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      ELSE
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, depreciation_value, depreciation_amount, depreciation_for_business_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            B.orgprice,
            A.depreciation_value,
            IF($VoucherType = 5, IFNULL(B.depreciation_amount, 0) + IFNULL(A.depreciation_value, 0), IFNULL(B.depreciation_amount, 0)) AS depreciation_amount,
            IF($VoucherType = 9, IFNULL(B.depreciation_for_business_amount, 0) + IFNULL(A.depreciation_value, 0), IFNULL(B.depreciation_for_business_amount, 0)) AS depreciation_for_business_amount,
            IFNULL(B.remaining_amount, 0) - IFNULL(A.depreciation_value, 0) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      END IF;

      IF $i = $Count THEN

        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B
          ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
            A.depreciation_amount = B.depreciation_amount,
            A.depreciation_for_business_amount = B.depreciation_for_business_amount,
            A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
            A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
        WHERE A.organization_id = $OrganizationID
        AND B.STT = $Count;

      END IF;
    END IF;

    SET $i = $i + 1;
    SET $VoucherType = 0;
  END WHILE;

  -- C?p nh?t ledger to
  UPDATE fixed_asset_ledger A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type <> 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
  WHERE A.organization_id = $OrganizationID;


  -- C?p nh?t ledger hao mòn, kh?u hao
  UPDATE fa_ledger_depreciation A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (5, 9)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
  WHERE A.organization_id = $OrganizationID;

  -- C?p nh?t ledger ghi tang, gi?m
  UPDATE fa_ledger_increment_and_decrement A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (1, 8, 6)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
  WHERE A.organization_id = $OrganizationID;

  -- C?p nh?t ledger ki?m kê
  UPDATE fa_ledger_inventory A
  INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.inventory_orgprice = IFNULL(B.orgprice,0) - IFNULL(A.difference_orgprice,0),
      A.inventory_remaining_amount = IFNULL(B.remaining_amount, 0) - IFNULL(A.difference_remaining_amount, 0),
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
  WHERE A.organization_id = $OrganizationID;

    -- Detail ghi tang
    UPDATE fixed_asset_increment_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 1) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Hao mon
    UPDATE fixed_asset_depreciation_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 5) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail KH
    UPDATE fixed_asset_depreciation_business_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 9) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_remaining_amount =  IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Ghi giam
    UPDATE fixed_asset_decrement_detail A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 6) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
    SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;

  -- L?y nguyên giá c?a tài s?n
  set $OrgpriceFA = (SELECT orgprice FROM fixed_asset fa WHERE fa.fixed_asset_id = $FixedAssetID);

  -- Ledger budget c?a tài s?n
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
  CREATE TEMPORARY TABLE tbLedgerBudgetFA
  SELECT lb.*
  FROM ledger_budget lb 
  INNER JOIN
  (
    SELECT * FROM
    (
      SELECT l.fixed_asset_id, IFNULL(l.voucher_id, '') AS voucher_id,
      ROW_NUMBER() OVER(PARTITION BY fixed_asset_id ORDER BY change_date DESC, created_date DESC) AS STT
      FROM ledger_budget l
      WHERE l.fixed_asset_id = $FixedAssetID AND IFNULL(voucher_type, 1) IN (1,2,8)
    ) A WHERE A.STT = 1
  ) A2 ON lb.fixed_asset_id = A2.fixed_asset_id AND IFNULL(lb.voucher_id, '') = A2.voucher_id;

  -- N?u nguyên giá khác v?i t?ng trong ledger budget thì c?p nh?t l?i
  IF (select SUM(amount) FROM tbLedgerBudgetFA) <> $OrgpriceFA THEN
      BEGIN

                 -- C?p nh?t d?i v?i tru?ng h?p ch? có m?t ngu?n
                 IF (SELECT count(*) FROM tbLedgerBudgetFA) = 1 THEN
                 BEGIN
                    UPDATE  tbLedgerBudgetFA set amount = $OrgpriceFA;

                    UPDATE ledger_budget lb 
                    INNER JOIN tbLedgerBudgetFA lbf ON lb.organization_id = lbf.organization_id AND lb.ledger_budget_id = lbf.ledger_budget_id
                    set lb.amount = lbf.amount;
                 END;
                 END IF;

                -- Tru?ng h?p có nhi?u ngu?n
                IF (SELECT count(*) FROM tbLedgerBudgetFA) > 1 THEN
                 BEGIN
                    SET $LedgerBudgetID = (SELECT ledger_budget_id FROM tbLedgerBudgetFA ORDER BY amount DESC LIMIT 1);

                    SET $SumBudget =  (SELECT sum(amount) FROM tbLedgerBudgetFA WHERE ledger_budget_id <> $LedgerBudgetID);

                    UPDATE ledger_budget lb 
                    set lb.amount = ifnull($OrgpriceFA,0) - ifnull($SumBudget,0)
                    WHERE lb.ledger_budget_id =  $LedgerBudgetID;

                 END;
                 END IF;
                 
      END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbCacheData;
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
    
END; 
END IF;
  
DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData2;

END;