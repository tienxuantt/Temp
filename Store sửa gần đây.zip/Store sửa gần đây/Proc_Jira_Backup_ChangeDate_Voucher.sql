﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Backup_ChangeDate_Voucher;

CREATE PROCEDURE Proc_Jira_Backup_ChangeDate_Voucher (IN $voucher_id varchar(36), IN $fixed_asset_id varchar(36), IN $type int)
SQL SECURITY INVOKER
BEGIN

    DECLARE $count int DEFAULT 0;
    DECLARE $quantity decimal(19,4) DEFAULT 0;
    DECLARE $remaining_number_of_year decimal(19,4) DEFAULT 0;
    DECLARE $depreciation_year decimal(19,4) DEFAULT 0; 
    DECLARE $depreciation_for_business_remaining_time decimal(19,4) DEFAULT 0; 
    DECLARE $depreciation_rate decimal(19,4) DEFAULT 0; 
    DECLARE $depreciation_for_business_value decimal(19,4) DEFAULT 0; 

    -- Lấy ra một số thông tin backup
    SELECT fa.quantity, fa.remaining_number_of_year, fa.depreciation_year, fa.depreciation_for_business_remaining_time, fa.depreciation_rate, fa.depreciation_for_business_value
    INTO $quantity, $remaining_number_of_year, $depreciation_year, $depreciation_for_business_remaining_time, $depreciation_rate,$depreciation_for_business_value 
    FROM fixed_asset fa WHERE fa.fixed_asset_id = $fixed_asset_id 
    LIMIT 1;

    DROP TEMPORARY TABLE IF EXISTS tbOrginData;
    CREATE TEMPORARY TABLE tbOrginData
    SELECT
        *
    FROM (SELECT
            organization_id,
            change_date,
            voucher_date,
            fixed_asset_id,
            voucher_id
        FROM fixed_asset_ledger
        WHERE fixed_asset_id = $fixed_asset_id
        AND voucher_id <> $voucher_id
        UNION ALL
        SELECT
            organization_id,
            change_date,
            voucher_date,
            fixed_asset_id,
            voucher_id
        FROM fa_ledger_inventory
        WHERE fixed_asset_id = $fixed_asset_id
        AND voucher_id <> $voucher_id) A;

    SELECT count(*) INTO $count 
    FROM  jira_asset_change_date 
    WHERE fixed_asset_id = $fixed_asset_id;

    IF ($type = 1 AND $count = 0) THEN
    BEGIN

        INSERT jira_asset_change_date (organization_id, voucher_id, fixed_asset_id, change_date, voucher_date, quantity, remaining_number_of_year, depreciation_year, depreciation_for_business_remaining_time,
        depreciation_rate, depreciation_for_business_value)
            SELECT
                organization_id,
                voucher_id,
                fixed_asset_id,
                change_date,
                voucher_date,
                $quantity, $remaining_number_of_year, $depreciation_year, $depreciation_for_business_remaining_time, $depreciation_rate, $depreciation_for_business_value
            FROM tbOrginData;

        UPDATE fixed_asset_ledger fal
        INNER JOIN tbOrginData B
            ON fal.organization_id = B.organization_id
            AND fal.voucher_id = B.voucher_id
            AND fal.fixed_asset_id = B.fixed_asset_id
        SET fal.change_date = DATE_FORMAT('2000-01-01', '%Y-%m-%d 23:59:59'),
            fal.voucher_date = DATE_FORMAT('2000-01-01', '%Y-%m-%d 23:59:59');

        UPDATE fa_ledger_inventory fal
        INNER JOIN tbOrginData B
            ON fal.organization_id = B.organization_id
            AND fal.voucher_id = B.voucher_id
            AND fal.fixed_asset_id = B.fixed_asset_id
        SET fal.change_date = DATE_FORMAT('2000-01-01', '%Y-%m-%d 23:59:59'),
            fal.voucher_date = DATE_FORMAT('2000-01-01', '%Y-%m-%d 23:59:59');

    END;
    END IF;

    IF ($type = 2) THEN
    BEGIN

        UPDATE fixed_asset_ledger fal
        INNER JOIN tbOrginData B
            ON fal.organization_id = B.organization_id
            AND fal.voucher_id = B.voucher_id
            AND fal.fixed_asset_id = B.fixed_asset_id
        INNER JOIN jira_asset_change_date C
            ON fal.organization_id = C.organization_id
            AND fal.voucher_id = C.voucher_id
            AND fal.fixed_asset_id = C.fixed_asset_id
        SET fal.change_date = C.change_date,
            fal.voucher_date = C.voucher_date;

        UPDATE fa_ledger_inventory fal
        INNER JOIN tbOrginData B
            ON fal.organization_id = B.organization_id
            AND fal.voucher_id = B.voucher_id
            AND fal.fixed_asset_id = B.fixed_asset_id
        INNER JOIN jira_asset_change_date C
            ON fal.organization_id = C.organization_id
            AND fal.voucher_id = C.voucher_id
            AND fal.fixed_asset_id = C.fixed_asset_id
        SET fal.change_date = C.change_date,
            fal.voucher_date = C.voucher_date;

        UPDATE fixed_asset fa
        INNER JOIN jira_asset_change_date B ON fa.fixed_asset_id = B.fixed_asset_id
        set fa.quantity = B.quantity,
        fa.remaining_number_of_year = B.remaining_number_of_year,
        fa.depreciation_year = B.depreciation_year,
        fa.depreciation_for_business_remaining_time = B.depreciation_for_business_remaining_time,
        fa.depreciation_rate = B.depreciation_rate,
        fa.depreciation_for_business_value = B.depreciation_for_business_value;

        DELETE A
            FROM jira_asset_change_date A
        WHERE A.fixed_asset_id = $fixed_asset_id;

        CALL Proc_Jira_ReCallUpdateFAData($fixed_asset_id);

    END;
    END IF;

    DROP TEMPORARY TABLE IF EXISTS tbOrginData;
END;