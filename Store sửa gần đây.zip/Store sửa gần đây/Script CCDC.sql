﻿SELECT el.equipment_id, el.status_id, el.equipment_code, el.voucher_id, el.voucher_code,el.voucher_type, el.voucher_date, el.change_date,el.pre_quantity,el.quantity, el.price, el.pre_total_money, el.total_money, el.distribution_amount, el.distribution_remaning_amount,el.distribution_amount_per_time,el.old_department_id,el.department_id, el.new_department_id, el.unit, el.equipment_category_id, el.vendor_id, el.incremental_date, el.tracking_date, el.distribution_type, el.distribution_time, el.distribution_rate, el.distribution_remaning_time,el.organization_id, el.organization_name, el.status, el.difference_orgprice
FROM equipment_ledger el WHERE el.equipment_id = '31a1c7bd-666a-42db-af79-345f6b6e3885'
ORDER BY el.change_date desc;

SELECT do.organization_code, e.equipment_code, e.tracking_date, e.department_name, e.quantity, B.quantity AS quantity_correct
FROM equipment e
INNER JOIN dic_organization do ON e.organization_id = do.organization_id
INNER JOIN
(
  SELECT el.equipment_id, SUM(IF(el.voucher_type IN (1,6,7), el.quantity, (-1)*el.quantity))AS quantity
  FROM equipment_ledger el
  WHERE el.voucher_type IN (1,2,3,6,7)
  GROUP BY el.equipment_id
) B ON e.equipment_id = B.equipment_id
WHERE e.quantity <> B.quantity
ORDER BY do.organization_code;

UPDATE equipment e
INNER JOIN
(
      SELECT el.equipment_id, SUM(IF(el.voucher_type IN (1,6,7), el.quantity, (-1)*el.quantity))AS quantity
      FROM equipment_ledger el
      WHERE el.voucher_type IN (1,2,3,6,7)
      GROUP BY el.equipment_id
) B ON e.equipment_id = B.equipment_id
set e.quantity = B.quantity,
e.price = if(B.quantity > 0, ROUND(e.total_money/B.quantity), e.price) ,
e.total_money = IF(B.quantity = 0, 0, e.total_money),
e.distribution_remaning_amount =  IF(B.quantity = 0, 0, e.distribution_remaning_amount),
e.distribution_amount =  IF(B.quantity = 0, 0, e.distribution_amount),
e.status_id =  IF(B.quantity = 0, 3, e.status_id)
WHERE e.quantity <> B.quantity AND B.quantity >= 0;

SELECT e.equipment_id
FROM  equipment e
INNER JOIN
(
      SELECT el.equipment_id, SUM(IF(el.voucher_type IN (1,6,7), el.quantity, (-1)*el.quantity))AS quantity
      FROM equipment_ledger el
      WHERE el.voucher_type IN (1,2,3,6,7)
      GROUP BY el.equipment_id
) B ON e.equipment_id = B.equipment_id
WHERE e.quantity > B.quantity AND B.quantity >= 0;

-- SELECT eid.voucher_id, eid.equipment_id, eid.pre_quantity, eid.quantity, eid.price, eid.pre_total_money, eid.total_money, eid.distribution_remaning_amount, eid.distribution_amount_per_time, eid.distribution_amount 
-- FROM equipment_increment_detail eid WHERE eid.equipment_id = $equipment_id; 

-- SELECT etd.voucher_id, etd.equipment_id, etd.pre_quantity, etd.quantity, etd.price, etd.pre_total_money, etd.total_money, etd.distribution_remaning_amount, etd.distribution_amount_per_time, etd.distribution_amount 
-- FROM equipment_transfer_detail etd WHERE etd.equipment_id = $equipment_id;

-- SELECT edd.voucher_id, edd.equipment_id, edd.quantity, edd.total_money, edd.distribution_amount, edd.distribution_remaning_amount, edd.distribution_value, edd.distribution_amount_per_time 
-- FROM equipment_distribution_detail edd WHERE edd.equipment_id = $equipment_id;

-- SELECT edd.voucher_id, edd.equipment_id, edd.pre_quantity, edd.quantity, edd.price, edd.pre_total_money, edd.total_money, edd.distribution_amount, edd.distribution_amount_per_time, edd.distribution_remaning_amount 
-- FROM equipment_decrement_detail edd WHERE edd.equipment_id = $equipment_id;


SELECT fa.quantity, fa.fixed_asset_id, fa.software_start_time, e.equipment_code, e.department_name, do.organization_code, CONCAT("CALL Proc_Jira_Update_Quantity_TotalMoney_Equipment('",e.equipment_id,"', ",fa.quantity,", ",fa.remaining_amount,");")  AS Data 
FROM fixed_asset_ledger fa
INNER JOIN equipment e ON fa.organization_id = e.organization_id AND fa.fixed_asset_code = e.equipment_code
INNER JOIN dic_organization do ON fa.organization_id = do.organization_id
WHERE fa.voucher_type = 6 AND  e.quantity = 0 AND fa.quantity > 0 AND e.status_id = 1 AND (fa.voucher_description LIKE '%CCDC%' OR fa.reason LIKE '%CCDC%')
order by do.organization_code;

SELECT CONCAT("CALL Proc_Jira_Update_Quantity_TotalMoney_Equipment('",e.equipment_id,"', ",fa.quantity,", ",fa.remaining_amount,");")  AS Data
FROM fixed_asset_ledger fa
INNER JOIN equipment e ON fa.organization_id = e.organization_id AND fa.fixed_asset_code = e.equipment_code
INNER JOIN dic_organization do ON fa.organization_id = do.organization_id
WHERE fa.voucher_type = 6 AND  e.quantity = 0 AND fa.quantity > 0 AND e.status_id = 1 AND (fa.voucher_description LIKE '%CCDC%' OR fa.reason LIKE '%CCDC%')
order by do.organization_code;


SELECT * FROM fixed_asset_decrement_detail fadd WHERE fadd.reason LIKE '%CCDC%' LIMIT 10;
SELECT * FROM fixed_asset_ledger fal WHERE fal.voucher_type = 6 AND fal.voucher_description LIKE '%CCDC%' OR fal.reason LIKE '%CCDC%';

SELECT e.equipment_code, e.equipment_name, e.department_name, do.organization_code, e.equipment_category_id, e.equipment_category_code, e.equipment_category_name 
FROM equipment e
INNER JOIN dic_organization do on e.organization_id = do.organization_id 
WHERE e.equipment_category_id IS NULL AND e.equipment_category_name IS NOT NULL
ORDER BY do.organization_code;

SELECT e.equipment_id FROM equipment e WHERE e.equipment_category_id IS NULL AND e.equipment_category_name IS NOT NULL;

SELECT * FROM equipment_ledger el WHERE el.equipment_id = 'fb0a92c4-018d-47a4-9aa7-04406b7d3eb1';