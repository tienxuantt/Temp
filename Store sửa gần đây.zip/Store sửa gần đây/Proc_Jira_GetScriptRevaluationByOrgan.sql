﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_GetScriptRevaluationByOrgan;

CREATE PROCEDURE Proc_Jira_GetScriptRevaluationByOrgan (IN $organization_code varchar(100))
SQL SECURITY INVOKER
BEGIN
    DECLARE $organID varchar(36) DEFAULT '';

    set $organID = (SELECT do.organization_id FROM dic_organization do WHERE do.organization_code = $organization_code LIMIT 1);

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization
    SELECT * 
    FROM fixed_asset_ledger fal 
    WHERE fal.voucher_type = 2 AND fal.organization_id = $organID AND fal.remaining_amount < 0;

    SELECT fixed_asset_code,  concat("CALL Proc_Jira_Backup_ChangeDate_Voucher('",voucher_id,"','",fixed_asset_id,"', 1);") as script 
    FROM tbOrganization
    ORDER BY fixed_asset_id;
                               
    DROP TEMPORARY TABLE IF EXISTS tbOrganization;

END;

