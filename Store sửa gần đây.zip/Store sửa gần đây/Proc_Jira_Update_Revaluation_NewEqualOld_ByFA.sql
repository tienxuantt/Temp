﻿SET NAMES 'utf8';
DROP PROCEDURE IF EXISTS Proc_Jira_Update_Revaluation_NewEqualOld_ByFA;

CREATE PROCEDURE Proc_Jira_Update_Revaluation_NewEqualOld_ByFA (IN $Voucher_id varchar(36), IN $FixedAssetID varchar(36))
BEGIN

  DECLARE $STT_Current int DEFAULT 0;
  DECLARE $revaluation_type int DEFAULT 0;
  DECLARE $fixed_asset_type int DEFAULT 0;
  DECLARE $OrgPrice decimal(19, 4) DEFAULT 0;
  DECLARE $Accum decimal(19, 4) DEFAULT 0;
  DECLARE $Remaining decimal(19, 4) DEFAULT 0;

  SET group_concat_max_len = 18446744073709551615;

  DROP TEMPORARY TABLE IF EXISTS tbOrginLedgerData;
  CREATE TEMPORARY TABLE tbOrginLedgerData
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id
    ORDER BY A.change_date, A.created_date) AS STT
  FROM (SELECT
      lg.voucher_id,
      lg.fixed_asset_id,
      lg.change_date,
      lg.created_date,
      lg.orgprice,
      lg.accum_depreciation_amount,
      lg.remaining_amount
    FROM fixed_asset_ledger lg
    WHERE lg.fixed_asset_id = $FixedAssetID
    AND lg.voucher_type <> 17
    UNION ALL
    SELECT
      voucher_id,
      fixed_asset_id,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE fixed_asset_id = $FixedAssetID) A;

  -- Lấy ra STT hiện tại
  SET $STT_Current = (SELECT
      STT
    FROM tbOrginLedgerData
    WHERE voucher_id = $Voucher_id LIMIT 1);

  -- Lấy ra bản ghi trước đó
  SELECT
    orgprice,
    accum_depreciation_amount,
    remaining_amount INTO $OrgPrice, $Accum, $Remaining
  FROM tbOrginLedgerData
  WHERE STT = $STT_Current - 1
  LIMIT 1;


  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation AS
  SELECT
    r.orgprice,
    r.orgprice_info,
    r.orgprice_old,
    r.orgprice_info_old,
    fa.voucher_id,
    fa.fixed_asset_id,
    fa.fixed_asset_code,
    fa.organization_id,
    fa.fixed_asset_revaluation_list,
    fa.revaluation_type,
    fa.description,
    COALESCE(fa1.fixed_asset_type, 0) fixed_asset_type
  FROM fixed_asset_revaluation fa
         INNER JOIN fixed_asset fa1
           ON fa.organization_id = fa1.organization_id
           AND fa.fixed_asset_id = fa1.fixed_asset_id,
       JSON_TABLE (fa.fixed_asset_revaluation_list,
       '$[*]'
       COLUMNS (
       orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
       orgprice_info text PATH '$.new_data[*].orgprice_info',
       orgprice_old decimal(19, 4) PATH '$.old_data[*].orgprice',
       orgprice_info_old text PATH '$.old_data[*].orgprice_info'
       )) AS r
  WHERE fa.fixed_asset_id = $FixedAssetID
  AND fa.voucher_id = $Voucher_id;

  -- Lưu 2 biến riêng
  SELECT
    fixed_asset_type,
    revaluation_type INTO $fixed_asset_type, $revaluation_type
  FROM tbFixedAssetRevaluation;

  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation_JSON AS
  SELECT
    SUM(r.amount) amount,
    fa.voucher_id,
    fa.fixed_asset_id
  FROM tbFixedAssetRevaluation fa,
       JSON_TABLE (fa.orgprice_info,
       '$[*]'
       COLUMNS (
       budget_category_id varchar(36) PATH '$.budget_category_id',
       budget_category_code varchar(50) PATH '$.budget_category_code',
       budget_category_name varchar(500) PATH '$.budget_category_name',
       budget_type int PATH '$.budget_type',
       is_budget bit(1) PATH '$.is_budget',
       amount decimal(19, 4) PATH '$.amount',
       depreciation_for_business_price decimal(19, 4) PATH '$.depreciation_for_business_price'
       )) AS r
  GROUP BY fa.voucher_id,
           fa.fixed_asset_id;

  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON_old;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation_JSON_old AS
  SELECT
    SUM(r.amount) amount,
    fa.voucher_id,
    fa.fixed_asset_id
  FROM tbFixedAssetRevaluation fa,
       JSON_TABLE (fa.orgprice_info_old,
       '$[*]'
       COLUMNS (
       budget_category_id varchar(36) PATH '$.budget_category_id',
       budget_category_code varchar(50) PATH '$.budget_category_code',
       budget_category_name varchar(500) PATH '$.budget_category_name',
       budget_type int PATH '$.budget_type',
       is_budget bit(1) PATH '$.is_budget',
       amount decimal(19, 4) PATH '$.amount',
       depreciation_for_business_price decimal(19, 4) PATH '$.depreciation_for_business_price'
       )) AS r
  GROUP BY fa.voucher_id,
           fa.fixed_asset_id;

  DROP TEMPORARY TABLE IF EXISTS tbOldData;
  CREATE TEMPORARY TABLE tbOldData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    description text,
    fixed_asset_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbNewData;
  CREATE TEMPORARY TABLE tbNewData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    description text,
    fixed_asset_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbChangeData;
  CREATE TEMPORARY TABLE tbChangeData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;

  INSERT INTO tbOldData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      fa.description,
      fa.fixed_asset_type,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.old_data[*].orgprice',
         orgprice_info longtext PATH '$.old_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.old_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_amount',
         accum_depreciation_amount decimal(19, 4) PATH '$.old_data[*].accum_depreciation_amount',
         remaining_amount decimal(19, 4) PATH '$.old_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.old_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.old_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.old_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.old_data[*].quantity',
         house_category_id int PATH '$.old_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.old_data[*].house_category_name',
         number_of_floor float PATH '$.old_data[*].number_of_floor',
         build_year int PATH '$.old_data[*].build_year',
         build_area float PATH '$.old_data[*].build_area',
         total_floor_area float PATH '$.old_data[*].total_floor_area',
         area float PATH '$.old_data[*].area',
         working_office float PATH '$.old_data[*].working_office',
         leasing float PATH '$.old_data[*].leasing',
         house float PATH '$.old_data[*].house',
         basis_of_business_activity float PATH '$.old_data[*].basis_of_business_activity',
         vacant float PATH '$.old_data[*].vacant',
         business float PATH '$.old_data[*].business',
         joint_venture float PATH '$.old_data[*].joint_venture',
         mix_using float PATH '$.old_data[*].mix_using',
         occupied float PATH '$.old_data[*].occupied',
         other float PATH '$.old_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.old_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.old_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbNewData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      fa.description,
      fa.fixed_asset_type,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
         orgprice_info longtext PATH '$.new_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.new_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_amount',
         accum_depreciation_amount decimal(19, 4) PATH '$.new_data[*].accum_depreciation_amount',
         remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.new_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.new_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.new_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.new_data[*].quantity',
         house_category_id int PATH '$.new_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.new_data[*].house_category_name',
         number_of_floor float PATH '$.new_data[*].number_of_floor',
         build_year int PATH '$.new_data[*].build_year',
         build_area float PATH '$.new_data[*].build_area',
         total_floor_area float PATH '$.new_data[*].total_floor_area',
         area float PATH '$.new_data[*].area',
         working_office float PATH '$.new_data[*].working_office',
         leasing float PATH '$.new_data[*].leasing',
         house float PATH '$.new_data[*].house',
         basis_of_business_activity float PATH '$.new_data[*].basis_of_business_activity',
         vacant float PATH '$.new_data[*].vacant',
         business float PATH '$.new_data[*].business',
         joint_venture float PATH '$.new_data[*].joint_venture',
         mix_using float PATH '$.new_data[*].mix_using',
         occupied float PATH '$.new_data[*].occupied',
         other float PATH '$.new_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.new_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.new_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbChangeData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.change_data[*].orgprice',
         orgprice_info longtext PATH '$.change_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.change_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_amount',
         accum_depreciation_amount decimal(19, 4) PATH '$.change_data[*].accum_depreciation_amount',
         remaining_amount decimal(19, 4) PATH '$.change_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.change_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.change_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.change_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.change_data[*].quantity',
         house_category_id int PATH '$.change_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.change_data[*].house_category_name',
         number_of_floor float PATH '$.change_data[*].number_of_floor',
         build_year int PATH '$.change_data[*].build_year',
         build_area float PATH '$.change_data[*].build_area',
         total_floor_area float PATH '$.change_data[*].total_floor_area',
         area float PATH '$.change_data[*].area',
         working_office float PATH '$.change_data[*].working_office',
         leasing float PATH '$.change_data[*].leasing',
         house float PATH '$.change_data[*].house',
         basis_of_business_activity float PATH '$.change_data[*].basis_of_business_activity',
         vacant float PATH '$.change_data[*].vacant',
         business float PATH '$.change_data[*].business',
         joint_venture float PATH '$.change_data[*].joint_venture',
         mix_using float PATH '$.change_data[*].mix_using',
         occupied float PATH '$.change_data[*].occupied',
         other float PATH '$.change_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.change_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.change_data[*].orgprice_from_other'
         )) AS r;

  UPDATE tbOldData A
  INNER JOIN tbFixedAssetRevaluation_JSON_old B
    ON A.voucher_id = B.voucher_id
    AND A.fixed_asset_id = B.fixed_asset_id
  SET A.orgprice = IFNULL(B.amount, 0),
      A.accum_depreciation_amount =  IFNULL($Accum, 0),
      A.depreciation_amount = IFNULL($Accum, 0),
      A.remaining_amount = IFNULL(B.amount, 0) - IFNULL($Accum, 0),
      A.row_update = 1;

UPDATE tbNewData A
  INNER JOIN tbFixedAssetRevaluation_JSON B
    ON A.voucher_id = B.voucher_id
    AND A.fixed_asset_id = B.fixed_asset_id
  SET A.orgprice = IFNULL(B.amount, 0),
      A.accum_depreciation_amount = IFNULL($Accum, 0),
      A.depreciation_amount = IFNULL($Accum, 0),
      A.remaining_amount = IFNULL(B.amount, 0) - IFNULL($Accum, 0),
      A.row_update = 1;

  UPDATE tbChangeData a
  INNER JOIN tbNewData b
    ON a.voucher_id = b.voucher_id
    AND a.fixed_asset_id = b.fixed_asset_id
  INNER JOIN tbOldData c
    ON a.voucher_id = c.voucher_id
    AND a.fixed_asset_id = c.fixed_asset_id
  SET a.orgprice = COALESCE(b.orgprice, 0) - COALESCE(c.orgprice, 0),
      a.remaining_amount = COALESCE(b.remaining_amount, 0) - COALESCE(c.remaining_amount, 0),
      a.depreciation_amount = COALESCE(b.depreciation_amount, 0) - COALESCE(c.depreciation_amount, 0),
      a.depreciation_for_business_amount = COALESCE(b.depreciation_for_business_amount, 0) - COALESCE(c.depreciation_for_business_amount, 0),
      a.accum_depreciation_amount = COALESCE(b.accum_depreciation_amount, 0) - COALESCE(c.accum_depreciation_amount, 0),
      a.depreciation_for_business_price = COALESCE(b.depreciation_for_business_price, 0) - COALESCE(c.depreciation_for_business_price, 0),
      a.row_update = 1
  WHERE (b.row_update = 1
  OR c.row_update = 1);


  UPDATE fixed_asset_revaluation far
  INNER JOIN (SELECT
      A.fixed_asset_id,
      A.voucher_id,
      B.row_update,
      CONCAT('[{"old_data":', A.old_data, ',"new_data":', B.new_data, ',"change_data":', C.change_data, '}]') AS fixed_asset_revaluation_list
    FROM (SELECT
        voucher_id,
        fixed_asset_id,
        CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
        'orgprice_info', orgprice_info,
        'depreciation_amount', depreciation_amount,
        'depreciation_for_business_amount', depreciation_for_business_amount,
        'accum_depreciation_amount', accum_depreciation_amount,
        'remaining_amount', remaining_amount,
        'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
        'depreciation_rate', depreciation_rate,
        'depreciation_year', depreciation_year,
        'remaining_number_of_year', remaining_number_of_year,
        'depreciation_for_business_price', depreciation_for_business_price,
        'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
        'depreciation_for_business_value', depreciation_for_business_value,
        'quantity', quantity,
        'house_category_id', house_category_id,
        'house_category_name', house_category_name,
        'number_of_floor', number_of_floor,
        'build_year', build_year,
        'build_area', build_area,
        'total_floor_area', total_floor_area,
        'area', area,
        'working_office', working_office,
        'leasing', leasing,
        'house', house,
        'basis_of_business_activity', basis_of_business_activity,
        'vacant', vacant,
        'business', business,
        'joint_venture', joint_venture,
        'mix_using', mix_using,
        'occupied', occupied,
        'other', other,
        'orgprice_from_budget', orgprice_from_budget,
        'orgprice_from_other', orgprice_from_other)), ']') AS old_data
      FROM tbOldData
      GROUP BY voucher_id,
               fixed_asset_id) AS A
      INNER JOIN (SELECT
          voucher_id,
          fixed_asset_id,
          MAX(row_update) AS row_update,
          CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
          'orgprice_info', orgprice_info,
          'depreciation_amount', depreciation_amount,
          'depreciation_for_business_amount', depreciation_for_business_amount,
          'accum_depreciation_amount', accum_depreciation_amount,
          'remaining_amount', remaining_amount,
          'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
          'depreciation_rate', depreciation_rate,
          'depreciation_year', depreciation_year,
          'remaining_number_of_year', remaining_number_of_year,
          'depreciation_for_business_price', depreciation_for_business_price,
          'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
          'depreciation_for_business_value', depreciation_for_business_value,
          'quantity', quantity,
          'house_category_id', house_category_id,
          'house_category_name', house_category_name,
          'number_of_floor', number_of_floor,
          'build_year', build_year,
          'build_area', build_area,
          'total_floor_area', total_floor_area,
          'area', area,
          'working_office', working_office,
          'leasing', leasing,
          'house', house,
          'basis_of_business_activity', basis_of_business_activity,
          'vacant', vacant,
          'business', business,
          'joint_venture', joint_venture,
          'mix_using', mix_using,
          'occupied', occupied,
          'other', other,
          'orgprice_from_budget', orgprice_from_budget,
          'orgprice_from_other', orgprice_from_other)), ']') AS new_data
        FROM tbNewData
        GROUP BY voucher_id,
                 fixed_asset_id) AS B
        ON A.voucher_id = B.voucher_id
        AND A.fixed_asset_id = B.fixed_asset_id
      INNER JOIN (SELECT
          voucher_id,
          fixed_asset_id,
          CONCAT('[', GROUP_CONCAT(JSON_OBJECT('orgprice', orgprice,
          'orgprice_info', orgprice_info,
          'depreciation_amount', depreciation_amount,
          'depreciation_for_business_amount', depreciation_for_business_amount,
          'accum_depreciation_amount', accum_depreciation_amount,
          'remaining_amount', remaining_amount,
          'depreciation_for_business_remaining_amount', depreciation_for_business_remaining_amount,
          'depreciation_rate', depreciation_rate,
          'depreciation_year', depreciation_year,
          'remaining_number_of_year', remaining_number_of_year,
          'depreciation_for_business_price', depreciation_for_business_price,
          'depreciation_for_business_remaining_time', depreciation_for_business_remaining_time,
          'depreciation_for_business_value', depreciation_for_business_value,
          'quantity', quantity,
          'house_category_id', house_category_id,
          'house_category_name', house_category_name,
          'number_of_floor', number_of_floor,
          'build_year', build_year,
          'build_area', build_area,
          'total_floor_area', total_floor_area,
          'area', area,
          'working_office', working_office,
          'leasing', leasing,
          'house', house,
          'basis_of_business_activity', basis_of_business_activity,
          'vacant', vacant,
          'business', business,
          'joint_venture', joint_venture,
          'mix_using', mix_using,
          'occupied', occupied,
          'other', other,
          'orgprice_from_budget', orgprice_from_budget,
          'orgprice_from_other', orgprice_from_other)), ']') AS change_data
        FROM tbChangeData
        GROUP BY voucher_id,
                 fixed_asset_id) AS C
        ON A.voucher_id = C.voucher_id
        AND A.fixed_asset_id = C.fixed_asset_id) AS A
    ON far.voucher_id = A.voucher_id
    AND A.fixed_asset_id = far.fixed_asset_id
  SET far.fixed_asset_revaluation_list = A.fixed_asset_revaluation_list,
      far.modified_by = 'admin';

  UPDATE fixed_asset_ledger fal
  INNER JOIN tbNewData nd
    ON nd.voucher_id = fal.voucher_id
    AND nd.fixed_asset_id = fal.fixed_asset_id
    AND nd.row_update = 1
  SET fal.orgprice = nd.orgprice,
      fal.depreciation_amount = CASE WHEN fal.fixed_asset_type = 2 THEN 0 ELSE IFNULL(nd.depreciation_amount, 0) - IFNULL(nd.depreciation_for_business_amount, 0) END,
      fal.depreciation_for_business_amount = CASE WHEN fal.fixed_asset_type = 2 THEN nd.depreciation_amount WHEN fal.fixed_asset_type = 1 THEN 0 ELSE nd.depreciation_for_business_amount END,
      fal.accum_depreciation_amount = nd.depreciation_amount,
      fal.remaining_amount = IFNULL(nd.orgprice, 0) - IFNULL(nd.depreciation_amount, 0),
      fal.depreciation_for_business_price = nd.depreciation_for_business_price,
      fal.depreciation_value = 0,
      fal.depreciation_for_business_value = 0;

  UPDATE fixed_asset_ledger fal
  INNER JOIN tbChangeData nd
    ON nd.voucher_id = fal.voucher_id
    AND nd.fixed_asset_id = fal.fixed_asset_id
  SET fal.difference_orgprice = nd.orgprice,
  fal.difference_quantity = nd.quantity,
  fal.difference_remaining_amount = nd.remaining_amount,
  fal.difference_depreciation_amount = CASE WHEN fal.fixed_asset_type = 2 THEN 0 ELSE IFNULL(nd.depreciation_amount, 0) - IFNULL(nd.depreciation_for_business_amount, 0) END,
  fal.difference_depreciation_for_business_amount =  CASE WHEN fal.fixed_asset_type = 2 THEN nd.depreciation_amount WHEN fal.fixed_asset_type = 1 THEN 0 ELSE nd.depreciation_for_business_amount END;

  CALL Proc_Jira_ReCallUpdateFAData($FixedAssetID);

  DROP TEMPORARY TABLE IF EXISTS tbFixedAsset;
  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetLedger;
  DROP TEMPORARY TABLE IF EXISTS tbBudget;
  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON;
  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation_JSON_old;
  DROP TEMPORARY TABLE IF EXISTS tbOrginLedgerData;
END;

SELECT FAL.fixed_asset_code, CONCAT("CALL Proc_Jira_Update_Revaluation_NewEqualOld_ByFA('",fal.voucher_id,"','",fal.fixed_asset_id,"');") as Data
FROM fixed_asset_ledger fal 
INNER JOIN fixed_asset_revaluation far on fal.organization_id = far.organization_id AND fal.voucher_id = far.voucher_id AND fal.fixed_asset_id = far.fixed_asset_id
WHERE fal.remaining_amount < 0 
and fal.voucher_type = 2
AND fal.convert_circular_id = 4
and fal.organization_id ='289800af-cf21-4742-b5f8-d8bfdad2627a';



