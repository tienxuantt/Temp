﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateDepreciationValueRaw;

CREATE PROCEDURE Proc_Jira_UpdateDepreciationValueRaw (IN $voucher_id varchar(36), IN $fixed_asset_id varchar(36), IN $depreciation_value decimal(19,4))
SQL SECURITY INVOKER
BEGIN

      DECLARE $organ_id varchar(36);

      SELECT fa.organization_id INTO $organ_id FROM fixed_asset fa WHERE fa.fixed_asset_id = $fixed_asset_id LIMIT 1;

     UPDATE fixed_asset_depreciation_detail A 
     set A.depreciation_value = $depreciation_value
     WHERE A.voucher_id = $voucher_id AND A.fixed_asset_id = $fixed_asset_id AND A.depreciation_value <> $depreciation_value;

     UPDATE fixed_asset_ledger A 
     set A.depreciation_value = $depreciation_value
     WHERE A.voucher_id = $voucher_id AND A.fixed_asset_id = $fixed_asset_id AND A.voucher_type = 5 AND A.depreciation_value <> $depreciation_value;
    
    UPDATE fixed_asset_depreciation fad
    INNER JOIN
    (
        SELECT fadd.organization_id, fadd.voucher_id, SUM(ROUND(fadd.depreciation_value)) AS TotalMoney
        FROM fixed_asset_depreciation_detail fadd
        GROUP BY fadd.organization_id, fadd.voucher_id
    ) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
    set fad.total_price = B.TotalMoney
    WHERE fad.organization_id = $organ_id AND fad.total_price <> B.TotalMoney;      

    CALL Proc_Jira_ReCallUpdateFAData($fixed_asset_id);

    DROP TEMPORARY TABLE IF EXISTS tblFaUpdateValue;

END;

CALL Proc_Jira_UpdateDepreciationValueRaw('f5f6a799-d86a-487c-8170-654a849cd21f','b73f3d3c-c307-48f4-b0e1-7708a3d0a744',315099016);

CALL Proc_Jira_OpenExportOrganization('1008116', 1);

