﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateInventoryOrgpriceOrgan;

CREATE PROCEDURE Proc_Jira_UpdateInventoryOrgpriceOrgan (IN $OrganizationID varchar(36), IN $FixedAssetID varchar(36))
SQL SECURITY INVOKER
BEGIN

    DROP TEMPORARY TABLE IF EXISTS tbOrginData;
    CREATE TEMPORARY TABLE tbOrginData
    SELECT
        *,
        ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY DATE(A.change_date), A.created_date
        ) AS STT
    FROM (SELECT
            organization_id,
            fixed_asset_ledger_id,
            fixed_asset_id,
            voucher_id,
            voucher_code,
            voucher_type,
            change_date,
            created_date,
            orgprice,
            CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS voucher_price,
            CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS depreciation_value,
            accum_depreciation_amount,
            remaining_amount
        FROM fixed_asset_ledger
        WHERE organization_id = $OrganizationID
        AND fixed_asset_id = $FixedAssetID
        AND voucher_type <> 17
        UNION ALL
        SELECT
            organization_id,
            fixed_asset_ledger_id,
            fixed_asset_id,
            voucher_id,
            voucher_code,
            voucher_type,
            change_date,
            created_date,
            orgprice,
            depreciation_value AS voucher_price,
            depreciation_value,
            accum_depreciation_amount,
            remaining_amount
        FROM fa_ledger_inventory
        WHERE organization_id = $OrganizationID
        AND fixed_asset_id = $FixedAssetID) A;

      DROP TEMPORARY TABLE IF EXISTS tbCacheDataInventory;
      CREATE TEMPORARY TABLE tbCacheDataInventory
      SELECT
        *
      FROM tbOrginData
      WHERE voucher_type = 10;

        UPDATE fa_ledger_inventory fli
        INNER JOIN tbCacheDataInventory od ON fli.organization_id = od.organization_id AND fli.voucher_id = od.voucher_id AND fli.fixed_asset_id = od.fixed_asset_id
        INNER JOIN  tbOrginData C ON fli.organization_id = C.organization_id AND fli.fixed_asset_id = C.fixed_asset_id
        set fli.orgprice = C.orgprice,
        fli.accum_depreciation_amount = C.orgprice,
        fli.remaining_amount = C.remaining_amount
        WHERE ifnull(fli.orgprice,0) = 0 AND od.STT = C.STT + 1;

--         SELECT fli.organization_id, fli.fixed_asset_code, fli.orgprice, fli.accum_depreciation_amount, fli.remaining_amount
--         FROM  fa_ledger_inventory fli
--         INNER JOIN tbCacheDataInventory od ON fli.organization_id = od.organization_id AND fli.voucher_id = od.voucher_id AND fli.fixed_asset_id = od.fixed_asset_id
--         INNER JOIN  tbOrginData C ON fli.organization_id = C.organization_id AND fli.fixed_asset_id = C.fixed_asset_id
--         WHERE ifnull(fli.orgprice,0) = 0 AND od.STT = C.STT + 1;
                                               
    DROP TEMPORARY TABLE IF EXISTS tbOrginData;
    DROP TEMPORARY TABLE IF EXISTS tbCacheDataInventory;
END;

SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateInventoryOrgpriceTenant;

CREATE PROCEDURE Proc_Jira_UpdateInventoryOrgpriceTenant ()
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $organID varchar(36) DEFAULT '';
    DECLARE $fixedAssetID varchar(36) DEFAULT '';

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization
    SELECT
    a.organization_id,
    a.fixed_asset_id
    FROM fa_ledger_inventory a
    WHERE ifnull(a.orgprice,0) = 0
    GROUP BY a.organization_id, a.fixed_asset_id;
                                 
    SELECT
        COUNT(1) INTO $count
    FROM tbOrganization;

    WHILE $i < $count DO
        SELECT
            organization_id, fixed_asset_id INTO $organID,  $fixedAssetID
        FROM tbOrganization
        LIMIT $i, 1;

        CALL Proc_Jira_UpdateInventoryOrgpriceOrgan($organID, $fixedAssetID);

        SET $i = $i + 1;
    END WHILE;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;

END;


CALL Proc_Jira_UpdateInventoryOrgpriceTenant();

SELECT fa.software_start_time FROM fixed_asset fa WHERE fa.fixed_asset_code = 'TS000039' AND fa.organization_id ='1caad198-e621-4e8b-ac42-17335e287252';

