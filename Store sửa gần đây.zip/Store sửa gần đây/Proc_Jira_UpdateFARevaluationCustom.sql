﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateFARevaluationCustom;

CREATE PROCEDURE Proc_Jira_UpdateFARevaluationCustom (IN $OrganizationID varchar(36))
COMMENT 'Cập nhật tài sản bị sai nguyên giá/GTCL do đánh giá lại'
BEGIN

  DROP TEMPORARY TABLE IF EXISTS tmpFAError;
  CREATE TEMPORARY TABLE tmpFAError
  SELECT
    fa.fixed_asset_id,
    fa.organization_id,
    far.voucher_id,
    far.fixed_asset_revaluation_list,
    far.revaluation_type
  FROM fixed_asset fa
    INNER JOIN fixed_asset_revaluation far
      ON fa.organization_id = far.organization_id
      AND fa.fixed_asset_id = far.fixed_asset_id
  WHERE fa.organization_id = $OrganizationID
  AND fa.status_id <> 2
  AND IFNULL(fa.is_parent, 0) = 0
  AND IFNULL(far.fixed_asset_revaluation_list, '') <> ''
  LIMIT 1;

  DROP TEMPORARY TABLE IF EXISTS tbOldData;
  CREATE TEMPORARY TABLE tbOldData (
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    revaluation_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbNewData;
  CREATE TEMPORARY TABLE tbNewData (
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    revaluation_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbChangeData;
  CREATE TEMPORARY TABLE tbChangeData (
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    revaluation_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  INSERT INTO tbOldData
    SELECT
      fa.fixed_asset_id,
      fa.voucher_id,
      fa.revaluation_type,
      r.*
    FROM tmpFAError fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.old_data[*].orgprice',
         orgprice_info longtext PATH '$.old_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.old_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_amount',
         remaining_amount decimal(19, 4) PATH '$.old_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.old_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.old_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.old_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.old_data[*].quantity',
         house_category_id int PATH '$.old_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.old_data[*].house_category_name',
         number_of_floor float PATH '$.old_data[*].number_of_floor',
         build_year int PATH '$.old_data[*].build_year',
         build_area float PATH '$.old_data[*].build_area',
         total_floor_area float PATH '$.old_data[*].total_floor_area',
         area float PATH '$.old_data[*].area',
         working_office float PATH '$.old_data[*].working_office',
         leasing float PATH '$.old_data[*].leasing',
         house float PATH '$.old_data[*].house',
         basis_of_business_activity float PATH '$.old_data[*].basis_of_business_activity',
         vacant float PATH '$.old_data[*].vacant',
         business float PATH '$.old_data[*].business',
         joint_venture float PATH '$.old_data[*].joint_venture',
         mix_using float PATH '$.old_data[*].mix_using',
         occupied float PATH '$.old_data[*].occupied',
         other float PATH '$.old_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.old_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.old_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbNewData
    SELECT
      fa.fixed_asset_id,
      fa.voucher_id,
      fa.revaluation_type,
      r.*
    FROM tmpFAError fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
         orgprice_info longtext PATH '$.new_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.new_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_amount',
         remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.new_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.new_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.new_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.new_data[*].quantity',
         house_category_id int PATH '$.new_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.new_data[*].house_category_name',
         number_of_floor float PATH '$.new_data[*].number_of_floor',
         build_year int PATH '$.new_data[*].build_year',
         build_area float PATH '$.new_data[*].build_area',
         total_floor_area float PATH '$.new_data[*].total_floor_area',
         area float PATH '$.new_data[*].area',
         working_office float PATH '$.new_data[*].working_office',
         leasing float PATH '$.new_data[*].leasing',
         house float PATH '$.new_data[*].house',
         basis_of_business_activity float PATH '$.new_data[*].basis_of_business_activity',
         vacant float PATH '$.new_data[*].vacant',
         business float PATH '$.new_data[*].business',
         joint_venture float PATH '$.new_data[*].joint_venture',
         mix_using float PATH '$.new_data[*].mix_using',
         occupied float PATH '$.new_data[*].occupied',
         other float PATH '$.new_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.new_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.new_data[*].orgprice_from_other'
         )) AS r;

  INSERT INTO tbChangeData
    SELECT
      fa.fixed_asset_id,
      fa.voucher_id,
      fa.revaluation_type,
      r.*
    FROM tmpFAError fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.change_data[*].orgprice',
         orgprice_info longtext PATH '$.change_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.change_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_amount',
         remaining_amount decimal(19, 4) PATH '$.change_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.change_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.change_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.change_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.change_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.change_data[*].quantity',
         house_category_id int PATH '$.change_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.change_data[*].house_category_name',
         number_of_floor float PATH '$.change_data[*].number_of_floor',
         build_year int PATH '$.change_data[*].build_year',
         build_area float PATH '$.change_data[*].build_area',
         total_floor_area float PATH '$.change_data[*].total_floor_area',
         area float PATH '$.change_data[*].area',
         working_office float PATH '$.change_data[*].working_office',
         leasing float PATH '$.change_data[*].leasing',
         house float PATH '$.change_data[*].house',
         basis_of_business_activity float PATH '$.change_data[*].basis_of_business_activity',
         vacant float PATH '$.change_data[*].vacant',
         business float PATH '$.change_data[*].business',
         joint_venture float PATH '$.change_data[*].joint_venture',
         mix_using float PATH '$.change_data[*].mix_using',
         occupied float PATH '$.change_data[*].occupied',
         other float PATH '$.change_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.change_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.change_data[*].orgprice_from_other'
         )) AS r;

        SELECT * FROM tbNewData;
        SELECT * FROM tbOldData od;
        SELECT * FROM tbChangeData cd;
                                
END;

CALL Proc_Jira_UpdateFARevaluationCustom('44db30fd-b15c-4eb7-b813-4d2bcfc2fdea');

