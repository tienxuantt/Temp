﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateRemoveHM_02;

CREATE PROCEDURE Proc_Jira_UpdateRemoveHM_02 (
IN $OrganID varchar(36),
IN $FixedAssetID varchar(36)
)
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $organCode varchar(100) DEFAULT '';
    DECLARE $fixedAssetCode varchar(100) DEFAULT '';
    DECLARE $orgprice decimal(19,4) DEFAULT 0;
    DECLARE $accum decimal(19,4) DEFAULT 0;
    DECLARE $depreciation_value decimal(19,4) DEFAULT 0;

--     SELECT K.depreciation_value  INTO $depreciation_value
--     FROM 
--     (
--         SELECT fal.depreciation_value, row_number() OVER(PARTITION BY fixed_asset_id ORDER BY fal.change_date, fal.created_date) AS STT 
--         FROM fixed_asset_ledger fal 
--         WHERE fal.organization_id = $OrganID AND fal.fixed_asset_id = $FixedAssetID AND fal.voucher_type = 5
--     ) K WHERE K.STT = 1;

    -- Các chứng từ đánh giá lại của đơn vị
--     DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerDGL;
--     CREATE TEMPORARY TABLE tbOrganizationLedgerDGL
--     SELECT fal.organization_id, fal.fixed_asset_id
--     FROM fixed_asset_ledger fal
--     WHERE  fal.organization_id = $OrganID AND fal.fixed_asset_id = $FixedAssetID AND fal.voucher_type = 2
--     GROUP BY fal.organization_id, fal.fixed_asset_id;

     -- Các chứng từ hao mòn của đơn vị
    DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerHM;
    CREATE TEMPORARY TABLE tbOrganizationLedgerHM
    SELECT fal.organization_id, fal.fixed_asset_id, fal.voucher_id, fal.depreciation_value,fal.orgprice, 1 AS status
    FROM fixed_asset_ledger fal
    WHERE  fal.organization_id = $OrganID AND fal.fixed_asset_id = $FixedAssetID AND fal.voucher_type = 5 AND fal.remaining_amount < 0;

    -- Xóa bỏ các tài sản có đánh giá lại
--     DELETE A FROM  tbOrganizationLedgerHM  A
--     INNER JOIN  tbOrganizationLedgerDGL B 
--     ON A.organization_id = B.organization_id AND A.fixed_asset_id = B.fixed_asset_id;

    -- Trạng thái 2 là chứng từ bị xóa bỏ
    UPDATE  tbOrganizationLedgerHM A 
    INNER JOIN fixed_asset_depreciation_detail B ON A.organization_id = B.organization_id AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
    set A.status = 2
    WHERE B.first_remaining_amount <= 0;

    UPDATE  tbOrganizationLedgerHM A 
    INNER JOIN fixed_asset_depreciation_detail B ON A.organization_id = B.organization_id AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
    set A.depreciation_value = B.first_remaining_amount 
    WHERE B.first_remaining_amount > 0;

    UPDATE fixed_asset_ledger fal
    INNER JOIN tbOrganizationLedgerHM B ON fal.organization_id = $OrganID AND fal.organization_id = B.organization_id and fal.voucher_id = B.voucher_id and fal.fixed_asset_id = B.fixed_asset_id AND B.status = 1
    set fal.depreciation_value = B.depreciation_value
    WHERE fal.voucher_type = 5;

    DELETE A FROM fixed_asset_ledger A
    INNER JOIN  tbOrganizationLedgerHM B ON A.organization_id = $OrganID AND A.organization_id = B.organization_id and A.voucher_id = B.voucher_id and A.fixed_asset_id = B.fixed_asset_id AND B.status = 2
    WHERE A.voucher_type = 5;

    DELETE A FROM fixed_asset_depreciation_detail A
    INNER JOIN  tbOrganizationLedgerHM B ON A.organization_id = $OrganID AND A.organization_id = B.organization_id and A.voucher_id = B.voucher_id and A.fixed_asset_id = B.fixed_asset_id AND B.status = 2;

    DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;
    CREATE TEMPORARY TABLE tbOrganizationFA
    SELECT organization_id, fixed_asset_id 
    FROM tbOrganizationLedgerHM
    GROUP BY organization_id, fixed_asset_id;

    DROP TEMPORARY TABLE IF EXISTS Temp_Jira_ReCallUpdateFAData;
    CREATE TEMPORARY TABLE Temp_Jira_ReCallUpdateFAData
    SELECT do.organization_code, fa.fixed_asset_code, fal.orgprice, fal.accum_depreciation_amount
    FROM tbOrganizationFA A
    INNER JOIN fixed_asset fa on A.organization_id = fa.organization_id and A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN dic_organization do on A.organization_id = do.organization_id
    INNER JOIN fixed_asset_ledger fal ON fal.voucher_type IN (1,8) AND fal.organization_id = do.organization_id AND A.fixed_asset_id = fal.fixed_asset_id;
       
    CALL Proc_Jira_ReCallUpdateFAData();

   DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerDGL;
   DROP TEMPORARY TABLE IF EXISTS tbOrganizationLedgerHM;
   DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;


END;

