SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL;

CREATE PROCEDURE Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL
(
IN $Organ_Code varchar(36), 
IN $FA_Code varchar(36), 
IN $OrgPrice decimal(19, 4), 
IN $DepreciationAmount decimal(19, 4), 
IN $DepreciationBusinessAmount decimal(19, 4)
)
  SQL SECURITY INVOKER
BEGIN
  DECLARE $Count int DEFAULT 0;
  DECLARE $i int DEFAULT 1;
  DECLARE $STT_GT int DEFAULT 100;
  DECLARE $VoucherType int DEFAULT 0;
  DECLARE $OrgpriceFA decimal(19, 4) DEFAULT 0;
  DECLARE $SumBudget decimal(19, 4) DEFAULT 0;
  DECLARE $LedgerBudgetID varchar(36);
  DECLARE $OrganizationID varchar(36);
  DECLARE $FixedAssetID varchar(36);
  DECLARE $FixedAssetType int;

  SET $OrganizationID = (SELECT do.organization_id FROM dic_organization do WHERE do.organization_code = $Organ_Code LIMIT 1);

  SELECT fa.fixed_asset_id, IFNULL(fa.fixed_asset_type, 1) 
  FROM fixed_asset fa 
  WHERE fa.organization_id = $OrganizationID AND fa.fixed_asset_code = $FA_Code LIMIT 1 
  INTO $FixedAssetID, $FixedAssetType;

  SET $DepreciationAmount = CASE WHEN $FixedAssetType = 2 THEN 0 ELSE $DepreciationAmount END;
  SET $DepreciationBusinessAmount = CASE WHEN $FixedAssetType = 1 THEN 0 ELSE $DepreciationBusinessAmount END;

  DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
  CREATE TEMPORARY TABLE tbUpdateData (
    STT int,
    fixed_asset_ledger_id bigint,
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    voucher_code varchar(100),
    voucher_type int,
    change_date datetime,
    orgprice decimal(19, 4),
    depreciation_value decimal(19, 4),
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  UPDATE fixed_asset_ledger fal
  set fal.change_date = CASE WHEN fal.voucher_type IN (1,8) THEN DATE_FORMAT(fal.change_date,'%Y-%m-%d 12:00:00')
                                                    WHEN fal.voucher_type IN (9) THEN DATE_FORMAT(fal.change_date,'%Y-%m-%d 14:00:00')
                                                    WHEN fal.voucher_type IN (5) THEN DATE_FORMAT(fal.change_date,'%Y-%m-%d 16:00:00')
                                         END 
  WHERE fal.organization_id = $OrganizationID and fal.fixed_asset_id = $FixedAssetID AND fal.voucher_type IN (1,5,8,9);

  UPDATE fa_ledger_inventory fal
  set fal.change_date = DATE_FORMAT(fal.change_date,'%Y-%m-%d 23:59:59')
  WHERE fal.organization_id = $OrganizationID and fal.fixed_asset_id = $FixedAssetID;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData2;
  CREATE TEMPORARY TABLE tbOrginData2
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT
  FROM (SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS depreciation_value,
      CASE WHEN $FixedAssetType = 1 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_amount ELSE 0 END AS depreciation_amount,
      CASE WHEN $FixedAssetType = 2 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_for_business_amount ELSE 0 END AS depreciation_for_business_amount,
      remaining_amount
    FROM fixed_asset_ledger
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID
    AND  (voucher_type <> 17 OR (voucher_type = 17 AND voucher_description LIKE '%chuy?n lo?i%'))
    UNION ALL
    SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      0 AS depreciation_value,
      CASE WHEN $FixedAssetType = 1 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_amount ELSE 0 END AS depreciation_amount,
      CASE WHEN $FixedAssetType = 2 THEN accum_depreciation_amount WHEN $FixedAssetType = 3 THEN depreciation_for_business_amount ELSE 0 END AS depreciation_for_business_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID) A;

    SET $STT_GT = (SELECT STT FROM tbOrginData2 WHERE voucher_type in (1,8) ORDER BY STT LIMIT 1);

   -- X�a b? ch?ng t? tru?c ghi tang
   DELETE FROM  tbOrginData2 WHERE STT <  $STT_GT;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData;
  CREATE TEMPORARY TABLE tbOrginData
  SELECT
    A.fixed_asset_ledger_id,
    A.fixed_asset_id,
    A.voucher_id,
    A.voucher_code,
    A.voucher_type,
    A.change_date,
    A.created_date,
    A.orgprice,
    A.depreciation_value,
    A.accum_depreciation_amount,
    A.depreciation_amount,
    A.depreciation_for_business_amount,
    A.remaining_amount,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY A.change_date, A.created_date) AS STT 
    FROM tbOrginData2 A;

IF EXISTS (SELECT 1 FROM tbOrginData od WHERE od.voucher_type in (1,8) AND od.STT = 1) AND $FixedAssetType = 3 THEN
BEGIN

    SELECT
    COUNT(1) INTO $Count
    FROM tbOrginData;

  WHILE $i <= $Count DO

    IF $i = 1 THEN
      INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, depreciation_value, depreciation_amount, depreciation_for_business_amount, remaining_amount)
        SELECT
          STT,
          fixed_asset_ledger_id,
          fixed_asset_id,
          voucher_id,
          voucher_code,
          voucher_type,
          change_date,
          $OrgPrice as orgprice,
          depreciation_value,
          IFNULL($DepreciationAmount, 0) AS depreciation_amount,
          IFNULL($DepreciationBusinessAmount, 0) AS depreciation_for_business_amount,
          IFNULL($OrgPrice, 0) - IFNULL($DepreciationAmount, 0) - IFNULL($DepreciationBusinessAmount, 0) AS remaining_amount
        FROM tbOrginData
        WHERE STT = $i;

      IF $i = $Count THEN

        -- C?p nh?t t�i s?n
        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
            A.depreciation_amount = B.depreciation_amount,
            A.depreciation_for_business_amount = B.depreciation_for_business_amount,
            A.remaining_amount = B.remaining_amount,
            A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(A.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
        WHERE A.organization_id = $OrganizationID;

        -- C?p nh?t detail ghi tang
        UPDATE fixed_asset_increment_detail A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
            A.depreciation_amount = B.depreciation_amount,
            A.depreciation_for_business_amount = B.depreciation_for_business_amount,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID;
      END IF;

    ELSE
      DROP TEMPORARY TABLE IF EXISTS tbCacheData;
      CREATE TEMPORARY TABLE tbCacheData
      SELECT
        *
      FROM tbUpdateData
      WHERE STT = $i - 1;

      SELECT
        voucher_type INTO $VoucherType
      FROM tbOrginData
      WHERE STT = $i;

      IF ($VoucherType IN (2, 10, 17)) THEN
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, depreciation_value, depreciation_amount, depreciation_for_business_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            IF($VoucherType  IN (17, 10), B.orgprice, A.orgprice) AS orgprice,
            0 AS depreciation_value,
            IF($VoucherType IN (17, 10), B.depreciation_amount, ifnull(A.accum_depreciation_amount,0) - ifnull(A.depreciation_for_business_amount,0)) AS depreciation_amount,
            IF($VoucherType IN (17, 10), B.depreciation_for_business_amount, A.depreciation_for_business_amount) AS depreciation_for_business_amount,
            IF($VoucherType  IN (17, 10), B.remaining_amount, IFNULL(A.remaining_amount, 0)) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      ELSE
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, depreciation_value, depreciation_amount, depreciation_for_business_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            B.orgprice,
            A.depreciation_value,
            IF($VoucherType = 5, IFNULL(B.depreciation_amount, 0) + IFNULL(A.depreciation_value, 0), IFNULL(B.depreciation_amount, 0)) AS depreciation_amount,
            IF($VoucherType = 9, IFNULL(B.depreciation_for_business_amount, 0) + IFNULL(A.depreciation_value, 0), IFNULL(B.depreciation_for_business_amount, 0)) AS depreciation_for_business_amount,
            IFNULL(B.remaining_amount, 0) - IFNULL(A.depreciation_value, 0) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      END IF;

      IF $i = $Count THEN

        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B
          ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
            A.depreciation_amount = B.depreciation_amount,
            A.depreciation_for_business_amount = B.depreciation_for_business_amount,
            A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
            A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
        WHERE A.organization_id = $OrganizationID
        AND B.STT = $Count;

      END IF;
    END IF;

    SET $i = $i + 1;
    SET $VoucherType = 0;
  END WHILE;

  -- C?p nh?t ledger to
  UPDATE fixed_asset_ledger A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type <> 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
  WHERE A.organization_id = $OrganizationID;


  -- C?p nh?t ledger hao m�n, kh?u hao
  UPDATE fa_ledger_depreciation A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (5, 9)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
  WHERE A.organization_id = $OrganizationID;

  -- C?p nh?t ledger ghi tang, gi?m
  UPDATE fa_ledger_increment_and_decrement A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (1, 8, 6)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END
  WHERE A.organization_id = $OrganizationID;

  -- C?p nh?t ledger ki?m k�
  UPDATE fa_ledger_inventory A
  INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.inventory_orgprice = IFNULL(B.orgprice,0) - IFNULL(A.difference_orgprice,0),
      A.inventory_remaining_amount = IFNULL(B.remaining_amount, 0) - IFNULL(A.difference_remaining_amount, 0),
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = CASE WHEN $FixedAssetType IN (2, 3) AND IFNULL(A.depreciation_for_business_price, 0) >= IFNULL(B.depreciation_for_business_amount, 0) 
                                                                THEN IFNULL(A.depreciation_for_business_price, 0) - IFNULL(B.depreciation_for_business_amount, 0) ELSE A.depreciation_for_business_remaining_amount END,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
  WHERE A.organization_id = $OrganizationID;

    -- Detail ghi tang
    UPDATE fixed_asset_increment_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 1) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Hao mon
    UPDATE fixed_asset_depreciation_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 5) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail KH
    UPDATE fixed_asset_depreciation_business_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 9) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_for_business_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Ghi giam
    UPDATE fixed_asset_decrement_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 6) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
    SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.depreciation_amount + B.depreciation_for_business_amount,
      A.depreciation_amount = B.depreciation_amount,
      A.depreciation_for_business_amount = B.depreciation_for_business_amount,
      A.remaining_amount = B.orgprice - B.depreciation_amount - B.depreciation_for_business_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;      

  -- L?y nguy�n gi� c?a t�i s?n
  set $OrgpriceFA = (SELECT orgprice FROM fixed_asset fa WHERE fa.fixed_asset_id = $FixedAssetID);

  -- Ledger budget c?a t�i s?n
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
  CREATE TEMPORARY TABLE tbLedgerBudgetFA
  SELECT lb.*
  FROM ledger_budget lb 
  INNER JOIN
  (
    SELECT * FROM
    (
      SELECT l.fixed_asset_id, IFNULL(l.voucher_id, '') AS voucher_id,
      ROW_NUMBER() OVER(PARTITION BY fixed_asset_id ORDER BY change_date DESC, created_date DESC) AS STT
      FROM ledger_budget l
      WHERE l.fixed_asset_id = $FixedAssetID AND IFNULL(voucher_type, 1) IN (1,2,8)
    ) A WHERE A.STT = 1
  ) A2 ON lb.fixed_asset_id = A2.fixed_asset_id AND IFNULL(lb.voucher_id, '') = A2.voucher_id;

  -- N?u nguy�n gi� kh�c v?i t?ng trong ledger budget th� c?p nh?t l?i
  IF (select SUM(amount) FROM tbLedgerBudgetFA) <> $OrgpriceFA THEN
      BEGIN

                 -- C?p nh?t d?i v?i tru?ng h?p ch? c� m?t ngu?n
                 IF (SELECT count(*) FROM tbLedgerBudgetFA) = 1 THEN
                 BEGIN
                    UPDATE  tbLedgerBudgetFA set amount = $OrgpriceFA;

                    UPDATE ledger_budget lb 
                    INNER JOIN tbLedgerBudgetFA lbf ON lb.organization_id = lbf.organization_id AND lb.ledger_budget_id = lbf.ledger_budget_id
                    set lb.amount = lbf.amount;
                 END;
                 END IF;

                -- Tru?ng h?p c� nhi?u ngu?n
                IF (SELECT count(*) FROM tbLedgerBudgetFA) > 1 THEN
                 BEGIN
                    SET $LedgerBudgetID = (SELECT ledger_budget_id FROM tbLedgerBudgetFA ORDER BY amount DESC LIMIT 1);

                    SET $SumBudget =  (SELECT sum(amount) FROM tbLedgerBudgetFA WHERE ledger_budget_id <> $LedgerBudgetID);

                    UPDATE ledger_budget lb 
                    set lb.amount = ifnull($OrgpriceFA,0) - ifnull($SumBudget,0)
                    WHERE lb.ledger_budget_id =  $LedgerBudgetID;

                 END;
                 END IF;
                 
      END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbCacheData;
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
    
END; 
END IF;
  
DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData2;

END;