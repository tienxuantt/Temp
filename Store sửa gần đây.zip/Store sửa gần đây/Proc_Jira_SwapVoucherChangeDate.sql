﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_SwapVoucherChangeDate;

CREATE PROCEDURE Proc_Jira_SwapVoucherChangeDate (IN $OrganizationID char(36), IN $VoucherIncrementID char(36), IN $VoucherTransferID char(36))
BEGIN

        -- Lấy ra dữ liệu
        DROP TEMPORARY TABLE IF EXISTS tblFAIncrementMaster;
        CREATE TEMPORARY TABLE tblFAIncrementMaster
        SELECT * FROM fixed_asset_increment fai WHERE fai.organization_id = $OrganizationID AND fai.voucher_id = $VoucherIncrementID; 

        DROP TEMPORARY TABLE IF EXISTS tblFATransferMaster;
        CREATE TEMPORARY TABLE tblFATransferMaster
        SELECT * FROM fixed_asset_transfer fai WHERE fai.organization_id = $OrganizationID AND fai.voucher_id = $VoucherTransferID; 

        DROP TEMPORARY TABLE IF EXISTS tblFAIncrementLedger;
        CREATE TEMPORARY TABLE tblFAIncrementLedger
        SELECT * FROM fixed_asset_ledger fai WHERE fai.organization_id = $OrganizationID AND fai.voucher_id = $VoucherIncrementID and fai.voucher_type IN (1,8); 

        -- Cập nhật dữ liệu
       UPDATE fixed_asset_increment fai
       INNER JOIN  tblFATransferMaster B ON fai.organization_id = B.organization_id
       set fai.voucher_date = B.voucher_date, fai.increment_date = B.transfer_date
       WHERE fai.organization_id = $OrganizationID AND fai.voucher_id = $VoucherIncrementID;

       UPDATE fixed_asset_ledger fai
       INNER JOIN  tblFATransferMaster B ON fai.organization_id = B.organization_id
       set fai.voucher_date = B.voucher_date, fai.change_date = B.transfer_date
       WHERE fai.organization_id = $OrganizationID AND fai.voucher_type IN (1,8) AND fai.voucher_id = $VoucherIncrementID; 

        -- 
       UPDATE fixed_asset_transfer  fai
       INNER JOIN  tblFAIncrementMaster B ON fai.organization_id = B.organization_id
       set fai.voucher_date = B.voucher_date, fai.transfer_date = B.increment_date
       WHERE fai.organization_id = $OrganizationID AND fai.voucher_id = $VoucherTransferID;

       UPDATE fixed_asset_ledger fai
       INNER JOIN  tblFAIncrementMaster B ON fai.organization_id = B.organization_id
       set fai.voucher_date = B.voucher_date, fai.change_date = B.increment_date
       WHERE fai.organization_id = $OrganizationID AND fai.voucher_type IN (3,7) AND fai.voucher_id = $VoucherTransferID; 

        UPDATE fixed_asset_ledger fal
        INNER JOIN fixed_asset_increment_detail faid on fal.organization_id = faid.organization_id AND fal.fixed_asset_id = faid.fixed_asset_id AND fal.voucher_type IN (1,8)
        set fal.orgprice = faid.orgprice, fal.accum_depreciation_amount = faid.accum_depreciation_amount, 
        fal.depreciation_amount = faid.depreciation_amount, fal.depreciation_for_business_amount = faid.depreciation_for_business_amount,
        fal.remaining_amount = faid.remaining_amount
        WHERE fal.organization_id = $OrganizationID AND faid.voucher_id = $VoucherIncrementID;

        SELECT CONCAT(" CALL Proc_Jira_Update_Depreciation_FixedAsset('",fal.organization_id,"','",fal.fixed_asset_id,"', ",ifnull(fal.accum_depreciation_amount,0),");" ) AS script 
        FROM tblFAIncrementLedger fal;

        DROP TEMPORARY TABLE IF EXISTS tblFAIncrementMaster;
        DROP TEMPORARY TABLE IF EXISTS tblFATransferMaster;
        DROP TEMPORARY TABLE IF EXISTS tblFAIncrementLedger;

END;

CALL Proc_Jira_SwapVoucherChangeDate('f7f07911-8f22-11ee-8651-18c04d80a749','f7f07911-8f22-11ee-8651-18c04d80a749','f7f07911-8f22-11ee-8651-18c04d80a749');

SELECT CONCAT("CALL Proc_Jira_SwapVoucherChangeDate('",fai.organization_id,"','",fai.voucher_id,"','",fat.voucher_id,"');")  AS script
FROM fixed_asset_ledger fai 
INNER JOIN fixed_asset_ledger fat ON fai.voucher_type IN (1,8) AND fat.voucher_type IN (3,7) AND fai.organization_id = fat.organization_id AND fai.fixed_asset_id = fat.fixed_asset_id AND fai.organization_id ='2d922057-7e4d-4e63-bd79-77174158fa54'
WHERE fai.change_date > fat.change_date AND YEAR(fai.change_date) = YEAR(fat.change_date) AND YEAR(fai.change_date) = 2016
GROUP BY fai.organization_id, fai.voucher_id, fat.voucher_id;

