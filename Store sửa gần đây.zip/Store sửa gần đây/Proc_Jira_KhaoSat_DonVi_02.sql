﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_KhaoSat_DonVi_02;

CREATE PROCEDURE Proc_Jira_KhaoSat_DonVi_02 (IN $maxFA int)
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $OrID varchar(36) DEFAULT '';

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;
    CREATE TEMPORARY TABLE tbOrganization
    SELECT do.organization_id 
    from dic_organization do 
    LEFT JOIN jira_organ_survey_ndmanh2 B ON do.organization_id = B.organization_id
    WHERE B.organization_id is null
    LIMIT $maxFA;

   INSERT jira_organ_survey_ndmanh2 (ID, organization_id)
   SELECT UUID(), organization_id
   FROM tbOrganization;
                                 
    SELECT
        COUNT(1) INTO $count
    FROM tbOrganization;

    WHILE $i < $count DO
        SELECT  organization_id INTO $OrID
        FROM tbOrganization
        LIMIT $i, 1;

            CALL Proc_Jira_KSDL_SL_NG_BC($OrID);

        SET $i = $i + 1;
    END WHILE;

    DROP TEMPORARY TABLE IF EXISTS tbOrganization;

END;

-- DELETE FROM jira_organ_survey_ndmanh;