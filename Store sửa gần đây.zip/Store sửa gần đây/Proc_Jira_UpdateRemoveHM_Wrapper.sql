﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateRemoveHM_Wrapper;

CREATE PROCEDURE Proc_Jira_UpdateRemoveHM_Wrapper (IN $MaxProcess int)
SQL SECURITY INVOKER
BEGIN
    DECLARE $i int DEFAULT 0;
    DECLARE $count int DEFAULT 0;
    DECLARE $organID varchar(36) DEFAULT '';
    DECLARE $fixedAssetID varchar(36) DEFAULT '';

    DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemWrapp;
    CREATE TEMPORARY TABLE tbOrganizationTemWrapp
    SELECT organization_id, fixed_asset_id 
    FROM fa_jira_execute
    WHERE IFNULL(type,0) <> 1
    LIMIT  $MaxProcess;

    UPDATE fa_jira_execute fje
    INNER JOIN tbOrganizationTemWrapp ot 
    on fje.organization_id = ot.organization_id and fje.fixed_asset_id = ot.fixed_asset_id
    set fje.type = 1;
                                 
    SELECT
        COUNT(1) INTO $count
    FROM tbOrganizationTemWrapp;

    WHILE $i < $count DO
        SELECT
            organization_id, fixed_asset_id INTO $organID, $fixedAssetID
        FROM tbOrganizationTemWrapp
        LIMIT $i, 1;

            CALL Proc_Jira_UpdateRemoveHM_02($organID, $fixedAssetID);

        SET $i = $i + 1;
    END WHILE;

    DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemWrapp;

END;



