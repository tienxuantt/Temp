﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_EquipementCategoryIDMiss;

CREATE PROCEDURE Proc_Jira_Update_EquipementCategoryIDMiss (IN $organization_id varchar(36))
BEGIN

        -- Lấy ra danh mục
        DROP TEMPORARY TABLE IF EXISTS tbCategoryEQ;
        CREATE TEMPORARY TABLE tbCategoryEQ
        SELECT * FROM 
        (
                SELECT 
                A.equipment_category_id,
                A.equipment_category_code,
                A.equipment_category_name,
                ROW_NUMBER() OVER(PARTITION BY A.equipment_category_master_id ORDER BY A.organization_id DESC) AS STT
                FROM dic_equipment_category A INNER JOIN dic_equipment_category_master B
                ON A.equipment_category_master_id = B.equipment_category_master_id
                WHERE A.organization_id IS NULL OR A.organization_id = $organization_id
        ) T WHERE T.STT = 1;

        -- Lấy ra CCDC bị mất loại
        DROP TEMPORARY TABLE IF EXISTS tbEquipmentMissCategory;
        CREATE TEMPORARY TABLE tbEquipmentMissCategory
        SELECT e.equipment_code, e.equipment_name, e.organization_id, e.equipment_id,  e.equipment_category_id, e.equipment_category_code, e.equipment_category_name 
        FROM equipment e
        WHERE e.organization_id = $organization_id AND (ifnull(e.equipment_category_id,'') = '' OR ifnull(e.equipment_category_name,'') = '');

        -- Lấy lại theo tên danh mục
        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON A.equipment_category_name = B.equipment_category_name
        set A.equipment_category_id = B.equipment_category_id,
        A.equipment_category_code = B.equipment_category_code
        WHERE ifnull(A.equipment_category_id,'') = '' AND IFNULL(A.equipment_category_name,'') <> '';

        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON A.equipment_category_id = B.equipment_category_id
        set A.equipment_category_name = B.equipment_category_name,
        A.equipment_category_code = B.equipment_category_code
        WHERE ifnull(A.equipment_category_name,'') = '' AND IFNULL(A.equipment_category_id,'') <> '';

        -- Cập nhật CCDC bàn
        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON A.equipment_name LIKE '%bàn%' AND B.equipment_category_name  LIKE '%bàn%'
        set A.equipment_category_id = B.equipment_category_id,
        A.equipment_category_code = B.equipment_category_code,
        A.equipment_category_name = B.equipment_category_name
        WHERE ifnull(A.equipment_category_id,'') = '';

        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON A.equipment_name LIKE '%tranh%' AND B.equipment_category_name  LIKE '%tranh%'
        set A.equipment_category_id = B.equipment_category_id,
        A.equipment_category_code = B.equipment_category_code,
        A.equipment_category_name = B.equipment_category_name
        WHERE ifnull(A.equipment_category_id,'') = '';

        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON A.equipment_name = B.equipment_category_name 
        set A.equipment_category_id = B.equipment_category_id,
        A.equipment_category_code = B.equipment_category_code,
        A.equipment_category_name = B.equipment_category_name
        WHERE ifnull(A.equipment_category_id,'') = '';

        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON  B.equipment_category_name LIKE CONCAT("%", SUBSTRING_INDEX(SUBSTRING_INDEX(A.equipment_name, ' ', 1), ' ', -1),"%") 
        set A.equipment_category_id = B.equipment_category_id,
        A.equipment_category_code = B.equipment_category_code,
        A.equipment_category_name = B.equipment_category_name
        WHERE ifnull(A.equipment_category_id,'') = '';

        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON  B.equipment_category_name  = 'CCDC'
        set A.equipment_category_id = B.equipment_category_id,
        A.equipment_category_code = B.equipment_category_code,
        A.equipment_category_name = B.equipment_category_name
        WHERE ifnull(A.equipment_category_id,'') = '';

        UPDATE tbEquipmentMissCategory A
        INNER JOIN  tbCategoryEQ B ON  B.equipment_category_name  LIKE 'CCDC%'
        set A.equipment_category_id = B.equipment_category_id,
        A.equipment_category_code = B.equipment_category_code,
        A.equipment_category_name = B.equipment_category_name
        WHERE ifnull(A.equipment_category_id,'') = '';

        UPDATE equipment e
        INNER JOIN tbEquipmentMissCategory emc ON e.organization_id = emc.organization_id AND e.equipment_id = emc.equipment_id
        set e.equipment_category_id = emc.equipment_category_id,
        e.equipment_category_code = emc.equipment_category_code,
        e.equipment_category_name = emc.equipment_category_name
        WHERE emc.equipment_category_id IS NOT NULL;

        UPDATE equipment_ledger e
        INNER JOIN tbEquipmentMissCategory emc ON e.organization_id = emc.organization_id AND e.equipment_id = emc.equipment_id
        set e.equipment_category_id = emc.equipment_category_id,
        e.equipment_category_code = emc.equipment_category_code,
        e.equipment_category_name = emc.equipment_category_name
        WHERE emc.equipment_category_id IS NOT NULL;

        UPDATE equipment_ledger_inventory e
        INNER JOIN tbEquipmentMissCategory emc ON e.organization_id = emc.organization_id AND e.equipment_id = emc.equipment_id
        set e.equipment_category_id = emc.equipment_category_id,
        e.equipment_category_code = emc.equipment_category_code,
        e.equipment_category_name = emc.equipment_category_name
        WHERE emc.equipment_category_id IS NOT NULL;
         
END;

CALL Proc_Jira_Update_EquipementCategoryIDMiss('b1e34708-7f18-4c89-9f6c-f230f4187c6d');

SELECT e.equipment_id,  e.equipment_category_id, e.equipment_category_code, e.equipment_category_name FROM equipment e WHERE e.equipment_id = '5c79a979-d4d3-4432-b083-ecb6d3b45d84';

SELECT e.equipment_code, e.equipment_name, e.organization_id , do.organization_code, e.equipment_id,  e.equipment_category_id, e.equipment_category_code, e.equipment_category_name 
FROM equipment e
INNER JOIN dic_organization do on e.organization_id = do.organization_id
WHERE ifnull(e.equipment_category_id,'') = '' OR IFNULL(e.equipment_category_name, '') = ''
ORDER BY do.organization_code;

SELECT CONCAT("CALL Proc_Jira_Update_EquipementCategoryIDMiss('",e.organization_id,"');")  as Data
FROM equipment e
WHERE ifnull(e.equipment_category_id,'') = '' OR ifnull(e.equipment_category_name,'') = ''
GROUP BY e.organization_id;

SELECT el.equipment_category_id, el.equipment_category_name FROM equipment_ledger el WHERE el.voucher_id = '0a4843b1-c83d-47a3-96e1-df0e5c87bdb8' AND el.equipment_id = '582dd2c3-3a25-4c50-85a3-c1e84157bb1a';

SELECT SUBSTRING_INDEX(SUBSTRING_INDEX(e.equipment_name, ' ', 1), ' ', -1) AS result , e.equipment_name
FROM equipment e LIMIT 100;
