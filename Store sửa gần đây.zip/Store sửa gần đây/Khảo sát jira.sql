﻿INSERT dic_fixed_asset_category_master (fixed_asset_category_master_id, fixed_asset_category_code, parent_id, is_parent, misa_code_id, public_asset_type, effect_year, created_date, created_by, modified_date, modified_by, is_data_convert, grade, is_system, convert_circular_id)
SELECT
A.fixed_asset_category_master_id,
A.fixed_asset_category_code,
A.parent_id,
A.is_parent,
NULL as misa_code_id,
A.public_asset_type,
A.effect_year,
A.created_date,
A.created_by,
A.modified_date,
A.modified_by,
A.is_data_convert,
NULL as grade,
NULL as is_system,
A.convert_circular_id
FROM dic_fixed_asset_category A
LEFT JOIN dic_fixed_asset_category_master dfacm1 ON dfacm1.fixed_asset_category_master_id = A.fixed_asset_category_master_id
WHERE dfacm1.fixed_asset_category_master_id IS NULL;

update fixed_asset fa1
INNER JOIN (
  SELECT
  SUM(IF(fa.status_id = 1, 1,0)) AS TotalDangSuDung,
  SUM(IF(fa.status_id = 2, 1,0)) AS TotalChuaGhiTang,
  SUM(IF(fa.status_id = 3, 1,0)) AS TotalDaGhiGiam,
  COUNT(*) AS Total,
  fa.parent_id
  FROM fixed_asset fa
  WHERE fa.parent_id IS NOT NULL
  GROUP BY fa.parent_id
) K ON fa1.fixed_asset_id = K.parent_id
SET fa1.status_id = CASE WHEN K.TotalDangSuDung > 0 THEN 1
                         WHEN K.TotalDaGhiGiam = K.Total THEN 3
                         WHEN K.TotalChuaGhiTang = K.Total THEN 2 ELSE fa1.status_id END
WHERE fa1.is_parent = 1
AND
(
 (fa1.status_id = 3 AND K.Total <> K.TotalDaGhiGiam)
 OR
 (fa1.status_id = 2 AND K.Total <> K.TotalChuaGhiTang)
 OR
 (fa1.status_id = 1 AND (K.TotalDaGhiGiam = K.Total OR K.TotalChuaGhiTang = K.Total))
);

SELECT fal.voucher_id, fal.fixed_asset_id, fal.change_date, MAX(fal.fixed_asset_ledger_id) AS ID  
FROM fixed_asset_ledger fal
WHERE fal.voucher_type = 5
GROUP BY fal.voucher_id, fal.fixed_asset_id, fal.change_date
HAVING COUNT(*) > 1;

SELECT fadd.fixed_asset_id
FROM fixed_asset_depreciation_detail fadd
INNER JOIN fixed_asset_ledger fal ON fadd.organization_id = fal.organization_id AND fadd.voucher_id = fal.voucher_id and fadd.fixed_asset_id = fal.fixed_asset_id
WHERE fadd.depreciation_value <> fal.depreciation_value;


SELECT fal.fixed_asset_code, do.organization_code, fal.voucher_code 
FROM fixed_asset_ledger fal
INNER JOIN fixed_asset_depreciation_detail fadd ON fal.organization_id = fadd.organization_id and fal.voucher_id = fadd.voucher_id and fal.fixed_asset_id = fadd.fixed_asset_id
INNER JOIN dic_organization do on fal.organization_id = do.organization_id
WHERE fal.voucher_type = 5 AND  ifnull(fadd.first_remaining_amount,0) - ifnull(fadd.depreciation_value,0) <> IFNULL(fal.remaining_amount,0)
ORDER BY do.organization_code;

select fa.fixed_asset_code, do.organization_code
from fixed_asset fa 
inner JOIN 
(
    select fal.organization_id, fal.fixed_asset_id, fal.remaining_amount, fal.orgprice, 
    row_number() over(partition by fixed_asset_id order by change_date desc, created_date desc, fal.fixed_asset_ledger_id DESC) rn 
    from fixed_asset_ledger fal
    WHERE fal.voucher_type <> 17
) tm on fa.organization_id = tm.organization_id and fa.fixed_asset_id = tm.fixed_asset_id and tm.rn = 1
INNER JOIN dic_organization do on fa.organization_id = do.organization_id 
where ifnull(fa.orgprice, 0) <> ifnull(tm.orgprice, 0) and ifnull(fa.is_parent, 0) = 0 and ifnull(fa.orgprice,0) = 0
GROUP BY fa.fixed_asset_code, do.organization_code;

SELECT do.organization_code, e.equipment_code, e.department_name, e.quantity, B.quantity AS quantity_correct
FROM equipment e
INNER JOIN dic_organization do ON e.organization_id = do.organization_id
INNER JOIN
(
  SELECT el.equipment_id, SUM(IF(el.voucher_type IN (1,6,7), el.quantity, (-1)*el.quantity))AS quantity
  FROM equipment_ledger el
  WHERE el.voucher_type IN (1,2,3,6,7)
  GROUP BY el.equipment_id
) B ON e.equipment_id = B.equipment_id
WHERE e.quantity <> B.quantity AND B.equipment_id = '7d29d13c-f8a0-4271-8ea7-9bef7e29e854'
ORDER BY do.organization_code;

SELECT el.equipment_id, count(*)  
FROM equipment_ledger el
WHERE el.voucher_type = 6
GROUP BY el.equipment_id, el.voucher_type
HAVING COUNT(*) > 1;

DELETE A1 FROM equipment_ledger A1
INNER JOIN
(
    SELECT A.equipment_ledger_id
    FROM 
    (
        SELECT el.equipment_ledger_id,
        ROW_NUMBER() OVER(PARTITION BY equipment_id ORDER BY el.change_date DESC, el.created_date DESC) AS STT 
        FROM equipment_ledger el
        WHERE el.voucher_type = 6
    ) A WHERE A.STT > 1
) B1 ON A1.equipment_ledger_id = B1.equipment_ledger_id;

SELECT fli.fixed_asset_id, fli.voucher_code, fli.fixed_asset_code, fli.change_date, fli.voucher_date, fli.created_date  
FROM fa_ledger_inventory fli 
WHERE fli.voucher_id = 'c0545a44-104c-4381-9054-b7bc8d93c795' AND fli.fixed_asset_id = '01ddd9d9-cde2-414c-9896-f77000855c93'
UNION ALL
SELECT fli.fixed_asset_id, fli.voucher_code, fli.fixed_asset_code,fli.change_date, fli.voucher_date, fli.created_date  
FROM fa_ledger_inventory fli 
WHERE fli.voucher_id = '26c65252-c80b-4040-a132-9a32af7ad66c' AND fli.fixed_asset_id = '01ddd9d9-cde2-414c-9896-f77000855c93';


SELECT * FROM 
(
    SELECT *, row_number() OVER(PARTITION BY  dfac.fixed_asset_category_master_id ORDER BY dfac.organization_id DESC) AS STT
    FROM dic_fixed_asset_category dfac 
    INNER JOIN dic_fixed_asset_category_master dfacm 
    ON dfacm.fixed_asset_category_master_id = dfac.fixed_asset_category_master_id
    WHERE dfac.organization_id is NULL OR dfac.organization_id = $organ
)A WHERE A.STT = 1;


SELECT eli.voucher_id, eli.voucher_code, eli.change_date, eli.voucher_date, eli.created_date FROM equipment_ledger_inventory eli WHERE eli.voucher_id ='d51da295-ec12-4552-a01a-67d8e85d722f';

SELECT eli.voucher_id, eli.voucher_code, eli.change_date, eli.voucher_date, eli.created_date FROM equipment_ledger eli WHERE eli.voucher_id ='3f2b8b2b-0cb5-4157-866e-6d9efbab836d';
-- 3f2b8b2b-0cb5-4157-866e-6d9efbab836d

SELECT fa.fixed_asset_code, fa.software_start_time, do.organization_code
FROM fixed_asset fa
INNER JOIN dic_organization do ON fa.organization_id = do.organization_id
INNER JOIN fixed_asset_ledger fal ON fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id
WHERE fa.public_asset_type <> fal.public_asset_type
GROUP BY fa.fixed_asset_code, fa.software_start_time, do.organization_code
ORDER BY do.organization_code ;

SELECT fal.fixed_asset_code, fal.public_asset_type, fa.public_asset_type AS fa_pub, fal.voucher_type, fal.change_date
FROM fixed_asset fa
INNER JOIN dic_organization do ON fa.organization_id = do.organization_id
INNER JOIN fixed_asset_ledger fal ON fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id
WHERE fa.public_asset_type <> fal.public_asset_type
ORDER BY do.organization_code ;

SELECT fadb.voucher_code, fadb.created_date, fadb.modified_date 
FROM fixed_asset_depreciation_business fadb
INNER JOIN dic_organization do ON fadb.organization_id = do.organization_id
WHERE do.organization_code = '1124743' AND  fadb.voucher_code IN ( 'KH.00010', 'KH00011', 'KH00012');

SELECT faid.fixed_asset_code
 FROM fixed_asset_increment_detail faid 
INNER JOIN fixed_asset_ledger fal on faid.organization_id = fal.organization_id AND faid.voucher_id = fal.voucher_id and faid.fixed_asset_id = fal.fixed_asset_id
WHERE fal.voucher_type = 1 AND faid.orgprice <> fal.orgprice and faid.organization_id ='629d4430-8efe-4eed-9c3d-ae135507323d';

SELECT fa.fixed_asset_id, fa.software_start_time, fa.increment_date, fa.purchase_date, fa.depreciation_start_date
FROM fixed_asset fa
INNER JOIN fixed_asset_ledger fal ON fal.voucher_type = 1 AND fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id
WHERE fa.software_start_time = YEAR(fa.increment_date) AND fa.software_start_time = YEAR(fa.purchase_date) AND fa.software_start_time = YEAR(fa.depreciation_start_date)
AND ifnull(fal.accum_depreciation_amount,0) > 0;

SELECT fa.fixed_asset_id, fa.software_start_time, fa.increment_date, fa.purchase_date, fa.depreciation_start_date
FROM fixed_asset fa
INNER JOIN fixed_asset_ledger fal ON fal.voucher_type = 1 AND fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id
LEFT JOIN
(
    SELECT fal.organization_id, fal.fixed_asset_id 
    FROM fixed_asset_ledger fal 
    WHERE fal.voucher_type IN (2,5) 
    GROUP BY fal.organization_id, fal.fixed_asset_id
)  C ON  fa.organization_id = C.organization_id AND fa.fixed_asset_id = C.fixed_asset_id
WHERE
C.fixed_asset_id IS NULL 
AND fa.software_start_time >= 2023 
AND fa.software_start_time = YEAR(fa.increment_date) 
AND fa.software_start_time = YEAR(fa.purchase_date) 
AND fa.software_start_time = YEAR(fa.depreciation_start_date)
AND ifnull(fal.accum_depreciation_amount,0) > 0;

SELECT do.organization_code, fa.fixed_asset_code, fa.fixed_asset_id, fa.software_start_time, fa.increment_date, fa.purchase_date, fa.depreciation_start_date
FROM fixed_asset fa
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
INNER JOIN fixed_asset_ledger fal ON fal.voucher_type = 1 AND fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id
LEFT JOIN
(
    SELECT fal.organization_id, fal.fixed_asset_id 
    FROM fixed_asset_ledger fal 
    WHERE fal.voucher_type IN (2,5) 
    GROUP BY fal.organization_id, fal.fixed_asset_id
)  C ON  fa.organization_id = C.organization_id AND fa.fixed_asset_id = C.fixed_asset_id
WHERE
C.fixed_asset_id IS NULL 
AND fa.software_start_time >= 2023 
AND fa.software_start_time = YEAR(fa.increment_date) 
AND fa.software_start_time = YEAR(fa.purchase_date) 
AND fa.software_start_time = YEAR(fa.depreciation_start_date)
AND ifnull(fal.accum_depreciation_amount,0) > 0
ORDER BY do.organization_code;

SELECT CONCAT("CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT('",do.organization_code,"','",fa.fixed_asset_code,"',",fal.orgprice,",",0,");") as script
FROM fixed_asset fa
INNER JOIN dic_organization do on fa.organization_id = do.organization_id
INNER JOIN fixed_asset_ledger fal ON fal.voucher_type = 1 AND fa.organization_id = fal.organization_id AND fa.fixed_asset_id = fal.fixed_asset_id
LEFT JOIN
(
    SELECT fal.organization_id, fal.fixed_asset_id 
    FROM fixed_asset_ledger fal 
    WHERE fal.voucher_type IN (2,5) 
    GROUP BY fal.organization_id, fal.fixed_asset_id
)  C ON  fa.organization_id = C.organization_id AND fa.fixed_asset_id = C.fixed_asset_id
WHERE
C.fixed_asset_id IS NULL 
AND fa.software_start_time >= 2023 
AND fa.software_start_time = YEAR(fa.increment_date) 
AND fa.software_start_time = YEAR(fa.purchase_date) 
AND fa.software_start_time = YEAR(fa.depreciation_start_date)
AND ifnull(fal.accum_depreciation_amount,0) > 0
ORDER BY do.organization_code;

SELECT fal.fixed_asset_id 
FROM fixed_asset_ledger fal 
WHERE fal.voucher_type IN (2,5) 
GROUP BY fal.fixed_asset_id;

update fixed_asset_ledger set depreciation_amount=13372450, accum_depreciation_amount = 13372450 where  voucher_id ='3fd58045-9f6b-42f2-b972-6a1d3cf12d09' and organization_id ='8a801a75-d58a-4a2e-9c4c-3efb09ac2c2a' 
AND fixed_asset_id ='3fd58045-9f6b-42f2-b972-6a1d3cf12d09';

SELECT * FROM activity_diary ad LIMIT 10;