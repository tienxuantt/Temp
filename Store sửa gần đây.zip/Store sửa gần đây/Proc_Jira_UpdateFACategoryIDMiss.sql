﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateFACategoryIDMiss;

CREATE PROCEDURE Proc_Jira_UpdateFACategoryIDMiss (IN $OrganizationID char(36), IN $FixedAssetID char(36))
BEGIN

  SELECT
    fa.convert_circular_id,
    fa.depreciation_rate,
    fa.number_of_year,
    fa.group_fixed_asset_category_id INTO @convert_id, @depreciation_rate, @number_of_year, @group_fixed_asset_category_id
  FROM fixed_asset fa
    INNER JOIN dic_organization do
      ON fa.organization_id = do.organization_id
  WHERE do.organization_id = $OrganizationID
  AND fa.fixed_asset_id = $FixedAssetID;

  SELECT
    dfac.fixed_asset_category_id,
    dfac.fixed_asset_category_code,
    dfac.fixed_asset_category_name INTO @category_id, @category_code, @category_name
  FROM dic_fixed_asset_category dfac
  WHERE dfac.depreciation_rate = @depreciation_rate
  AND dfac.number_of_year = @number_of_year
  AND dfac.group_fixed_asset_category_id = @group_fixed_asset_category_id
  AND dfac.convert_circular_id = @convert_id
  AND (dfac.organization_id IS NULL
  OR dfac.organization_id = $OrganizationID)
  ORDER BY dfac.organization_id DESC
  LIMIT 1;

  UPDATE fixed_asset fa
  SET fa.fixed_asset_category_id = @category_id,
      fa.fixed_asset_category_code = @category_code,
      fa.fixed_asset_category_name = @category_name
  WHERE fa.fixed_asset_id = $FixedAssetID;

END;