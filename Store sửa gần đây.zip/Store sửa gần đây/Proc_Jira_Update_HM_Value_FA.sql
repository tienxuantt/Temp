﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Update_HM_Value_FA;

CREATE PROCEDURE Proc_Jira_Update_HM_Value_FA (IN $FixedAssetID varchar(36), IN $DepreciationValue decimal(19,4))
BEGIN

    UPDATE fixed_asset_ledger fal
    INNER JOIN fixed_asset_depreciation_detail fadd on fal.organization_id = fadd.organization_id and fal.fixed_asset_id = fadd.fixed_asset_id and fal.voucher_id = fadd.voucher_id
    set fal.depreciation_value = fadd.depreciation_value
    WHERE fal.voucher_type = 5 AND fadd.fixed_asset_id = $FixedAssetID AND  ifnull(fal.depreciation_value ,0) <> IFNULL(fadd.depreciation_value, 0);


    IF ($DepreciationValue >= 0) THEN
        UPDATE fixed_asset_depreciation_detail fadd
        set fadd.depreciation_value = $DepreciationValue
        WHERE fadd.depreciation_value < 0 AND fadd.fixed_asset_id = $FixedAssetID;
    
        UPDATE fixed_asset_ledger fal
        set fal.depreciation_value = $DepreciationValue
        WHERE fal.fixed_asset_id = $FixedAssetID AND fal.voucher_type = 5 AND fal.depreciation_value < 0;
    END IF;

    CALL Proc_Jira_ReCallUpdateFAData($FixedAssetID);
   
END;

-- DELETE FROM jira_organ_survey_ndmanh;                                                