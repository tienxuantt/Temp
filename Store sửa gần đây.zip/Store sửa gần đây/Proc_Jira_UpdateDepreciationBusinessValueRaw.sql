﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateDepreciationBusinessValueRaw;

CREATE PROCEDURE Proc_Jira_UpdateDepreciationBusinessValueRaw (IN $voucher_id varchar(36), IN $fixed_asset_id varchar(36), IN $depreciation_for_business_value decimal(19, 4))
SQL SECURITY INVOKER
BEGIN

    DECLARE $organ_id varchar(36);

    SELECT
        fa.organization_id INTO $organ_id
    FROM fixed_asset fa
    WHERE fa.fixed_asset_id = $fixed_asset_id LIMIT 1;

    UPDATE fixed_asset_depreciation_business_detail  A
    SET A.depreciation_for_business_value = $depreciation_for_business_value
    WHERE A.voucher_id = $voucher_id
    AND A.fixed_asset_id = $fixed_asset_id
    AND A.depreciation_for_business_value <> $depreciation_for_business_value;

    UPDATE fixed_asset_ledger A
    SET A.depreciation_for_business_value = $depreciation_for_business_value
    WHERE A.voucher_id = $voucher_id
    AND A.fixed_asset_id = $fixed_asset_id
    AND A.voucher_type = 9
    AND A.depreciation_for_business_value <> $depreciation_for_business_value;

    UPDATE fixed_asset_depreciation_business fad
    INNER JOIN (SELECT
            fadd.organization_id,
            fadd.voucher_id,
            SUM(ROUND(fadd.depreciation_for_business_value)) AS TotalMoney
        FROM fixed_asset_depreciation_business_detail fadd
        WHERE fadd.organization_id = $organ_id AND fadd.voucher_id = $voucher_id
        GROUP BY fadd.organization_id,
                 fadd.voucher_id) B
        ON B.organization_id = fad.organization_id
        AND B.voucher_id = fad.voucher_id
    SET fad.total_price = B.TotalMoney
    WHERE fad.organization_id = $organ_id AND fad.voucher_id = $voucher_id
    AND fad.total_price <> B.TotalMoney;

    CALL Proc_Jira_ReCallUpdateFAData($fixed_asset_id);

    DROP TEMPORARY TABLE IF EXISTS tblFaUpdateValue;

END ;

SELECT fadd.fixed_asset_code,  CONCAT("CALL Proc_Jira_UpdateDepreciationBusinessValueRaw('",fadd.voucher_id,"','",fadd.fixed_asset_id,"', ",fadd.depreciation_for_business_remaining_amount,");") as Data
FROM fixed_asset_depreciation_business_detail fadd
INNER JOIN fixed_asset fa ON fadd.organization_id = fa.organization_id and fadd.fixed_asset_id = fa.fixed_asset_id 
WHERE fa.convert_circular_id = 4 
AND fadd.organization_id = '289800af-cf21-4742-b5f8-d8bfdad2627a'
AND fadd.depreciation_for_business_remaining_amount < fadd.depreciation_for_business_value;

SELECT CONCAT("CALL Proc_Jira_Update_Revaluation_NewEqualOld_ByFA('",fal.voucher_id,"','",fal.fixed_asset_id,"');") as Data
FROM fixed_asset_ledger fal 
INNER JOIN fixed_asset_revaluation far on fal.organization_id = far.organization_id AND fal.voucher_id = far.voucher_id AND fal.fixed_asset_id = far.fixed_asset_id
WHERE fal.remaining_amount < 0 
and fal.voucher_type = 2
AND fal.convert_circular_id = 4
and fal.organization_id ='289800af-cf21-4742-b5f8-d8bfdad2627a';

SELECT fadd.fixed_asset_code,  CONCAT("CALL Proc_Jira_UpdateDepreciationValueRaw('",fadd.voucher_id,"','",fadd.fixed_asset_id,"', ",fadd.first_remaining_amount,");") as Data
FROM fixed_asset_depreciation_detail fadd
INNER JOIN fixed_asset fa ON fadd.organization_id = fa.organization_id and fadd.fixed_asset_id = fa.fixed_asset_id 
WHERE fa.convert_circular_id = 4 
AND fadd.organization_id = '289800af-cf21-4742-b5f8-d8bfdad2627a'
AND fadd.first_remaining_amount < fadd.depreciation_value;