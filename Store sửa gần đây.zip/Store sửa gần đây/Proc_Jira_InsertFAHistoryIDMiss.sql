﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_InsertFAHistoryIDMiss;

CREATE PROCEDURE Proc_Jira_InsertFAHistoryIDMiss (IN $OrganizationID char(36))
BEGIN

        -- Danh mục của đơn vị
        DROP TEMPORARY TABLE IF EXISTS tblFAcategory;
        CREATE TEMPORARY TABLE tblFAcategory    
        SELECT * FROM 
        (
            SELECT dfac.* ,
            row_number() OVER(PARTITION BY  dfacm.fixed_asset_category_master_id ORDER BY dfac.organization_id DESC) AS STT
            FROM dic_fixed_asset_category_master dfacm 
            INNER JOIN dic_fixed_asset_category dfac 
            ON dfacm.fixed_asset_category_master_id = dfac.fixed_asset_category_master_id
            WHERE (dfac.organization_id IS NULL OR dfac.organization_id = $OrganizationID) AND dfac.convert_circular_id = 4
        )  G1 WHERE G1.STT = 1;

        -- Các tài sản đang bị thiếu từ 3 -> 4
        DROP TEMPORARY TABLE IF EXISTS tblFAMiss;
        CREATE TEMPORARY TABLE tblFAMiss
        SELECT fa.fixed_asset_id, fa.fixed_asset_code, fa.software_start_time, fa.convert_circular_id, fa.fixed_asset_name 
        FROM fixed_asset fa
        LEFT JOIN (
            SELECT cch.fixed_asset_id FROM convert_circular_history cch WHERE cch.circular_source_id = 3 AND cch.convert_circular_id = 4
        )  T ON T.fixed_asset_id = fa.fixed_asset_id
        WHERE fa.organization_id = $OrganizationID
        AND T.fixed_asset_id IS NULL 
        AND fa.convert_circular_id >= 4 
        AND fa.software_start_time <  (SELECT cc.effect_year FROM convert_circular cc WHERE cc.convert_circular_id = 4);

      -- Lấy ra các mapping từ 3 -> 4
      DROP TEMPORARY TABLE IF EXISTS tblFAmapping;
      CREATE TEMPORARY TABLE tblFAmapping
      SELECT * 
      FROM fixed_asset_category_mapping facm 
      WHERE facm.convert_circular_id_source = 3 
      AND facm.convert_circular_id_destination = 4;

      -- Lấy ra các lịch sử đang ở 3
      DROP TEMPORARY TABLE IF EXISTS tblFAhistory;
      CREATE TEMPORARY TABLE tblFAhistory
      SELECT * 
      FROM convert_circular_history cch 
      WHERE cch.convert_circular_id = 3 AND cch.organization_id = $OrganizationID;

    -- Insert vào cho loại 4
    INSERT convert_circular_history (convert_circular_id, fixed_asset_id, fixed_asset_code, fixed_asset_name, fixed_asset_category_id_old, fixed_asset_category_id_new, effect_year, is_auto_convert, depreciation_rate, number_of_year, change_date, remaining_number_of_year, depreciation_end_date, depreciation_date, depreciation_year, organization_id, effected_to_ledger_id, is_data_convert, circular_source_id, fixed_asset_category_name_old, fixed_asset_category_code_old, fixed_asset_category_name_new, fixed_asset_category_code_new, fixed_asset_revaluation_id, parent_id, created_by, created_date, modified_by, modified_date, group_fixed_asset_category_id_old, group_fixed_asset_category_id_new, revaluation_ref_ids, public_asset_type_new, public_asset_type_old)
    SELECT 
       4 AS  convert_circular_id,
       A.fixed_asset_id,
       A.fixed_asset_code,
       A.fixed_asset_name,
       B.fixed_asset_category_id_new AS  fixed_asset_category_id_old,
       D.fixed_asset_category_id AS  fixed_asset_category_id_new,
       D.effect_year,
       0 AS  is_auto_convert,
       D.depreciation_rate,
       D.number_of_year,
       null AS  change_date,
       null AS remaining_number_of_year,
       null AS depreciation_end_date,
       null AS depreciation_date,
       null AS depreciation_year,
       B.organization_id,
       null AS effected_to_ledger_id,
       0 AS is_data_convert,
       3 AS  circular_source_id,
       B.fixed_asset_category_name_new AS  fixed_asset_category_name_old,
       B.fixed_asset_category_code_new AS   fixed_asset_category_code_old,
       D.fixed_asset_category_name AS  fixed_asset_category_name_new,
       D.fixed_asset_category_code AS  fixed_asset_category_code_new,
       null AS  fixed_asset_revaluation_id,
       null AS  parent_id,
       null AS created_by,
       null AS  created_date,
       null AS modified_by,
       null AS modified_date,
       null AS group_fixed_asset_category_id_old,
       null AS   group_fixed_asset_category_id_new,
       null AS revaluation_ref_ids,
       null AS  public_asset_type_new,
       null AS   public_asset_type_old 
     FROM tblFAMiss A 
     INNER JOIN tblFAhistory B ON A.fixed_asset_id = B.fixed_asset_id
     INNER JOIN  tblFAmapping C ON B.fixed_asset_category_code_new = C.fixed_asset_category_source_code
     INNER JOIN tblFAcategory D ON C.fixed_asset_category_destination_code = D.fixed_asset_category_code;

      DROP TEMPORARY TABLE IF EXISTS tblFAMiss;
      DROP TEMPORARY TABLE IF EXISTS tblFAmapping;
      DROP TEMPORARY TABLE IF EXISTS tblFAhistory;
      DROP TEMPORARY TABLE IF EXISTS tblFAcategory;

END;

SELECT CONCAT("CALL Proc_Jira_InsertFAHistoryIDMiss('",fa.organization_id,"');") AS script
FROM fixed_asset fa
LEFT JOIN (
    SELECT cch.fixed_asset_id FROM convert_circular_history cch WHERE cch.circular_source_id = 3 AND cch.convert_circular_id = 4
)  T ON T.fixed_asset_id = fa.fixed_asset_id
WHERE  T.fixed_asset_id IS NULL 
AND fa.convert_circular_id >= 4 
AND fa.software_start_time <  (SELECT cc.effect_year FROM convert_circular cc WHERE cc.convert_circular_id = 4)
GROUP BY fa.organization_id;