﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateDepreciationValueGrowByFA;

CREATE PROCEDURE Proc_Jira_UpdateDepreciationValueGrowByFA (IN $fixed_asset_id varchar(36))
SQL SECURITY INVOKER
BEGIN

      DECLARE $organ_id varchar(36);

      SELECT fa.organization_id INTO $organ_id FROM fixed_asset fa WHERE fa.fixed_asset_id = $fixed_asset_id LIMIT 1;
  
      DROP TEMPORARY TABLE IF EXISTS tblFaUpdateValue;
      CREATE TEMPORARY TABLE tblFaUpdateValue
      SELECT IFNULL(fal.depreciation_value,0) + IFNULL(fal.remaining_amount, 0) AS  depreciation_value,
      fal.voucher_id,
      fal.fixed_asset_id,
      fal.organization_id
      FROM fixed_asset_ledger fal
      WHERE fal.organization_id = $organ_id AND fal.fixed_asset_id = $fixed_asset_id 
      AND fal.voucher_type = 5 
      AND fal.remaining_amount < 10 
      AND fal.remaining_amount > 0;

     UPDATE fixed_asset_depreciation_detail A 
     INNER JOIN tblFaUpdateValue B ON A.organization_id = B.organization_id AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
     set A.depreciation_value = B.depreciation_value
     WHERE A.depreciation_value <> B.depreciation_value;

     UPDATE fixed_asset_ledger A 
     INNER JOIN tblFaUpdateValue B ON A.organization_id = B.organization_id AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
     set A.depreciation_value = B.depreciation_value
     WHERE A.voucher_type = 5 AND A.depreciation_value <> B.depreciation_value;
    
    UPDATE fixed_asset_depreciation fad
    INNER JOIN
    (
        SELECT fadd.organization_id, fadd.voucher_id, SUM(ROUND(fadd.depreciation_value)) AS TotalMoney
        FROM fixed_asset_depreciation_detail fadd
        GROUP BY fadd.organization_id, fadd.voucher_id
    ) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
    set fad.total_price = B.TotalMoney
    WHERE fad.organization_id = $organ_id AND fad.total_price <> B.TotalMoney;      

    CALL Proc_Jira_ReCallUpdateFAData($fixed_asset_id);

    DROP TEMPORARY TABLE IF EXISTS tblFaUpdateValue;

END;

CALL Proc_Jira_UpdateDepreciationValueGrowByFA('e816baa8-b71f-4611-a5bd-a8bf87ccc139');

SELECT concat("CALL Proc_Jira_UpdateDepreciationValueGrowByFA('",fal.fixed_asset_id,"');") as Data 
FROM fixed_asset_ledger fal
WHERE fal.organization_id = 'd8b3862f-9ac6-4dec-9baa-846bfd94e314' 
AND fal.voucher_type = 5 
AND fal.remaining_amount < 10 
AND fal.remaining_amount > 0
GROUP BY fal.fixed_asset_id;

