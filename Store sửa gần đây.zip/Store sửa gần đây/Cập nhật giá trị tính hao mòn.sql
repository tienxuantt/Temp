﻿UPDATE fixed_asset_depreciation_detail fadd
set fadd.depreciation_value = 7500000, fadd.depreciation_year = 7500000
WHERE fadd.voucher_id = '3422260b-582c-4b73-a750-5574fd736304' AND fadd.fixed_asset_id = '480c698f-459c-4f77-94f5-4e60d284fe00';

UPDATE fixed_asset_ledger fadd
set fadd.depreciation_value = 7500000, fadd.depreciation_year = 7500000
WHERE fadd.voucher_id = '3422260b-582c-4b73-a750-5574fd736304' AND fadd.voucher_type = 5 AND fadd.fixed_asset_id = '480c698f-459c-4f77-94f5-4e60d284fe00';

UPDATE fixed_asset fa set fa.depreciation_year =   7500000 WHERE  fixed_asset_id = '480c698f-459c-4f77-94f5-4e60d284fe00';

UPDATE fixed_asset_depreciation fad
INNER JOIN
(
    SELECT fadd.organization_id, fadd.voucher_id, SUM(ROUND(fadd.depreciation_value)) AS TotalMoney
    FROM fixed_asset_depreciation_detail fadd
    GROUP BY fadd.organization_id, fadd.voucher_id
) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
set fad.total_price = B.TotalMoney
WHERE fad.total_price <> B.TotalMoney;

CALL Proc_Jira_ReCallUpdateFAData('480c698f-459c-4f77-94f5-4e60d284fe00');

