﻿
SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_Survey_Revaluation_RemainingAmount_Error;

CREATE PROCEDURE Proc_Jira_Survey_Revaluation_RemainingAmount_Error (IN $view_output int)
BEGIN

  SET group_concat_max_len = 18446744073709551615;

  DROP TEMPORARY TABLE IF EXISTS a1_tmp;
  CREATE TEMPORARY TABLE a1_tmp AS
  SELECT
    r.remaining_amount,
    fa.voucher_id,
    fa.fixed_asset_id,
    fa.fixed_asset_code,
    fa.organization_id
  FROM fixed_asset_revaluation fa
         INNER JOIN fixed_asset fa1
           ON fa.fixed_asset_id = fa1.fixed_asset_id,
       JSON_TABLE (fa.fixed_asset_revaluation_list,
       '$[*]'
       COLUMNS (
       remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount'
       )) AS r
  WHERE (fa1.is_parent IS NULL
  OR fa1.is_parent = FALSE);

  DELETE FROM jira_fa_focus;
  
  DROP TEMPORARY TABLE IF EXISTS tmpFAErr;
  CREATE TEMPORARY TABLE tmpFAErr AS
  SELECT a.organization_id,
        a.fixed_asset_id,
        a.voucher_id
  FROM fixed_asset_ledger fal
  INNER JOIN a1_tmp a ON fal.organization_id = a.organization_id AND fal.fixed_asset_id = a.fixed_asset_id AND fal.voucher_id = a.voucher_id
  LEFT JOIN jira_fa_focus jfas ON a.fixed_asset_id = jfas.fixed_asset_id and fal.voucher_id = jfas.voucher_id
  WHERE fal.voucher_type = 2
  AND IFNULL(fal.remaining_amount, 0) <> IFNULL(a.remaining_amount, 0)
  AND jfas.fixed_asset_id IS NULL;

  INSERT INTO jira_fa_focus (id, fixed_asset_id, voucher_id)
  SELECT UUID(), fixed_asset_id, a.voucher_id
  FROM tmpFAErr a
  GROUP BY a.fixed_asset_id, a.voucher_id ;

    IF ($view_output = 1) THEN
          SELECT fixed_asset_id, a.voucher_id
          FROM tmpFAErr a
          GROUP BY a.fixed_asset_id, a.voucher_id;
    end if;

  DROP TEMPORARY TABLE IF EXISTS a1_tmp;
  DROP TEMPORARY TABLE IF EXISTS tmpFAErr;
END;

CALL Proc_Jira_Survey_Revaluation_RemainingAmount_Error(0);