﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_UpdateDepartmentIDMiss;

CREATE PROCEDURE Proc_Jira_UpdateDepartmentIDMiss (IN $OrganizationID char(36), IN $FixedAssetID char(36))
BEGIN

     DECLARE $department_id varchar(36);

      SELECT
        fa.department_id INTO $department_id
      FROM fixed_asset fa
      WHERE fa.organization_id = $OrganizationID AND fa.status_id = 1 AND IFNULL(fa.is_parent,0) = 0 AND IFNULL(fa.department_id,'') <> ''
      LIMIT 1;

      UPDATE fixed_asset fa
      SET fa.department_id = $department_id
      WHERE  fa.fixed_asset_id = $FixedAssetID;

END;