﻿SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_KS_FARevaluationDiffLedger;

CREATE PROCEDURE Proc_Jira_KS_FARevaluationDiffLedger (IN $OrganizationID varchar(36))
COMMENT ''
BEGIN

  DROP TEMPORARY TABLE IF EXISTS tmpLedgerRevalulation;
  CREATE TEMPORARY TABLE tmpLedgerRevalulation
  SELECT fal.organization_id, fal.voucher_id, fal.fixed_asset_id, fal.orgprice, fal.accum_depreciation_amount, fal.remaining_amount 
  FROM fixed_asset_ledger fal
  INNER JOIN fa_jira_execute B ON fal.organization_id = B.organization_id and fal.fixed_asset_id = B.fixed_asset_id
  WHERE fal.voucher_type = 2 AND (fal.organization_id = $OrganizationID OR $OrganizationID IS NULL);

  DROP TEMPORARY TABLE IF EXISTS tmpFAError;
  CREATE TEMPORARY TABLE tmpFAError
  SELECT
    fa.fixed_asset_code,
    fa.fixed_asset_id,
    fa.organization_id,
    far.voucher_id,
    far.fixed_asset_revaluation_list,
    far.revaluation_type
  FROM fixed_asset fa
    INNER JOIN fixed_asset_revaluation far
      ON fa.organization_id = far.organization_id
      AND fa.fixed_asset_id = far.fixed_asset_id
  WHERE (fa.organization_id = $OrganizationID OR $OrganizationID IS NULL)
  AND fa.status_id <> 2
  AND IFNULL(fa.is_parent, 0) = 0
  AND IFNULL(far.fixed_asset_revaluation_list, '') <> '';

  DROP TEMPORARY TABLE IF EXISTS tbNewData;
  CREATE TEMPORARY TABLE tbNewData (
    fixed_asset_code  varchar(100),
    organization_id varchar(36),
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    revaluation_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;
                                                         

  INSERT INTO tbNewData
    SELECT
      fa.fixed_asset_code,
      fa.organization_id,
      fa.fixed_asset_id,
      fa.voucher_id,
      fa.revaluation_type,
      r.*
    FROM tmpFAError fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
         orgprice_info longtext PATH '$.new_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.new_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_amount',
         remaining_amount decimal(19, 4) PATH '$.new_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.new_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.new_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.new_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.new_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.new_data[*].quantity',
         house_category_id int PATH '$.new_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.new_data[*].house_category_name',
         number_of_floor float PATH '$.new_data[*].number_of_floor',
         build_year int PATH '$.new_data[*].build_year',
         build_area float PATH '$.new_data[*].build_area',
         total_floor_area float PATH '$.new_data[*].total_floor_area',
         area float PATH '$.new_data[*].area',
         working_office float PATH '$.new_data[*].working_office',
         leasing float PATH '$.new_data[*].leasing',
         house float PATH '$.new_data[*].house',
         basis_of_business_activity float PATH '$.new_data[*].basis_of_business_activity',
         vacant float PATH '$.new_data[*].vacant',
         business float PATH '$.new_data[*].business',
         joint_venture float PATH '$.new_data[*].joint_venture',
         mix_using float PATH '$.new_data[*].mix_using',
         occupied float PATH '$.new_data[*].occupied',
         other float PATH '$.new_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.new_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.new_data[*].orgprice_from_other'
         )) AS r;
                                                       

        UPDATE fixed_asset_ledger fal
        INNER JOIN (
            SELECT A.organization_id, A.fixed_asset_id, A.voucher_id, A.orgprice, A.depreciation_amount
            FROM tbNewData A 
            INNER JOIN tmpLedgerRevalulation B 
            on B.organization_id = A.organization_id AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
            INNER JOIN dic_organization do on A.organization_id = do.organization_id
            WHERE A.orgprice <> B.orgprice
        )  T ON fal.organization_id = T.organization_id AND fal.voucher_id = T.voucher_id AND fal.fixed_asset_id = T.fixed_asset_id
        set fal.orgprice = T.orgprice, fal.depreciation_amount = T.depreciation_amount, fal.accum_depreciation_amount = IF(fal.fixed_asset_type in (1,2), T.depreciation_amount,  fal.accum_depreciation_amount);


        DROP TEMPORARY TABLE IF EXISTS Temp_Jira_ReCallUpdateFAData;
        CREATE TEMPORARY TABLE Temp_Jira_ReCallUpdateFAData
        SELECT do.organization_code, A.fixed_asset_code, fal.orgprice, fal.accum_depreciation_amount
        FROM tbNewData A 
        INNER JOIN tmpLedgerRevalulation B 
        on B.organization_id = A.organization_id AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
        INNER JOIN dic_organization do on A.organization_id = do.organization_id
        INNER JOIN fixed_asset_ledger fal ON fal.voucher_type IN (1,8) AND fal.organization_id = B.organization_id AND A.fixed_asset_id = fal.fixed_asset_id
        WHERE A.orgprice <> B.orgprice;
       
        CALL Proc_Jira_ReCallUpdateFAData();
                                
         DROP TEMPORARY TABLE IF EXISTS tmpLedgerRevalulation;
         DROP TEMPORARY TABLE IF EXISTS tmpFAError;
END;



CALL Proc_Jira_KS_FARevaluationDiffLedger(NULL);