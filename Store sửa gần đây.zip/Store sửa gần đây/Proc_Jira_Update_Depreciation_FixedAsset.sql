﻿DROP PROCEDURE IF EXISTS Proc_Jira_Update_Depreciation_FixedAsset;

CREATE PROCEDURE Proc_Jira_Update_Depreciation_FixedAsset(IN $Organ_Code varchar(36), IN $FA_Code varchar(36), IN $OrgPrice decimal(19, 4), IN $AccumDepreciationAmount decimal(19, 4))
SQL SECURITY INVOKER
BEGIN
  DECLARE $Count int DEFAULT 0;
  DECLARE $i int DEFAULT 1;
  DECLARE $VoucherType int DEFAULT 0;
  DECLARE $OrgpriceFA decimal(19, 4) DEFAULT 0;
  DECLARE $SumBudget decimal(19, 4) DEFAULT 0;
  DECLARE $LedgerBudgetID varchar(36);
  DECLARE $OrganizationID varchar(36);
  DECLARE $FixedAssetID varchar(36);

  SET $OrganizationID = (SELECT do.organization_id FROM dic_organization do WHERE do.organization_code = $Organ_Code LIMIT 1);
  SET $FixedAssetID = (SELECT fa.fixed_asset_id FROM fixed_asset fa WHERE fa.organization_id = $OrganizationID AND fa.fixed_asset_code = $FA_Code LIMIT 1);

  DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
  CREATE TEMPORARY TABLE tbUpdateData (
    STT int,
    fixed_asset_ledger_id bigint,
    fixed_asset_id varchar(36),
    voucher_id varchar(36),
    voucher_code varchar(100),
    voucher_type int,
    change_date datetime,
    orgprice decimal(19, 4),
    voucher_price decimal(19, 4),
    depreciation_value decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4)
  ) COLLATE utf8mb4_0900_as_ci;

  DROP TEMPORARY TABLE IF EXISTS tbOrginData;
  CREATE TEMPORARY TABLE tbOrginData
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id ORDER BY DATE(A.change_date), A.created_date) AS STT
  FROM (SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS voucher_price,
      CASE WHEN voucher_type = 9 THEN IFNULL(depreciation_for_business_value, 0) ELSE IF(voucher_type = 5, IFNULL(depreciation_value, 0), 0) END AS depreciation_value,
      accum_depreciation_amount,
      remaining_amount
    FROM fixed_asset_ledger
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID
    AND voucher_type <> 17
    UNION ALL
    SELECT
      fixed_asset_ledger_id,
      fixed_asset_id,
      voucher_id,
      voucher_code,
      voucher_type,
      change_date,
      created_date,
      orgprice,
      depreciation_value AS voucher_price,
      depreciation_value,
      accum_depreciation_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE organization_id = $OrganizationID
    AND fixed_asset_id = $FixedAssetID) A;

IF EXISTS (SELECT 1 FROM tbOrginData od WHERE od.voucher_type in (1,8) AND od.STT = 1) THEN
BEGIN

    SELECT
    COUNT(1) INTO $Count
    FROM tbOrginData;

  WHILE $i <= $Count DO

    IF $i = 1 THEN
      INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
        SELECT
          STT,
          fixed_asset_ledger_id,
          fixed_asset_id,
          voucher_id,
          voucher_code,
          voucher_type,
          change_date,
          $OrgPrice as orgprice,
          voucher_price,
          depreciation_value,
          $AccumDepreciationAmount AS accum_depreciation_amount,
          IFNULL($OrgPrice, 0) - $AccumDepreciationAmount AS remaining_amount
        FROM tbOrginData
        WHERE STT = $i;

      IF $i = $Count THEN

        -- Cập nhật tài sản
        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.accum_depreciation_amount,
            A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
            A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID;

        -- Cập nhật detail ghi tang
        UPDATE fixed_asset_increment_detail A
        INNER JOIN tbUpdateData B ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.accum_depreciation_amount,
            A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
            A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID;
      END IF;

    ELSE
      DROP TEMPORARY TABLE IF EXISTS tbCacheData;
      CREATE TEMPORARY TABLE tbCacheData
      SELECT
        *
      FROM tbUpdateData
      WHERE STT = $i - 1;

      SELECT
        voucher_type INTO $VoucherType
      FROM tbOrginData
      WHERE STT = $i;

      IF ($VoucherType IN (2, 10, 17)) THEN
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            IF($VoucherType = 10, B.orgprice, A.orgprice) AS orgprice,
            A.voucher_price,
            0 AS depreciation_value,
            IF($VoucherType = 10, B.accum_depreciation_amount, A.accum_depreciation_amount),
            IF($VoucherType = 10, B.remaining_amount, IFNULL(A.orgprice, 0) - IFNULL(A.accum_depreciation_amount, 0)) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      ELSE
        INSERT INTO tbUpdateData (STT, fixed_asset_ledger_id, fixed_asset_id, voucher_id, voucher_code, voucher_type, change_date, orgprice, voucher_price, depreciation_value, accum_depreciation_amount, remaining_amount)
          SELECT
            A.STT,
            A.fixed_asset_ledger_id,
            A.fixed_asset_id,
            A.voucher_id,
            A.voucher_code,
            A.voucher_type,
            A.change_date,
            B.orgprice,
            A.voucher_price,
            A.depreciation_value,
            IFNULL(B.accum_depreciation_amount, 0) + IFNULL(A.depreciation_value, 0) AS accum_depreciation_amount,
            IFNULL(B.remaining_amount, 0) - IFNULL(A.depreciation_value, 0) AS remaining_amount
          FROM tbOrginData A
            LEFT JOIN tbCacheData B
              ON 1 = 1
          WHERE A.STT = $i;
      END IF;

      IF $i = $Count THEN

        UPDATE fixed_asset A
        INNER JOIN tbUpdateData B
          ON A.fixed_asset_id = B.fixed_asset_id
        SET A.orgprice = B.orgprice,
            A.accum_depreciation_amount = B.accum_depreciation_amount,
            A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
            A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
            A.remaining_amount = B.remaining_amount
        WHERE A.organization_id = $OrganizationID
        AND B.STT = $Count;

      END IF;
    END IF;

    SET $i = $i + 1;
    SET $VoucherType = 0;
  END WHILE;

  -- Cập nhật ledger to
  UPDATE fixed_asset_ledger A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type <> 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount
  WHERE A.organization_id = $OrganizationID;


  -- Cập nhật ledger hao mòn, khấu hao
  UPDATE fa_ledger_depreciation A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (5, 9)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount
  WHERE A.organization_id = $OrganizationID;

  -- Cập nhật ledger ghi tăng, giảm
  UPDATE fa_ledger_increment_and_decrement A
  INNER JOIN (SELECT
      *
    FROM tbUpdateData
    WHERE voucher_type IN (1, 8, 6)) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_id = B.fixed_asset_id
    AND A.voucher_id = B.voucher_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount
  WHERE A.organization_id = $OrganizationID;

  -- Cập nhật ledger kiểm kê
  UPDATE fa_ledger_inventory A
  INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 10) B
    ON A.organization_id = $OrganizationID
    AND A.fixed_asset_ledger_id = B.fixed_asset_ledger_id
  SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
  WHERE A.organization_id = $OrganizationID;

    -- Detail ghi tăng
    UPDATE fixed_asset_increment_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 1) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN fa.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 2 THEN 0 WHEN fa.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN fa.fixed_asset_type = 1 THEN 0 WHEN fa.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Hao mon
    UPDATE fixed_asset_depreciation_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 5) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail KH
    UPDATE fixed_asset_depreciation_business_detail  A
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 9) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN A.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 2 THEN 0 WHEN A.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN A.fixed_asset_type = 1 THEN 0 WHEN A.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN A.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.first_remaining_amount = IFNULL(B.remaining_amount,0) + IFNULL(B.depreciation_value,0),
      A.depreciation_value = 0
   WHERE A.organization_id = $OrganizationID;  

    -- Detail Ghi giam
    UPDATE fixed_asset_decrement_detail  A
    INNER JOIN fixed_asset fa ON fa.organization_id = $OrganizationID AND A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN (SELECT * FROM tbUpdateData WHERE voucher_type = 6) B
    ON A.organization_id = $OrganizationID AND A.voucher_id = B.voucher_id AND A.fixed_asset_id = B.fixed_asset_id
   SET A.orgprice = B.orgprice,
      A.accum_depreciation_amount = B.accum_depreciation_amount,
      A.depreciation_amount = CASE WHEN fa.fixed_asset_type = 1 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 2 THEN 0 WHEN fa.fixed_asset_type = 3 THEN A.depreciation_amount END,
      A.depreciation_for_business_amount = CASE WHEN fa.fixed_asset_type = 1 THEN 0 WHEN fa.fixed_asset_type = 2 THEN B.accum_depreciation_amount WHEN fa.fixed_asset_type = 3 THEN A.depreciation_for_business_amount END,
      A.remaining_amount = B.remaining_amount,
      A.depreciation_value = 0,
      A.depreciation_for_business_value = 0
   WHERE A.organization_id = $OrganizationID;      

  -- Lấy nguyên giá của tài sản
  set $OrgpriceFA = (SELECT orgprice FROM fixed_asset fa WHERE fa.fixed_asset_id = $FixedAssetID);

  -- Ledger budget của tài sản
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
  CREATE TEMPORARY TABLE tbLedgerBudgetFA
  SELECT lb.*
  FROM ledger_budget lb 
  INNER JOIN
  (
    SELECT * FROM
    (
      SELECT l.fixed_asset_id, IFNULL(l.voucher_id, '') AS voucher_id,
      ROW_NUMBER() OVER(PARTITION BY fixed_asset_id ORDER BY change_date DESC, created_date DESC) AS STT
      FROM ledger_budget l
      WHERE l.fixed_asset_id = $FixedAssetID AND IFNULL(voucher_type, 1) IN (1,2,8)
    ) A WHERE A.STT = 1
  ) A2 ON lb.fixed_asset_id = A2.fixed_asset_id AND IFNULL(lb.voucher_id, '') = A2.voucher_id;

  -- Nếu nguyên giá khác với tổng trong ledger budget thì cập nhật lại
  IF (select SUM(amount) FROM tbLedgerBudgetFA) <> $OrgpriceFA THEN
      BEGIN

                 -- Cập nhật đối với trường hợp chỉ có một nguồn
                 IF (SELECT count(*) FROM tbLedgerBudgetFA) = 1 THEN
                 BEGIN
                    UPDATE  tbLedgerBudgetFA set amount = $OrgpriceFA;

                    UPDATE ledger_budget lb 
                    INNER JOIN tbLedgerBudgetFA lbf ON lb.organization_id = lbf.organization_id AND lb.ledger_budget_id = lbf.ledger_budget_id
                    set lb.amount = lbf.amount;
                 END;
                 END IF;

                -- Trường hợp có nhiều nguồn
                IF (SELECT count(*) FROM tbLedgerBudgetFA) > 1 THEN
                 BEGIN
                    SET $LedgerBudgetID = (SELECT ledger_budget_id FROM tbLedgerBudgetFA ORDER BY amount DESC LIMIT 1);

                    SET $SumBudget =  (SELECT sum(amount) FROM tbLedgerBudgetFA WHERE ledger_budget_id <> $LedgerBudgetID);

                    UPDATE ledger_budget lb 
                    set lb.amount = ifnull($OrgpriceFA,0) - ifnull($SumBudget,0)
                    WHERE lb.ledger_budget_id =  $LedgerBudgetID;

                 END;
                 END IF;
                 
      END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbCacheData;
  DROP TEMPORARY TABLE IF EXISTS tbLedgerBudgetFA;
    
END; 
END IF;
  
DROP TEMPORARY TABLE IF EXISTS tbUpdateData;
DROP TEMPORARY TABLE IF EXISTS tbOrginData;

END;
