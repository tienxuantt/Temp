﻿-- Xóa một dòng hao mòn khỏi lịch sử biến động
DELETE FROM fixed_asset_ledger WHERE voucher_id = '210b9ec2-42ea-4f35-bb7a-946c2a898c6f' and fixed_asset_id = '469f2bb4-891d-48ec-bcaa-af6827105a86';
DELETE FROM fixed_asset_depreciation_detail WHERE voucher_id = '210b9ec2-42ea-4f35-bb7a-946c2a898c6f' and fixed_asset_id = '469f2bb4-891d-48ec-bcaa-af6827105a86';
CALL Proc_Jira_Update_Depreciation_FixedAsset('d7203e3c-f2eb-4fad-b41c-8d1413131f21','469f2bb4-891d-48ec-bcaa-af6827105a86', 2340000);

UPDATE fixed_asset_depreciation fad
INNER JOIN (SELECT
    fadd.organization_id,
    fadd.voucher_id,
    SUM(COALESCE(fadd.depreciation_value, 0)) AS total_detail
  FROM fixed_asset_depreciation_detail fadd
  WHERE IFNULL(fadd.is_parent, 0) = 0 AND fadd.organization_id = 'd7203e3c-f2eb-4fad-b41c-8d1413131f21'
  GROUP BY fadd.voucher_id,
           fadd.organization_id) a
  ON fad.organization_id = a.organization_id AND fad.voucher_id = a.voucher_id
SET fad.total_price = a.total_detail
WHERE fad.total_price <> a.total_detail AND fad.organization_id = 'd7203e3c-f2eb-4fad-b41c-8d1413131f21';

-- --------------------------------------------------------------------------------------------------------------------------------------------------



