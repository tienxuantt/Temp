﻿use MISAAsset_hoabinh;
go

DROP PROCEDURE IF EXISTS [Proc_CreateAccountMisaQlts];
go

CREATE PROCEDURE [Proc_CreateAccountMisaQlts]
@OrganizationCode nvarchar(100)
AS

--start transaction
BEGIN TRANSACTION

Declare @UserID uniqueidentifier = newid();
Declare @UserName nvarchar(100) = concat(@OrganizationCode,'_misaqlts');
Declare @OrganID uniqueidentifier = (select Top(1) OrganizationID from Organization where OrganizationCode = @OrganizationCode);

if not exists (select 1 from dbo.aspnet_Users where UserName = @UserName)
begin
-- CREATE TABLE #temptable ( [ApplicationId] uniqueidentifier, [UserId] uniqueidentifier, [UserName] nvarchar(256), [LoweredUserName] nvarchar(256), [MobileAlias] nvarchar(16), [IsAnonymous] bit, [LastActivityDate] datetime, [IsSystem] bit, [DictionaryKey] int, [IsActivate] bit, [IsForgotPassword] bit, [UserNameDisplay] nvarchar(255), [StringRandomFromForgotPassword] nvarchar(50) )
INSERT INTO dbo.aspnet_Users
VALUES
( '{B17585E2-B82D-436F-AD59-BD351BDABE45}', @UserID, @UserName, @UserName, NULL, 0, N'2020-05-13T05:06:19.827', 0, 0, 1, 0, N'misaqlts', NULL )

-- CREATE TABLE #temptable ( [UserId] uniqueidentifier, [RoleId] uniqueidentifier, [Description] nvarchar(255) )
INSERT INTO dbo.aspnet_UsersInRoles
VALUES
( @UserID, '{69d0b556-1cf1-4be1-a017-e2791f20d5e9}', N'Hệ thống' )

-- CREATE TABLE #temptable ( [ApplicationId] uniqueidentifier, [UserId] uniqueidentifier, [Password] nvarchar(128), [PasswordFormat] int, [PasswordSalt] nvarchar(128), [MobilePIN] nvarchar(16), [Email] nvarchar(256), [LoweredEmail] nvarchar(256), [PasswordQuestion] nvarchar(256), [PasswordAnswer] nvarchar(128), [IsApproved] bit, [IsLockedOut] bit, [CreateDate] datetime, [LastLoginDate] datetime, [LastPasswordChangedDate] datetime, [LastLockoutDate] datetime, [FailedPasswordAttemptCount] int, [FailedPasswordAttemptWindowStart] datetime, [FailedPasswordAnswerAttemptCount] int, [FailedPasswordAnswerAttemptWindowStart] datetime, [Comment] nvarchar(255), [Address] nvarchar(255), [JobTitle] nvarchar(100), [OrganizationUnit] nvarchar(500), [OfficePhone] nvarchar(50), [Mobile] nvarchar(50), [FullName] nvarchar(100), [IsManager] bit, [Fax] nvarchar(50), [HomePhone] nvarchar(50), [OfficeEmail] nvarchar(255), [OfficeAddress] nvarchar(255), [Photo] varbinary(max), [OrganizationUnitID] uniqueidentifier, [Password256] nvarchar(256) )
INSERT INTO dbo.aspnet_Membership
VALUES
( '{b17585e2-b82d-436f-ad59-bd351bdabe45}', @UserID, N'W7wuPHO19rIv+M2M2m7Stxr+zUQ=', 1, N'ZmovQ0moT468ZkeijKtLHw==', NULL, NULL, N'misaqlts@gmail.com', NULL, NULL, 1, 0, N'2012-10-31T11:59:29', N'2022-07-04T02:59:32.577', N'2022-07-04T02:59:32.733', N'1754-01-01T00:00:00', 0, N'1754-01-01T00:00:00', 0, N'1754-01-01T00:00:00', N'', N'', N'Kế toán ', N'Trường Tiểu học Văn Hoàng', N'', N'0986446568', N'admin', NULL, N'', N'', N'vuhienchau1983@gmail.com', N'', NULL, NULL, N'2a46c3858e14bcbc7538ebc1ab171a357ddea9f68d500abc4b2842dc900762d8' )

INSERT INTO dbo.SC_OrganizationUser
VALUES (NEWID(), @UserID, @OrganID, 1);
end;

IF @@ERROR != 0
BEGIN
ROLLBACK TRANSACTION
RETURN
END
COMMIT TRANSACTION
go

EXECUTE [dbo].[Proc_CreateAccountMisaQlts] N'3009888'
GO