﻿SET NAMES 'utf8';
DROP PROCEDURE IF EXISTS Proc_Jira_KS_Duplicate_Depreciation_Ledger;

CREATE PROCEDURE Proc_Jira_KS_Duplicate_Depreciation_Ledger ()
BEGIN

        DELETE FROM fa_jira_execute;

        DROP TEMPORARY TABLE IF EXISTS tbFixedAssetError;
        CREATE TEMPORARY TABLE tbFixedAssetError
        SELECT fal.voucher_id, fal.fixed_asset_id, fal.change_date, MAX(fal.fixed_asset_ledger_id) AS ID  
        FROM fixed_asset_ledger fal
        WHERE fal.voucher_type = 5
        GROUP BY fal.voucher_id, fal.fixed_asset_id, fal.change_date
        HAVING COUNT(*) > 1;

       INSERT fa_jira_execute (organization_id, fixed_asset_id, TYPE)
       SELECT UUID(), fixed_asset_id, 0
       FROM  tbFixedAssetError
       GROUP BY fixed_asset_id;

       DELETE A 
       FROM fixed_asset_ledger A
       INNER JOIN tbFixedAssetError fae on A.fixed_asset_ledger_id = fae.ID
       WHERE A.voucher_type = 5;

       DROP TEMPORARY TABLE IF EXISTS tbFixedAssetError;

END;

CALL Proc_Jira_KS_Duplicate_Depreciation_Ledger();