﻿SET NAMES 'utf8';
DROP PROCEDURE IF EXISTS Proc_Jira_KS_Revaluation_AccumOldByFA;

CREATE PROCEDURE Proc_Jira_KS_Revaluation_AccumOldByFA (IN $Voucher_id varchar(36), IN $FixedAssetID varchar(36))
BEGIN

  DECLARE $STT_Current int DEFAULT 0;
  DECLARE $revaluation_type int DEFAULT 0;
  DECLARE $fixed_asset_type int DEFAULT 0;
  DECLARE $OrgPrice decimal(19, 4) DEFAULT 0;
  DECLARE $Accum decimal(19, 4) DEFAULT 0;
  DECLARE $AccumLedger decimal(19, 4) DEFAULT 0;
  DECLARE $Remaining decimal(19, 4) DEFAULT 0;

  SET group_concat_max_len = 18446744073709551615;

  DROP TEMPORARY TABLE IF EXISTS tbOrginLedgerData;
  CREATE TEMPORARY TABLE tbOrginLedgerData
  SELECT
    *,
    ROW_NUMBER() OVER (PARTITION BY fixed_asset_id
    ORDER BY A.change_date, A.created_date) AS STT
  FROM (SELECT
      lg.voucher_id,
      lg.fixed_asset_id,
      lg.change_date,
      lg.created_date,
      lg.orgprice,
      lg.accum_depreciation_amount,
      lg.remaining_amount
    FROM fixed_asset_ledger lg
    WHERE lg.fixed_asset_id = $FixedAssetID
    AND lg.voucher_type <> 17
    UNION ALL
    SELECT
      voucher_id,
      fixed_asset_id,
      change_date,
      created_date,
      orgprice,
      accum_depreciation_amount,
      remaining_amount
    FROM fa_ledger_inventory
    WHERE fixed_asset_id = $FixedAssetID) A;

  -- Lấy ra STT hiện tại
  SET $STT_Current = (SELECT
      STT
    FROM tbOrginLedgerData
    WHERE voucher_id = $Voucher_id LIMIT 1);

  -- Lấy ra bản ghi trước đó
  SELECT
    orgprice,
    accum_depreciation_amount,
    remaining_amount INTO $OrgPrice, $Accum, $Remaining
  FROM tbOrginLedgerData
  WHERE STT = $STT_Current - 1
  LIMIT 1;


  DROP TEMPORARY TABLE IF EXISTS tbFixedAssetRevaluation;
  CREATE TEMPORARY TABLE tbFixedAssetRevaluation AS
  SELECT
    r.orgprice,
    r.orgprice_info,
    r.orgprice_old,
    r.orgprice_info_old,
    fa.voucher_id,
    fa.fixed_asset_id,
    fa.fixed_asset_code,
    fa.organization_id,
    fa.fixed_asset_revaluation_list,
    fa.revaluation_type,
    fa.description,
    COALESCE(fa1.fixed_asset_type, 0) fixed_asset_type
  FROM fixed_asset_revaluation fa
         INNER JOIN fixed_asset fa1
           ON fa.organization_id = fa1.organization_id
           AND fa.fixed_asset_id = fa1.fixed_asset_id,
       JSON_TABLE (fa.fixed_asset_revaluation_list,
       '$[*]'
       COLUMNS (
       orgprice decimal(19, 4) PATH '$.new_data[*].orgprice',
       orgprice_info text PATH '$.new_data[*].orgprice_info',
       orgprice_old decimal(19, 4) PATH '$.old_data[*].orgprice',
       orgprice_info_old text PATH '$.old_data[*].orgprice_info'
       )) AS r
  WHERE fa.fixed_asset_id = $FixedAssetID
  AND fa.voucher_id = $Voucher_id;

  -- Lưu 2 biến riêng
  SELECT
    fixed_asset_type,
    revaluation_type INTO $fixed_asset_type, $revaluation_type
  FROM tbFixedAssetRevaluation;

  DROP TEMPORARY TABLE IF EXISTS tbOldData;
  CREATE TEMPORARY TABLE tbOldData (
    voucher_id varchar(36),
    fixed_asset_id varchar(36),
    description text,
    fixed_asset_type int,
    orgprice decimal(19, 4),
    orgprice_info longtext,
    depreciation_amount decimal(19, 4),
    depreciation_for_business_amount decimal(19, 4),
    accum_depreciation_amount decimal(19, 4),
    remaining_amount decimal(19, 4),
    depreciation_for_business_remaining_amount decimal(19, 4),
    depreciation_rate decimal(19, 4),
    depreciation_year decimal(19, 4),
    remaining_number_of_year int,
    depreciation_for_business_price decimal(19, 4),
    depreciation_for_business_remaining_time decimal(19, 4),
    depreciation_for_business_value decimal(19, 4),
    quantity decimal(19, 4),
    house_category_id int,
    house_category_name varchar(500),
    number_of_floor float,
    build_year int,
    build_area float,
    total_floor_area float,
    area float,
    working_office float,
    leasing float,
    house float,
    basis_of_business_activity float,
    vacant float,
    business float,
    joint_venture float,
    mix_using float,
    occupied float,
    other float,
    orgprice_from_budget decimal(19, 4),
    orgprice_from_other decimal(19, 4),
    row_update int DEFAULT 0
  ) COLLATE utf8mb4_0900_as_ci;


  INSERT INTO tbOldData
    SELECT
      fa.voucher_id,
      fa.fixed_asset_id,
      fa.description,
      fa.fixed_asset_type,
      r.*,
      0 AS row_update
    FROM tbFixedAssetRevaluation fa,
         JSON_TABLE (fa.fixed_asset_revaluation_list,
         '$[*]'
         COLUMNS (
         orgprice decimal(19, 4) PATH '$.old_data[*].orgprice',
         orgprice_info longtext PATH '$.old_data[*].orgprice_info',
         depreciation_amount decimal(19, 4) PATH '$.old_data[*].depreciation_amount',
         depreciation_for_business_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_amount',
         accum_depreciation_amount decimal(19, 4) PATH '$.old_data[*].accum_depreciation_amount',
         remaining_amount decimal(19, 4) PATH '$.old_data[*].remaining_amount',
         depreciation_for_business_remaining_amount decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_amount',
         depreciation_rate decimal(19, 4) PATH '$.old_data[*].depreciation_rate',
         depreciation_year decimal(19, 4) PATH '$.old_data[*].depreciation_year',
         remaining_number_of_year int PATH '$.old_data[*].remaining_number_of_year',
         depreciation_for_business_price decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_price',
         depreciation_for_business_remaining_time decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_remaining_time',
         depreciation_for_business_value decimal(19, 4) PATH '$.old_data[*].depreciation_for_business_value',
         quantity decimal(19, 4) PATH '$.old_data[*].quantity',
         house_category_id int PATH '$.old_data[*].house_category_id',
         house_category_name varchar(500) PATH '$.old_data[*].house_category_name',
         number_of_floor float PATH '$.old_data[*].number_of_floor',
         build_year int PATH '$.old_data[*].build_year',
         build_area float PATH '$.old_data[*].build_area',
         total_floor_area float PATH '$.old_data[*].total_floor_area',
         area float PATH '$.old_data[*].area',
         working_office float PATH '$.old_data[*].working_office',
         leasing float PATH '$.old_data[*].leasing',
         house float PATH '$.old_data[*].house',
         basis_of_business_activity float PATH '$.old_data[*].basis_of_business_activity',
         vacant float PATH '$.old_data[*].vacant',
         business float PATH '$.old_data[*].business',
         joint_venture float PATH '$.old_data[*].joint_venture',
         mix_using float PATH '$.old_data[*].mix_using',
         occupied float PATH '$.old_data[*].occupied',
         other float PATH '$.old_data[*].other',
         orgprice_from_budget decimal(19, 4) PATH '$.old_data[*].orgprice_from_budget',
         orgprice_from_other decimal(19, 4) PATH '$.old_data[*].orgprice_from_other'
         )) AS r;

  
   set $AccumLedger = (SELECT od.depreciation_amount FROM tbOldData od LIMIT 1);     

   IF ($AccumLedger <> $Accum AND $AccumLedger >= 0) THEN
          INSERT jira_fixed_asset_error (ID, fixed_asset_id, voucher_id)
          SELECT uuid(), $FixedAssetID, $Voucher_id;
   end if;
        
END;

SELECT * FROM  jira_fixed_asset_error;

SELECT CONCAT("CALL Proc_Jira_KS_Revaluation_AccumOldByFA('",fal.voucher_id,"','",fal.fixed_asset_id,"');") as Data 
FROM fixed_asset_revaluation fal;

SELECT * FROM fixed_asset_ledger fal WHERE fal.voucher_description LIKE '%chuyển loại%'     LIMIT 10;