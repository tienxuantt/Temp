﻿SET NAMES 'utf8';

DROP TABLE IF EXISTS jira_asset_change_date;

CREATE TABLE jira_asset_change_date (
    organization_id varchar(36) DEFAULT NULL,
    voucher_id varchar(36) DEFAULT NULL,
    fixed_asset_id varchar(36) DEFAULT NULL,
    change_date datetime DEFAULT NULL,
    voucher_date datetime DEFAULT NULL,
    quantity decimal(19, 4) DEFAULT NULL,
    remaining_number_of_year decimal(19, 4) DEFAULT NULL,
    depreciation_year decimal(19, 4) DEFAULT NULL,
    depreciation_for_business_remaining_time decimal(19, 4) DEFAULT NULL,
    depreciation_rate decimal(19, 4) DEFAULT NULL,
    depreciation_for_business_value decimal(19, 4) DEFAULT NULL
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_as_ci,
ROW_FORMAT = DYNAMIC;