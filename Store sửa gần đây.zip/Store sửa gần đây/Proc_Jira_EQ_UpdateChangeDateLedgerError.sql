﻿ SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_EQ_UpdateChangeDateLedgerError;

CREATE PROCEDURE Proc_Jira_EQ_UpdateChangeDateLedgerError (IN $organization_id varchar(36))
SQL SECURITY INVOKER
BEGIN

        UPDATE equipment_ledger fad
        INNER JOIN
        (
             SELECT fal.organization_id, fal.voucher_id, MAX(fal.change_date)  AS change_date, MAX(fal.created_date) AS created_date
             FROM equipment_ledger fal
             WHERE fal.organization_id = $organization_id
             GROUP BY fal.organization_id, fal.voucher_id
        ) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
        set fad.change_date = B.change_date,
        fad.created_date = B.created_date
        WHERE fad.organization_id = $organization_id;

        UPDATE equipment_ledger_inventory fad
        INNER JOIN
        (
             SELECT fal.organization_id, fal.voucher_id, MAX(fal.change_date)  AS change_date, MAX(fal.created_date) AS created_date
             FROM equipment_ledger_inventory fal
             WHERE fal.organization_id = $organization_id
             GROUP BY fal.organization_id, fal.voucher_id
        ) B ON B.organization_id = fad.organization_id AND B.voucher_id = fad.voucher_id
        set fad.change_date = B.change_date,
        fad.created_date = B.created_date
        WHERE fad.organization_id = $organization_id;

END;


SELECT concat("Call Proc_Jira_UpdateChangeDateLedgerError('",a.organization_id,"');") AS Data
FROM fixed_asset a 
GROUP BY a.organization_id;

Call Proc_Jira_EQ_UpdateChangeDateLedgerError('cc238f87-7550-4985-bd4e-89cc703c8dfc');

SELECT eli.equipment_code, eli.voucher_code, eli.change_date, eli.created_date FROM equipment_ledger_inventory eli WHERE eli.voucher_id = 'c47f02a6-7c67-47fb-8b0f-af891a05da93' AND eli.equipment_code = 'CCDC39';
SELECT eli.equipment_code, eli.voucher_code, eli.change_date, eli.created_date FROM equipment_ledger eli WHERE eli.voucher_id = '05e12fd5-5829-4eb8-b779-57482e162c97' AND eli.equipment_code = 'CCDC39';

SELECT etd.created_date FROM equipment_transfer_detail etd WHERE etd.voucher_id = '05e12fd5-5829-4eb8-b779-57482e162c97';
SELECT etd.created_date FROM equipment_inventory etd WHERE etd.voucher_id = '05e12fd5-5829-4eb8-b779-57482e162c97';

UPDATE equipment_ledger_inventory eli
INNER JOIN equipment_inventory ei ON eli.voucher_id = ei.voucher_id AND eli.organization_id = ei.organization_id
set eli.created_date = ei.created_date;