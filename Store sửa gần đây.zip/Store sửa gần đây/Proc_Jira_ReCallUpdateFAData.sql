SET NAMES 'utf8';

DROP PROCEDURE IF EXISTS Proc_Jira_ReCallUpdateFAData;

CREATE PROCEDURE Proc_Jira_ReCallUpdateFAData (IN $fixed_asset_id varchar(36))
SQL SECURITY INVOKER
BEGIN
  DECLARE $i int DEFAULT 0;
  DECLARE $count int DEFAULT 0;
  DECLARE $organCode varchar(100) DEFAULT '';
  DECLARE $fixedAssetCode varchar(100) DEFAULT '';
  DECLARE $orgprice decimal(19, 4) DEFAULT 0;
  DECLARE $accum decimal(19, 4) DEFAULT 0;
  DECLARE $fixed_asset_type int DEFAULT 0;
  DECLARE $depreciation_amount decimal(19, 4) DEFAULT 0;
  DECLARE $depreciation_for_business_amount decimal(19, 4) DEFAULT 0;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationFA;
  CREATE TEMPORARY TABLE tbOrganizationFA (
    fixed_asset_id varchar(36)
  );

  IF ($fixed_asset_id IS NULL) THEN
  BEGIN
    INSERT tbOrganizationFA
      SELECT
        fixed_asset_id
      FROM tempReCallUpdateFAData;
  END;
  END IF;

  IF ($fixed_asset_id IS NOT NULL) THEN
  BEGIN
    INSERT tbOrganizationFA
      VALUES ($fixed_asset_id);
  END;
  END IF;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemFA;
  CREATE TEMPORARY TABLE tbOrganizationTemFA
  SELECT
    do.organization_code,
    fa.fixed_asset_code,
    fal.orgprice,
    fal.accum_depreciation_amount,
    fal.depreciation_amount,
    fal.depreciation_for_business_amount,
    fa.fixed_asset_type
  FROM tbOrganizationFA A
    INNER JOIN fixed_asset fa
      ON A.fixed_asset_id = fa.fixed_asset_id
    INNER JOIN dic_organization do
      ON fa.organization_id = do.organization_id
    INNER JOIN fixed_asset_ledger fal
      ON fal.voucher_type IN (1, 8)
      AND fal.organization_id = do.organization_id
      AND A.fixed_asset_id = fal.fixed_asset_id;

  SELECT
    COUNT(1) INTO $count
  FROM tbOrganizationTemFA;

  WHILE $i < $count DO
    SELECT
      organization_code,
      fixed_asset_code,
      orgprice,
      accum_depreciation_amount,
      fixed_asset_type,
      depreciation_amount,
      depreciation_for_business_amount INTO $organCode, $fixedAssetCode, $orgprice, $accum, $fixed_asset_type, $depreciation_amount, $depreciation_for_business_amount
    FROM tbOrganizationTemFA
    LIMIT $i, 1;

                IF ($fixed_asset_type = 3) THEN
                        CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT_ALL($organCode, $fixedAssetCode, IFNULL($orgprice, 0), IFNULL($depreciation_amount, 0), IFNULL($depreciation_for_business_amount, 0));
                ELSE
                        CALL Proc_Jira_Update_Depreciation_FixedAsset_From_GT($organCode, $fixedAssetCode, IFNULL($orgprice, 0), IFNULL($accum, 0));
                end if;

    SET $i = $i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tbOrganizationTemFA;
  DROP TEMPORARY TABLE IF EXISTS tempReCallUpdateFAData;

END;
